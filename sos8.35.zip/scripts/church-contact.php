<?php
include "db-conx.php";

$id =	$_POST['id'];
$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();

	$sql = 'insert into customers (id, first_name, last_name, role, phone1, phone2, email1, email2, fax, address, address_2, city, province, postal_code, country, notes)
				values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
				on duplicate key
				update first_name=?, last_name=?, role=?, phone1=?, phone2=?, email1=?, email2=?, fax=?, address=?, address_2=?, city=?, province=?, postal_code=?, country=?, notes=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$id,
		$_POST['first_name'],
		$_POST['last_name'],
		$_POST['role'],
		$_POST['phone1'],
		$_POST['phone2'],
		$_POST['email1'],
		$_POST['email2'],
		$_POST['fax'],
		$_POST['address'],
		$_POST['address_2'],
		$_POST['city'],
		$_POST['province'],
		$_POST['postal_code'],
		$_POST['country'],
		$_POST['notes'],
		$_POST['first_name'],
		$_POST['last_name'],
		$_POST['role'],
		$_POST['phone1'],
		$_POST['phone2'],
		$_POST['email1'],
		$_POST['email2'],
		$_POST['fax'],
		$_POST['address'],
		$_POST['address_2'],
		$_POST['city'],
		$_POST['province'],
		$_POST['postal_code'],
		$_POST['country'],
		$_POST['notes']
	));
	
	if ($id == 'new') {
		$id = $db_handle->lastInsertId();		

		// set some default values
		$sql = 'update customers set notes=concat(notes, "\n\rCustomer created via EPIC."), no_mail=1, source=? where id=?';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array(
			$_POST['contact_source'],
			$id
		));
	}

//	$result->status = $status;
	$result->id = $id;
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);
?>