<?php
var_dump(printer_list(PRINTER_ENUM_LOCAL | PRINTER_ENUM_SHARED));

$getprt=printer_list(PRINTER_ENUM_LOCAL| PRINTER_ENUM_SHARED );
$printers = serialize($getprt);
$printers=unserialize($printers);
//print_r($printers);
echo '<select name="printers">';
foreach ($printers as $PrintDest)  {
	$printer = "\\\\bob\\" . $PrintDest["NAME"];
	$printer = $PrintDest["NAME"];
//	$printer = $PrintDest["NAME"];
//	echo "<option value=".$PrintDest["NAME"].">".explode(",",$PrintDest["DESCRIPTION"])[1]."</option>";
	echo "<option value=".$PrintDest["NAME"].">".$printer."</option>";
}
echo '</select>';

$cmd = 'RunDLL32.EXE printui.dll,PrintUIEntry /y /n "' . $printer . '"';
echo $cmd;
exec($cmd, $output, $retval);
//echo $output;
echo $retval;

//echo printer_list(PRINTER_ENUM_LOCAL | PRINTER_ENUM_SHARED)[0][0];
//$getprt = printer_list( PRINTER_ENUM_LOCAL | PRINTER_ENUM_SHARED );
//$printers = json_encode($getprt);
//echo $printers[0]['NAME'];

//$page = "http://your_domain_name/filename.php";
//$page = "http://bob/sos/scripts/test.php";
//echo '1';
//print_page($page, $printer);
//echo '2';

function print_page($page, $printer) {
echo 'printer1=' . $printer;
//    $printer = "PrinterName"); 
    if($ph = printer_open($printer)) 
    { 

echo 'printer2=' . $printer;
       $content = file_get_contents($page); 

       printer_set_option($ph, PRINTER_MODE, "RAW"); 
       printer_write($ph, $content); 
       printer_close($ph); 
    } 
}


/*
//$printer = "EPSONFA4549 (WP-4535 Series)"; 
$output = 'hello world';

$handle = printer_open($printer);
printer_start_doc($handle, "Start Doc");
printer_start_page($handle);

//printer_write($handle, "test test");


printer_set_option($handle, PRINTER_MODE, "RAW"); 
//printer_write($handle, $output);
printer_draw_text($handle, '<div>the text that will be printed</div>', 100, 100);
//printer_write($handle, "\n");
printer_end_page($handle);
printer_end_doc($handle);
printer_close($handle);
*/
/*
if($ph = printer_open($printer)) 
{ 
   // Get file contents 
   $fh = fopen("test.php", "rb"); 
   $content = fread($fh, filesize("test.php")); 
   fclose($fh); 
   
   echo $content;
        
   // Set print mode to RAW and send PDF to printer 
   printer_set_option($ph, PRINTER_MODE, "RAW"); 
   printer_write($ph, $content); 
   printer_close($ph); 
} 
else echo "Couldn't connect..."; 
*/


/*<?php
    $getprt=printer_list( PRINTER_ENUM_LOCAL );
    echo json_encode($getprt);
?>

<script>
$.post('lsprt.php', function(data) {
    value = JSON.parse(data);
    for (val in value) {
        $('#asd').append('<option value="'+ value[val]['NAME'] +'">'+ value[val]['NAME'] +'</option>');
    }
});
</script>

<select id="asd"></select>*/
?>
