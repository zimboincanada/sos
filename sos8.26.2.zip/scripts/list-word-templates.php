<?php
// returns list of documents in $directory
$directory = $_POST['templatePath'];
$allfiles = glob($directory . "*.*");
$files = array();

foreach($allfiles as $file) {
   $files[] = basename($file);
}

echo json_encode($files);
?>