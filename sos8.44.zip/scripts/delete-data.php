<?php
	include "db-conx.php";
	include "inventory.php";

	$result = "database update fail";
	$query = $_POST['query'];
	$key = $_POST['key'];
	
	switch($query) {
		
		// delete single sales order (the table constraint will also remove the child sales order items)
		case 'deleteSalesOrder': {
			try {
				$db_handle->beginTransaction();							

				// put stock back on shelves
				$sql = 'select * from sales_order_items where sales_order=?';
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($key));
				while ($data = $sth->fetch()) {
					$sku = $data['sku'];
					$qty = $data['qty'];
					updateInventory(3, $sku, -$qty, 0);
				}			
					
				$sql = "delete from sales_orders where id=?";
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($key));
					
				if ($status) 
					$result = "success";
				
				$db_handle->commit();
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}				
			
			break;
		}

		case 'deletePurchaseOrder': {
			try {
				$db_handle->beginTransaction();							

				// put stock back on shelves
				if ($_POST['updateInventory'] == 'true') {
					$sql = 'select * from purchase_order_items where po_id=?';
					$sth = $db_handle->prepare($sql);
					$status = $sth->execute(array($key));
					while ($data = $sth->fetch()) {
						$sku = $data['sku'];
						$qty = $data['qty_received'];
						updateInventory(1, $sku, -$qty, 0);
					}			
				}

				$sql = "delete from purchase_orders where id=?";
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($key));
					
				if ($status) 
					$result = "success";
				
				$db_handle->commit();
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}				
			
			break;
		}
		
		case 'deleteCustomer': {
			$sql = "delete from customers where id=?";
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($key));
			
			if ($status) $result = "success";
			break;
		}		

		case 'deleteSubscription': {
			$sql = "delete from mag_subs where id=?";
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($key));
			
			$sql = "update sales_order_items set mag_sub_id=0 where mag_sub_id=?";
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($key));

			if ($status) $result = "success";
			break;
		}		

	}
	echo json_encode($result);
?>