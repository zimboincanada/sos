<?php
	/* SOS subs data to S2
	*/

	set_time_limit(500);
	$server = "localhost";
	$database = "sos_s2";
	$username = "root";
	$password = "";
	$db_handle = new PDO("mysql:host=$server;dbname=$database", $username, $password);
	
	try {
		$db_handle->beginTransaction();

		$sql = "truncate sos2ss";
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();

//donorOnlyList();		
//die(0);

		// print
/*
		$sql = "
			select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			ms.qty as tag1,
			'' as tag2,
			'' as tag3,
			'' as subgiver,
			ms.issue_status as cen,
			'' as pn,
			'' as upd,
			'' as tj,
			'' as en,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as subdue,
			if(so.customer_id=ms.recipient_id,'',lpad(so.customer_id,6,'0')) as subdonor,
			'' as tjdue,
			'' as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			'' as dm,
			'' as dmdue,
			'' as bm,
			'' as bmdue,
			'' as digidonor,
			'' as digiemail,
			'' as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='39:2'
			and soi.type='M' and (soi.sub_type='P')
			";		
*/						
		$sql = "
			select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			ms.qty as tag1,
			'' as tag2,
			'' as tag3,
			'' as subgiver,
			ms.issue_status as cen,
			'' as pn,
			'' as upd,
			'' as tj,
			'' as en,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as subdue,
			if(so.customer_id<>ms.recipient_id,lpad(so.customer_id,6,'0'),'') as subdonor,
			'' as tjdue,
			'' as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			'' as dm,
			'' as dmdue,
			'' as bm,
			'' as bmdue,
			'' as digidonor,
			'' as digiemail,
			'' as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='39:2'
			and soi.type='M' and (soi.sub_type='P')
			";		
						
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();

		while ($row = $sth->fetch()) {
			insertRecord('P', $row);
		}		

		// both
		$sql = 
			"select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			ms.qty as tag1,
			'' as tag2,
			'' as tag3,
			'' as subgiver,
			ms.issue_status as cen,
			'' as pn,
			'' as upd,
			'' as tj,
			'' as en,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as subdue,
			if(so.customer_id=ms.recipient_id,'',lpad(so.customer_id,6,'0')) as subdonor,
			'' as tjdue,
			'' as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			'' as dm,
			'' as dmdue,
			1 as bm,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as bmdue,
			'' as digidonor,
			ms.digi_email as digiemail,
			'' as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='39:2'
			and soi.type='M' and (soi.sub_type='B')
			";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();

		while ($row = $sth->fetch()) {
			insertRecord('B', $row);
		}		
		
		// digi only
		$sql = 
			"select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			ms.qty as tag1,
			'' as tag2,
			'' as tag3,
			'' as subgiver,
			'' as cen,
			'' as pn,
			'' as upd,
			'' as tj,
			'' as en,
			'' as subdue,
			if(so.customer_id=ms.recipient_id,'',lpad(so.customer_id,6,'0')) as subdonor,
			'' as tjdue,
			'' as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			ms.issue_status as dm,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as dmdue,
			'' as bm,
			'' as bmdue,
			'' as digidonor,
			ms.digi_email as digiemail,
			'' as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='39:2'
			and soi.type='M' and (soi.sub_type='D')
			";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();

		while ($row = $sth->fetch()) {
			insertRecord('D', $row);
		}				
		
		// joc
		$sql = 
			"select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			'' as tag1,
			ms.qty as tag2,
			'' as tag3,
			'' as subgiver,
			'' as cen,
			'' as pn,
			'' as upd,
			ms.issue_status as tj,
			'' as en,
			'' as subdue,
			'' as subdonor,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as tjdue,
			if(so.customer_id=ms.recipient_id,'',lpad(so.customer_id,6,'0')) as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			'' as dm,
			'' as dmdue,
			'' as bm,
			'' as bmdue,
			'' as digidonor,
			'' as digiemail,
			ms.digi_email as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='31:1'
			and soi.type='M' and (soi.sub_type='J')
			";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();
//echo $sql;
		while ($row = $sth->fetch()) {
			insertRecord('J', $row);
		}				
		
		donorOnlyList();

		$db_handle->commit();
	}
	catch (Exception $e) {
		$db_handle->rollback();
	}
	
	function insertRecord($type, $row) {
		global $db_handle;

		// test if record for this customer already exists
		$sql = 'select * from sos2ss where idnumber="' . $row['idnumber'] . '"';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();
		$origRow = $sth->fetch();
		if ($origRow['idnumber'] <> '') {	// it does

//			$delete = false;

			// if new record is newer subdue then update first one
			switch ($type) {
				case 'P': {
					if ($row['subdue'] > $origRow['subdue'])
						$subDue = $row['subdue'];
					else
						$subDue = $origRow['subdue'];
					
					// bulks indicator
					$cen = $row['cen'];
					if ($row['tag1'] > 1)
						$cen = 'j';
					
					$sql = 'update sos2ss set cen="' . $cen . '", subdue="' . $subDue . '", subdonor="' . $row['subdonor'] . '" where idnumber=' . $row['idnumber'];
					break;
				}
				case 'B': {
					if ($row['bmdue'] > $origRow['bmdue'])
						$subDue = $row['bmdue'];
					else
						$subDue = $origRow['bmdue'];

					$sql = 'update sos2ss set bm="' . $row['bm'] . '", bmdue="' . $subDue . '", subdonor="' . $row['subdonor'] . '" where idnumber=' . $row['idnumber'];
					break;
				}
				case 'D': {
					if ($row['dmdue'] > $origRow['dmdue'])
						$subDue = $row['dmdue'];
					else
						$subDue = $origRow['dmdue'];
					
					$sql = 'update sos2ss set dm="' . $row['dm'] . '", dmdue="' . $subDue . '", digidonor="' . $row['digidonor'] . '" where idnumber=' . $row['idnumber'];
					break;
				}
				case 'J': {
					if ($row['tjdue'] > $origRow['tjdue'])
						$subDue = $row['tjdue'];
					else
						$subDue = $origRow['tjdue'];
					
					$sql = 'update sos2ss set tj="' . $row['tj'] . '", tjdue="' . $subDue . '", tjdonor="' . $row['tjdonor'] . '" where idnumber=' . $row['idnumber'];					
					break;
				}
			}
			
							
			if ($type == 'P') {				
				$sql = 'update sos2ss set cen="' . $cen . '", subdue="' . $subDue . '", subdonor="' . $row['subdonor'] . '" where idnumber=' . $row['idnumber'];
			}

			$sth = $db_handle->prepare($sql);
			$status = $sth->execute();
		}
		else {				
			// bulks indicator
			$cen = $row['cen'];
			if ($row['tag1'] > 1)
				$cen = 'j';

			$sql = 
				'insert into sos2ss set
				idnumber=?,
				title=?,
				init=?,
				lname=?,
				address1=?, 
				address2=?, 
				town=?,
				pcode=?,
				state=?,
				cname=?,
				phone=?,
				mailcent=?,
				tag1=?,
				tag2=?,
				tag3=?,
				subgiver=?,
				cen=?,
				pn=?,
				upd=?,
				tj=?,
				en=?,
				subdue=?,
				subdonor=?,
				tjdue=?,
				tjdonor=?,
				last_amended=?,
				stats=?,
				country=?,
				email=?,
				newsub_stats=?,
				start_date=?,
				dm=?,
				dmdue=?,
				bm=?,
				bmdue=?,
				digidonor=?,
				digiemail=?,
				digijnlemail=?				
				';
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array(
				$row['idnumber'],
				$row['title'],
				$row['init'],
				$row['lname'],
				$row['address1'],
				$row['address2'],
				$row['town'],
				$row['pcode'],
				$row['state'],
				$row['cname'],
				$row['phone'],
				$row['mailcent'],
				$row['tag1'],
				$row['tag2'],
				$row['tag3'],
				$row['subgiver'],
				$cen,
				$row['pn'],
				$row['upd'],
				$row['tj'],
				$row['en'],
				$row['subdue'],
				$row['subdonor'],
				$row['tjdue'],
				$row['tjdonor'],
				$row['last_amended'],
				$row['stats'],
				$row['country'],
				$row['email'],
				$row['newsub_stats'],
				$row['start_date'],
				$row['dm'],
				$row['dmdue'],
				$row['bm'],
				$row['bmdue'],
				$row['digidonor'],
				$row['digiemail'],
				$row['digijnlemail']
			));
		}

echo 'insert: ' . json_encode($row) . '<br>';

	}
	
	function donorOnlyList() {
		global $db_handle;
				
		$sql = 'select subdonor from sos2ss where subdonor<>""';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();
		while ($row = $sth->fetch()) {
			$donor = $row['subdonor'];
//			if ($donor != '') {		// donors of any kind only
				
				$sql = 'select idnumber from sos2ss where idnumber=' . $donor;
				$sth2 = $db_handle->prepare($sql);
				$status = $sth2->execute();
				$row2 = $sth2->fetch();
				$found = $row2['idnumber'];
				
echo '<br>looking for: ' . $donor;
				if ($found == '') {	// donor only found
				
					$sql = 'select * from customers where id=' . $donor;
					$sth3 = $db_handle->prepare($sql);
					$status3 = $sth3->execute();
					$row3 = $sth3->fetch();
					$lastName = $row3['last_name'];
					
echo ', missing: ' . $donor . ' ' . $lastName;
					$sql = 'insert into sos2ss set title=?, idnumber=?, cname=?, lname=?, address1=?, address2=?, town=?, country=?, pcode=?, phone=?, email=?';
					$sth4 = $db_handle->prepare($sql);
//echo $sql . '<>';
					$status4 = $sth4->execute(array(
						'',
						$donor,
						$row3['first_name'],
						$lastName,
						$row3['address'],
						$row3['address_2'],
						$row3['city'],
						$row3['country'],
						$row3['postal_code'],
						$row3['phone1'],
						$row3['email1']
					));
				}
//					$found = ' * missing';
//				echo 'looking for ' . $donor . ', found ' . $found .'<br>';
//			}
		}
	}
?>