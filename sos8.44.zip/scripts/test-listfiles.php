<?php
$directory = "./";
$pdffiles = glob($directory . "*.*");

$files = array();

foreach($pdffiles as $pdffile)
{
   $files[] = basename($pdffile);
//   $files[] = "<a href=$pdffile>".basename($pdffile)."</a>";
}

echo json_encode($files);
?>