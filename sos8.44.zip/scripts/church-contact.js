// CONTACTS...

function contact() {
	this.edit = function(id) {
		document.getElementById('contact-panel').overlay = doOverlay(true, 'contact-panel');
		document.getElementById('contact-panel').style.display = 'block';
		document.getElementById('contact-panel').reset();
		this.currentContact = id;
//alert(id)		
//		$('#contact-panel-details').hide();
//		$('#contact-panel-list').hide();
		$('#contact-panel-save').hide();
		$('#contact-panel-save-select').hide();
		
		// setup reference data
		var options = oSettings.provinces;
		fillPicklistWithData('contact-province', options, options);		
		var options = oSettings.countries.split(',');
		fillPicklistWithData('contact-country', options, options);		
		
		if (id == 'new') {
			$('#contact-province').val('');
			$('#contact-country').val(oSettings.country);

			$('#contact-panel-save-select').show();
		}
		else {
			var sql = 'select * from customers c where c.id=' + id;
			execSQL(sql, function(data) {
				var contact = data[0];
				$('#contact-first-name').val(contact.first_name);
				$('#contact-last-name').val(contact.last_name);
				$('#contact-role').val(contact.role);
				$('#contact-phone-1').val(contact.phone1);
				$('#contact-phone-2').val(contact.phone2);
				$('#contact-email').val(contact.email1);
				$('#contact-email-2').val(contact.email2);
				$('#contact-fax').val(contact.fax);
				$('#contact-address').val(contact.address);
				$('#contact-address-2').val(contact.address_2);
				$('#contact-city').val(contact.city);
				$('#contact-province').val(contact.province);
				$('#contact-postal-code').val(contact.postal_code);
				$('#contact-country').val(contact.country);
				$('#contact-notes').val(contact.notes);

				$('#contact-panel-save').show();
			}, false);
		}

		$('#contact-panel-details').show();
		$('#contact-name').focus();
	}

	// close contact dialog
	this.close = function() {
		document.getElementById('contact-panel').style.display = 'none';
		doOverlay(false, document.getElementById('contact-panel').overlay);
	}

	this.createRelationship = function(customerID) {
//		if (!formValidated('contact-panel'))
//			return;

		var sql = 'insert into church_contacts set church_id=' + oChurch.details.id + ', contact_id=' + customerID;
//console.log(sql)
		execSQL(sql, function() {
			oContact.listAllContacts(true);			
//			oContact.close();
			oChurch.listContacts();
			statusMsg('Contact relationship created.');	
			log('EPIC CONTACT UPDATED', oChurch.details.name + ', Contact ID=' + customerID);	
		});
	}

	this.deleteCheck = function(id) {
//console.log(id)		
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to unlink this Contact? <br><br>(The contact will NOT be deleted).", 
			["Yes", "No"],
			[ function() { oContact.remove(id) }, function() {} ]
		);
	}

	this.remove = function(id) {
		var sql = 'delete from church_contacts where id=' + id;
		execSQL(sql, function() {
			oChurch.listContacts();
		});
	}	
	
	this.listAllContacts = function(close) {
		if (close) {
			$('#contact-panel-list').hide();
			$('#contacts-panel').show();
				
//			$('#contact-panel-list').slideToggle(
//				function() { $('#contacts-panel').slideToggle(); }
//			);
		
			return;
		}
		
		$('#contacts-panel').slideToggle(
			function() { $('#contact-panel-list').slideToggle(); }
		);
		
		var b = new cb_browse('contact-all-contacts');
		var sql = "select id, first_name, last_name, address, city, province from customers";
		b.preQuery = 'create temporary table report (index(last_name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 20;
		b.height = 250;
//		b.controls[1] = true;		// print			
		b.columns = ['id', 'first_name', 'last_name', 'address','city', 'province'];
		b.colClass = ['hide', 'con-first-name', 'con-last-name', 'con-list-address','con-list-city','con-list-province'];
		b.colHeadings = ['ID','First name', 'Last name', 'Address','City','Prv'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'last_name';
		b.fetch = function(xxx, yyy, json) {
//console.log(data, json)			
			oContact.createRelationship(json.id);
//			oContact.edit(data[0]);
		}
		b.init();
	}	
	
	this.save = function(mode) {
		var obj = this;
//alert(oChurch.details.id)		
		if (!formValidated('contact-panel'))
			return;

		$.ajax({
			type: 'post',
			url: "scripts/church-contact.php",
			cache: false,
			data: { 
				id: obj.currentContact,
				first_name: $('#contact-first-name').val(),
				last_name: $('#contact-last-name').val(),
				role: $('#contact-role').val(),
				phone1: $('#contact-phone-1').val(),
				phone2: $('#contact-phone-2').val(),
				email1: $('#contact-email').val(),
				email2: $('#contact-email-2').val(),
				fax: $('#contact-fax').val(),
				address: $('#contact-address').val(),
				address_2: $('#contact-address-2').val(),
				city: $('#contact-city').val(),
				province: $('#contact-province').val(),
				postal_code: $('#contact-postal-code').val(),
				country: $('#contact-country').val(),
				notes: $('#contact-notes').val(),
				contact_source: oSettings.epic_default_contact_source,
				churchID: oChurch.details.id
			},
			success: function(result) { 
//console.log(result)
//				if (oChurch.details.id == 'new') {
//					oChurch.setOtherTabs(true);
//					oChurch.details.id = result.id;
//				}
				oChurch.listContacts();
				obj.close();
				statusMsg('Contact details saved.');
				
				if (mode == 'select')
					oContact.createRelationship(result.id);
//				log('EPIC CHURCH DETAILS UPDATED', oChurch.details.name);				
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}
	
}