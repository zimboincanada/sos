<?php 
/**
* @package    CMI Subscription System External API
* @author     Jonny Eggins <web@creation.info>
* @author     Josh Barrie <web@creation.info>
* @version    1.0
* 
*	keys.json file required with json 
*	Example
*	{
*		"host":"http://xxxx",
*		"username":"xxxxx",
*		"password":"xxxxxxx",
*		"token":"xxxxxxxxxxxxxxxx"
*	}
* 
*/
/*
$data = array(
	'federationid' => '446277',
	'issuecount' => 4,
	'qty' => '1',
	'analytics' => array( 
		'sourceid' => '',
		'event_id' => '',
	),
	'pubid' => '1',
	'giverid' => 0
);		
$s2 = new subsApi();			
echo $s2->createSubscription(json_encode($data));
*/
/*
$s2 = new subsApi();			
echo $s2->getSubscription(598180);
*/
/*
$s2 = new subsApi();			
echo json_encode($s2->getCustomerSubscriptions(0));
*/
/*
$s2 = new subsApi();			
echo $s2->getAnalytics();
*/
/*
$data = array('subid' => 598145, 'newqty' => 2);	
$s2 = new subsApi();			
echo $s2->adjustBulks(json_encode($data));
*/

/*
$s2 = new subsApi();			
$result = json_decode($s2->searchCustomersByAccountingId(112492));
if (is_object($result))
	echo ' is obj';
else {
	echo $result;
	echo ' is something else';
}
*/


$data = array(
	'webstoreid' => '',
	'accountingid' => '123456',
	'title' => 'sir',
	'firstname' => 'newton',
	'lastname' => 'isaac',
	'addr1' => '15 address st',
	'addr2' => 'address_2',
	'city' => 'citytown',
	'state' => 'province',
	'postcode' => '123 ABC',
	'country' => 'Azania',
	'email' => ''
);
$s2 = new subsApi('uk-test-keys.json');			
echo json_encode($s2->createCustomer(json_encode($data)));


/*
$data = array(
	'webstoreid' => '',
	'federationid' => '168413',
	'title' => 'Revf',
	'firstname' => 'newton',
	'lastname' => 'isaac',
	'addr1' => '15 address st',
	'addr2' => 'address_2',
	'city' => 'citytown',
	'state' => 'province',
	'postcode' => '123 ABC',
	'country' => 'Azania',
	'email' => 'email1@bob.com'
);
$s2 = new subsApi('uk-test-keys.json');		
echo json_encode($s2->updateCustomer(json_encode($data)));
*/

//$s2 = new subsApi('bob');

class subsApi {
	private $auth; // store the credentials to be used
	private $debug; // store the class setttings

	/**
	 * This is loaded when the class is included;
	 */
	function __construct($s2keys) {
		try {
//			$jsonkeys = file_get_contents("c://wamp//www//sos//3rd-party//s2//keys.json");
			$jsonkeys = file_get_contents("c://wamp//www//sos//3rd-party//s2//" .  $s2keys);
		} catch (Exception $e){

			echo 'Having trouble reading keys.json file<br>'.$e->getMessage();
			die();
		}
		if ($jsonkeys == ''){
			echo 'Having trouble reading keys.json file<br>'.$e->getMessage();
		}
		$keys =  json_decode($jsonkeys);
		$this->auth = $keys;
		$this->debug = 0;
	}
	
	/**
	 * Turn debugging on
	 */
	public function turnDebuggingOn(){
		$this->debug = 1;
	}

	public function autoCreateSubscription($subJson){
	    $url = '/api/subscription/autocreate';
		$method = 'POST';
		return $this->request($url,$method,$subJson);
	}

	/**
	 * get a list of all the publications and there current issues
	 * @return [json]        [return json success/failed message]
	 */
	public function getPublications(){
	    $url = '/api/publications';
	    $method = 'GET';
	    return $this->request($url,$method);
	}

	/**
	 * get a list of all the publications and there current issues
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [json] $json  [description]
	 * @return [json]        [return json success/failed message]
	 */
	public function getAnalytics(){
	    $url = '/api/analytics';
	    $method = 'GET';
	    return $this->request($url,$method);
	}

	/**
	 * Renew as subscription
	 * @param  [json] $json  [description]
	 * @return [json]        [return json success/failed message]
	 */
	public function renewSubscription($json){
	   $obj = json_decode($json);
	   $subid = $obj->subid;
	   $url = '/api/subscription/renew/'.$subid;
	   $method = 'POST';
	   return $this->request($url,$method,$json);
	}

	/**
	 * Update the subscription details (email only)
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [string] $email  [The customers new email for that subscription]
	 * @return [json]        [return json success/failed message]
	 */
	public function updateSubscription($subid,$email){
	   $url = '/api/subscription/update/'.$subid;
	   $json = new stdClass();
	   $json->email = $email;
	   $json = json_encode($json);
	   $method = 'POST';
	   
	   return json_decode($this->request($url,$method,$json));
// CB replaced line below with line above
//	   return $this->request($url,$method,$json);
    }
   
   	/**
	 * Add Comment to subscription
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [string] $comment  [The comment you want to attach to the subscription]
	 * @return [json]        [return json success/failed message]
	 */
	public function  commentSubscription($subid,$comment){
        
		$url = '/api/subscription/comment/'.$subid;
		$json = new stdClass();
		$json->comment = $comment;
		$json = json_encode($json);
		$method = 'POST';

		return json_decode($this->request($url,$method,$json));
// CB replaced line below with line above
//	   return $this->request($url,$method,$json);
    }

    /**
	 * Add a new subscription to a customer *Federation ID required
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [json] $subJson  [Json of the subscription details]
	 * @return [json]        [return json success/failed message]
	 */
	public function createSubscription($subJson){
		$url = '/api/subscription/create';
		$method = 'POST';
		return $this->request($url,$method,$subJson);
	}

	/**
	 * Get subscription details from sub id
	 * @param  [int] $subid [the id of the subscription]
	 * @return [json]        [return json with subs details and history]
	 */
	public function getSubscription($subid){
		$url = '/api/subscription/'.$subid;
		$method = 'GET';
		return json_decode($this->request($url,$method));
// CB replaced line below with line above		
//		return $this->request($url,$method);
	}

	/**
	 * Get subscription details from sub id
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [string] $cancelledReason [Reason why they wish to cancel their subscription]
	 * @return [json]        [return json success/failed message]
	 */
	public function cancelSubscription($subid,$cancelledReason){
		$json = new stdClass();
		$json->reason = $cancelledReason;
		$url = '/api/subscription/cancel/'.$subid;
		$method = 'POST';
		$json = json_encode($json);
		return json_decode($this->request($url,$method,$json));
// CB replaced line below with line above		
//		return $this->request($url,$method,$json);
	}

	/**
	 * Search customers by federation id
	 * @param  [int] $id [federation id]
	 * @return [json]     [return a single customer with their details]
	 */
	public function getCustomerSubscriptions($federationid){
		$url = '/api/customer/'.$federationid.'/subscriptions';
		$method = 'GET';
		return json_decode($this->request($url,$method));
// CB replaced line below with line above
//		return $this->request($url,$method);
	}

	/**
	 * Search customers by federation id
	 * @param  [int] $id [federation id]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersByFederationId($id){
		$url = '/api/customer/search?federationid='.$id;
		$method = 'GET';
		return $this->request($url,$method);
	}

	/**
	 * Search customers by accounting id
	 * @param  [int] $id [accounting id]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersByAccountingId($id){
		$url = '/api/customer/search?accountingid='.$id;
		$method = 'GET';
		return json_decode($this->request($url,$method));
// CB replaced line below with line above
//		return $this->request($url,$method);
	}

	/**
	 * Search customers by webstoreid id
	 * @param  [int] $id [webstoreid id]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersByWebstoreId($id){
		$url = '/api/customer/search?webstoreid='.$id;
		$method = 'GET';
		return $this->request($url,$method);
	}

	/**
	 * Search customers by email
	 * @param  [int] $id [email]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersByEmail($email){
		$url = '/api/customer/search?email='.urlencode($email);
		$method = 'GET';
		return $this->request($url,$method);
	}

	/**
	 * Search customers by fistname or lastname
	 * @param  [string] $firstname [firstname search term]
	 * @param  [string] $lastname [lastname search term]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersViaName($firstname,$lastname){
		$url = '';
		if ($firstname == '' && $lastname == ''){

			echo 'Please enter at least firstname or lastname';
			die();
		} else if ($firstname == '' && $lastname != ''){
			$firstname = urlencode($firstname);
			$lastname = urlencode($lastname);
			$url = '/api/customer/search?lastname='.$lastname;
		} else if ($firstname != '' && $lastname == ''){
			$firstname = urlencode($firstname);
			$url = '/api/customer/search?firstname='.$firstname;
		} else if ($firstname != '' && $lastname != ''){
			$firstname = urlencode($firstname);
			$lastname = urlencode($lastname);
			$url = '/api/customer/search?firstname='.$firstname.'&lastname='.$lastname;
		} 
		

		$method = 'GET';
		return $this->request($url,$method);
	}

	 /**
	 * Create new customer
	 * @param  [json] $subJson  [Json of the subscription details]
	 * @return [json]  [return json success/failed message]
	 */
	public function createCustomer($json){
		$url = '/api/customer/create';
		$return = $this->request($url,'POST',$json);
		return json_decode($return);
// CB replaced the line below with the line above		
//		echo $return;
	}

	/**
	 * Adjust the qty of a sub
	 * @param  [json] $json  [json with subid and newqty]
	 * @return [json]  [return json success/failed message]
	 */
	public function adjustBulks($json){
		$url = '/api/subscription/adjustbulks';
		$return = $this->request($url,'POST',$json);
		return json_decode($return);
// CB replaced line below with line above
//		echo $return;
	}

	/**
	 * Update customer
	 * NOTE: You need to lookup customer first to get federation id and then override the details and submit json
	 * @param  [json] $subJson  [Json of the updated customer details]
	 * @return [json]  [return json success/failed message]
	 */
	public function updateCustomer($details){
		$url = '/api/customer/update';
		$return = $this->request($url,'POST',$details);
		return json_decode($return);
// CB replaced the line below with the line above
//		echo $return;
	}

	/**
	 * Method to control the request to the api, and do checks to make sure calls make sense
	 * @param  [string] $url    [url the is being requested]
	 * @param  [string] $method [POST,PUT,GET]
	 * @param  [json] $json   [json infomation (not required) ]
	 * @return [json]         [Returns what ever the server returns]
	 */
	public function request($url,$method,$json = ''){
		if ($url == ''){
			die('no url given');
		}
		//do checks to make sure requests are correct;
		if ($method != 'GET'){
			if ($json == ''){
				
				$this->displayMessage('failed','Json required on PUT/POST','');
			}
		}
		return $this->curlRequest($this->auth,$url,$method,$json);
	}

	/**
	 * Method for connecting by curling and making requests to the API
	 * @param  [obj] $auth       [contains the credentials to connect to API]
	 * @param  [string] $requestUrl [The URL that the request is going to]
	 * @param  [string] $method     [POST,GET,PUT]
	 * @param  [json] $json       [Json information to pass to API]
	 * @return [json]             [returns a json request]
	 */
	private function curlRequest($auth,$requestUrl,$method,$json){
		
				$requestUrl = $this->auth->host.$requestUrl;
				$ch = curl_init();
				
				if($method == 'PUT') {
					$putString = $json;
				}

				// Headers
				curl_setopt($ch, CURLOPT_HTTPHEADER, array(
					'Authorization: Basic '.base64_encode("$auth->username:$auth->password"),
					'x-subsys-token:'.$auth->token,
					'Content-Type: application/json',
					'Accept: application/json'
					));	

				curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_URL, $requestUrl);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

				if($method == 'PUT') {
					curl_setopt($ch, CURLOPT_PUT, true);
					curl_setopt($ch, CURLOPT_INFILE, $json);
					curl_setopt($ch, CURLOPT_INFILESIZE, strlen($json));
				}

				if($method == 'POST') {

					curl_setopt($ch, CURLOPT_POST, true);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
				}

				// Time Out
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,0);
				curl_setopt($ch, CURLOPT_TIMEOUT, 30); //timeout in seconds

				// Allow any SSL
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				$info = curl_getinfo($ch);
				if ($this->debug == 1){
					echo '<pre>';
					print_r($info);
					echo '<pre>';
				}

				$response = curl_exec($ch);
//echo '>' . json_encode($response) . '<';
				if ($this->debug == 1){
					echo '<pre>';
					print_r($response);
					echo '<pre>';
				}
				if($errno = curl_errno($ch)) {
				    $error_message = curl_strerror($errno);
//				    echo "cURL error ({$errno}):\n {$error_message}";
					// CB - replaced line above with 2 lines below
					$msg = "cURL error ({$errno}):\n {$error_message}";
					$response = json_encode(array('status' => 'failed', 'message' => $msg));
				}
				curl_close($ch);

				return trim($response);
				
	}

	/**
	 * Do a check to make sure it is a valid json
	 * @param  [json] $json [json to test]
	 * @return [json]       [Dies if failes else retunr json]
	 */
	public function checkJson($json){
		if (!is_object($json)){
			$json = json_decode($json); // check to see if it is a true json
			if (json_last_error() != JSON_ERROR_NONE){
				$this->displayMessage('failed','Bad json','Error encoding json');
			}
			try {
				$json = json_encode($json); // make sure it can encode to json
			} catch(Exception $e){
				$this->displayMessage('failed','Bad json',$e->getMessage());
			}
		} else {
			try {
				$json = json_encode($json); // make sure it can encode to json
			} catch(Exception $e){
				$this->displayMessage('failed','Bad json',$e->getMessage());
			}
		}

	}

	/**
	 * [display the errors in json format nicely]
	 * @param  [string] $status      ['success','failed','notice','error']
	 * @param  [string] $messageText [Text you want to pass back]
	 * @param  [string] $message2    [Extras Text you want to pass back]
	 * @param  obj $extra       	[Object of extra info to pass back]
	 * @return [json]              [Dies and returns json]
	 */
	public function displayMessage($status,$messageText,$message2,$extra = ''){
            $message = new stdClass();
            $message->status = $status;
            $message->message = $messageText;
            $message->message2 = $message2;
            if (extra != ''){
                $message = (object) array_merge((array) $message, (array) $extra);
            }
            echo json_encode($message);
            die();
    }
}
?>