<?php
	include "db-conx.php";

	$result = "database update fail";
	$query = $_POST['query'];
		
	switch($query) {		

		case 'createPO': {
			try {
				$db_handle->beginTransaction();

				// get supplier address
				$sql = 'select name, address, shipping_address, po_footer from suppliers where id=?';
				$sth = $db_handle->prepare($sql);			
				$sth->execute(array($_POST['supplierID']));
				$row = $sth->fetch();
				$supplierAddress = $row['name'] . "\n" . $row['address'];

				// insert header info
				$sql = "insert into purchase_orders
							(supplier_id, supplier_address, shipping_address, status, is_smart)
							values (?,?,?,?,?)";
				$sth = $db_handle->prepare($sql);
				$sth->execute(array(
					$_POST['supplierID'], 
					$supplierAddress, 
					$row['shipping_address'], 
					0,		// on order
					1		// smart PO
				));
				$result = $db_handle->lastInsertId();
				
				// populate with all products supplied by current supplier
				$sql = 'insert into purchase_order_items (po_id, sku) select ?, sku from products where type="P" and digital=0 and status=1 and pack=0 and do_not_restock=0 and supplier_id=?';
				$sth = $db_handle->prepare($sql);			
				$sth->execute(array($result, $_POST['supplierID']));

				$db_handle->commit();
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}				
			break;
		}
		
		case 'updateWithCalcs': {
			try {
				$db_handle->beginTransaction();

//				$poNumber = $_POST['poNumber'];
			
				// add the po items
				$poBasketData = $_POST['poBasketData'];
				for ($x=0; $x<sizeof($poBasketData); $x++) {	
					$sql = "update purchase_order_items
								set median_sales=?, min_qty=?, qty_rqd=?, qty_ordered=?
								where id=?";
					$sth = $db_handle->prepare($sql);
					$sth->execute(array(
						$poBasketData[$x][1], 
						$poBasketData[$x][2], 
						$poBasketData[$x][3],
						$poBasketData[$x][4],
						$poBasketData[$x][0] 
					));
				}
				$db_handle->commit();
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}				
			break;
		}

		case 'savePO': {
			try {
				$db_handle->beginTransaction();

				$poNumber = $_POST['poNumber'];

				// insert header info
/*				$sql = "insert into purchase_orders
							(id, supplier_id, supplier_address, shipping_address, status)
							values (?,?,?,?,?)
							on duplicate key update
							id = values(id),
							supplier_id = values(supplier_id),
							supplier_address = values(supplier_address),
							shipping_address = values(shipping_address),				
							status = values(status)";				
				$sth = $db_handle->prepare($sql);
				$sth->execute(array($poNumber, $_POST['supplier_id'], $supplierAddress, $_POST['shipping_address'], $_POST['status']));
				if ($poNumber == '')
					$poNumber = $db_handle->lastInsertId();
*/
				// update PO status
				$sql = "update purchase_orders set status=? where id=?";
				$sth = $db_handle->prepare($sql);
				$sth->execute(array($_POST['status'], $poNumber));

				// clear out existing data, then re-add below
				$sql = "delete from purchase_order_items where po_id=?";
				$sth = $db_handle->prepare($sql);
				$sth->execute(array($poNumber));
				
				// add the po items
				$poBasketData = $_POST['poBasketData'];
				for ($x=0; $x<sizeof($poBasketData); $x++) {	
					$sql = "insert into purchase_order_items
								(po_id, sku, median_sales, min_qty, qty_rqd, qty_ordered)
								values (?,?,?,?,?,?)";
					$sth = $db_handle->prepare($sql);
					$sth->execute(array(
						$poNumber, 
						$poBasketData[$x][0], 
						$poBasketData[$x][1], 
						$poBasketData[$x][2], 
						$poBasketData[$x][3],
						$poBasketData[$x][4]
					));
				}
				$db_handle->commit();
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}				
			break;
		}

	}
	echo json_encode($result);
?>