<?php
/* 	Sends an email

	usage:
	$.post('mail.php', { caller: 'mini', to: 'addressee email', subject: 'Subject of email', message: 'body of email' }, function() {});
	
	params:
	caller = must be 'mini': to prevent unintended running of this script and sending unwanted emails
	to, subject, message = self-evident
*/

//error_reporting(-1);
//ini_set('display_errors', 'On');

$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";	
$headers .= "From: minimax@minimax.com";
mail('c.baines@creation.info', 'test from minimax', 'test message, custard alert', $headers);
die(0);


if ($_POST['caller'] == 'mini') {
	$to = $_POST['to'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];
	$headers = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";	
	$headers .= "From: minimax@minimax.com";
	echo json_encode(mail($to, $subject, $message, $headers));
}
?>