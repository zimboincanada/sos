<?php
//$data = 'this is a drill';
//echo $data;
//$data = str_replace("drill", "banana", $data);
//echo $data;
//die(0);

//echo 'begin';
//$replacements = array('{CHURCH}' => 'Church of the Lukewarm', '{SPEAKER}' => 'Philip Bell');
$replacements = $_POST['mmData'];
$templateName = 'c:/wamp/www/sos/word_templates/' . $_POST['sourceFile'];
$newFile = $_POST['sourceFile'];
//$templateName = 'C:/wamp/www/sos//test-source.docx';

echo mailMerge($templateName, $newFile, $replacements);
//echo 'all done';
//echo json_encode($replacements);

function mailMerge($templateFile, $newFile, $row) {
//echo 'starting MM...';
	if (!copy($templateFile, $newFile)) {		// make a duplicate so we don't overwrite the template
//echo 'NOT copied.';
		return false; 	// could not duplicate template
	}
	
//echo 'copied.';
	$zip = new ZipArchive();
	if ($zip->open($newFile, ZIPARCHIVE::CHECKCONS) !== TRUE) {
//echo 'not a DOCx';
		return false; 	// probably not a docx file
	}

//echo 'replacing...';

	$file = substr($templateFile, -4) == '.odt' ? 'content.xml' : 'word/document.xml';
	$data = $zip->getFromName($file);


//	for ($x=0; $x<sizeof($row); $x++) {
//		$key = 'key';
//		$value = 'value';
//echo '>'.  $key . '-' . $value . '<';
//		$data = str_replace($key, $value, $data);	
//	}

	foreach ($row as $key => $value) {
//echo '<br>>'.  $key . '-' . $value . '<' ;
		$data = str_replace($key, $value, $data);
	}
	$data = str_replace("{CRLF}", "<w:br/>", $data);
	
//$bob = '</w:tab xml:space="preserve">';
//$bob = '<w:tab w:val="left" w:leader="dot" w:pos="1440"/>some text';	// works
//$bob = '&#x9;some text';
	
//	$data = str_replace("{TAB}", $bob, $data);
//$data = str_replace("Person Name", "BobBob", $data);
	
//echo '<br>after=' . $data;
		
	$zip->deleteName($file);
	$zip->addFromString($file, $data);
	$zip->close();
	
	return true;
}
?>