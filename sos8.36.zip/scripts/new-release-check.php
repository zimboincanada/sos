<?php
$fileId = '0BwwA4oUTeiV1UVNwOHItT0xfa2M';
$response = $driveService->files->get($fileId, array(
  'alt' => 'media' ));
$content = $response->getBody()->getContents();
echo 'help';
?>