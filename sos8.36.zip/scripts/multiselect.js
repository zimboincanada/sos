/*
Usage:
	<span id='event-presentation-type' class="cmi-multiselect"></span>

JS:
	// create the ms object, with values for dropdown
	var ms = new cmiMultiSelect('event-presentation-type');
	ms.values = oSettings.presentation_type.split(',');
	ms.texts = oSettings.presentation_type.split(',');
	ms.init();

	...

	$('#event-presentation-type').attr('cmi-multiselect-value); = contains the selected values
*/

function cmiMultiSelect(parent) {

/*	<span id='event-presentation-type' class="cmi-multiselect">
		<div class="cmi-select-box" onclick="showCheckboxes()">
			<select>
				<option>Select an option</option>
			</select>
			<div class="cmi-over-select"></div>
		</div>
		<div id="cmi-checkboxes">
			<label><input type="checkbox" value='bob' onchange='updateDisplay(this)'/>First checkbox</label>
			<label><input type="checkbox" value='larry' onchange='updateDisplay(this)' />Second checkbox</label>
			<label><input type="checkbox" value='moe' onchange='updateDisplay(this)'/>Third checkbox</label>
		</div>
	</span>
*/
//console.log(options)
	var obj = this;
	this.expanded = false;
	this.values = [ 'value1', 'value2' ];		// defaults
	this.texts = [ 'text1', 'text2' ];		// defaults
	this.height = '150px';
	
	this.init = function() {
//var bob = document.getElementById(parent).innerHTML;
//console.log(this.bob)
//console.log('1 -->', $('#event-presentation-type').attr('cmi-multiselect-value'))
		document.getElementById(parent).innerHTML = '';
		
		var div = document.createElement('div');
		document.getElementById(parent).appendChild(div);
		$(div).addClass('cmi-multiselect-select-box');
		$(div).on('click', function() { obj.expanded = false; obj.showCheckboxes() } )
		
		var select = document.createElement('select');
		div.appendChild(select);

		var defaultPrompt = $('#event-presentation-type').attr('cmi-multiselect-value');
		var option = document.createElement('option');
		select.appendChild(option);
		if (defaultPrompt == '')
			defaultPrompt = 'Select an option';
		$(option).html(defaultPrompt);
		obj.selectBox = option;
		
		var div2 = document.createElement('div');
		div.appendChild(div2);
		$(div2).addClass('cmi-multiselect-over-select');
		
		// dropdown options
		var div = document.createElement('div');
		document.getElementById(parent).appendChild(div);	
		this.checkBoxes = div;
		$(div).addClass('cmi-multiselect-checkboxes');
		$(div).css('height', this.height);

		var html = '';
		var checked = '';
		var savedValues = $('#event-presentation-type').attr('cmi-multiselect-value').split(';');
//console.log(savedValues);		
		for (var x in obj.values) {
			checked = savedValues.indexOf(obj.values[x]) == -1 ? '' : 'checked';
			html += '<label><input type="checkbox"' + checked + ' value="' + obj.values[x] + '">' + obj.texts[x] + '</label>';		
		}
		
		$(div, 'input').on('change', function() { obj.updateDisplay() } );
		$(div).html(html);
	}

	this.showCheckboxes = function() {
		$('.cmi-multiselect').on('mouseleave', function() { $(obj.checkBoxes).hide(); expanded = false; });
		
		if (!obj.expanded) {
			obj.checkBoxes.style.display = "inline-block";
			obj.expanded = true;
		} 
		else {
			obj.checkBoxes.style.display = "none";
			obj.expanded = false;
		}
	}

	this.updateDisplay = function() {
		var str = '';
		var els = $(obj.checkBoxes).children("label");
		var isSelection = false;
		
		for (var x=0; x<els.length; x++) {
			var el = $(els[x]).children("input");

			if ($(el).prop('checked')) {
				if (isSelection)
					str += ';' + $(el).val();
				else
					str += $(el).val();
				isSelection = true;
			}
		}

		$('#event-presentation-type').attr('cmi-multiselect-value', str);

		if (!isSelection)
			str = 'Select an option';

		$(obj.selectBox).html(str);
	}

	return this;
}