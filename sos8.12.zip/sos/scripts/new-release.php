<?php
//	include "db-conx.php";
	
	
//	$path = 'c:/wamp/www/';
//	echo rename($path . "sos", $path. "sos123");
//	echo rename_win($path . "sos", $path. "bobbob");
//	die(0);
	
	
/*		$versions = file_get_contents("https://raw.github.com/zimboincanada/sos/master/version-history.txt");
		$split = explode("\n", $versions);

		foreach ($split as $string) {
			echo $string . '<br>';
		}
		
die(0);	
*/
/*
$str = file_get_contents('C:/wamp/www/sos/index.html');
$str =str_replace("8.05", "9.09", $str);
file_put_contents('C:/wamp/www/sos/index.html', $str);			
die(0);
*/
//echo json_encode(backupDatabase('8.05'));
//echo json_encode(rollbackDatabase('8.05'));
//die(0);
	
	switch($_GET['func']) {
		case 'getReleaseInfo': {
			$info = releaseInfo();
			echo json_encode($info);
			break;
		}
		
		case 'execDownload': {
			echo json_encode(execDownload());
			break;
		}
		
		case 'doBackup': {
			echo json_encode(backupDatabase());
			break;
		}
		
		case 'doUnzip': {
			echo json_encode(extractZipFile());
			break;
		}

		case 'rollback': {
			echo json_encode(rollbackDatabase('8.05'));
			break;
		}
	}
	
	function releaseInfo() {
		
		$currentVersion = (float)$_GET['version'];
		$releaseInfo = new stdClass();
		$releaseInfo->isNewRelease = false;

		$versions = file_get_contents("https://raw.github.com/zimboincanada/sos/master/version-history.txt");
		$split = explode("\n", $versions);
		
		foreach ($split as $string) {
			if ((float)$string > $currentVersion) {
				$releaseInfo->isNewRelease = true;
				$releaseInfo->version = $string;
				return $releaseInfo;
			}
		}
		
		return $releaseInfo;
	}

	function execDownload() {
		$result = new stdClass();
		
// Create a curl handle to a non-existing location
//$version = $_GET['versionToGet'];
/*$file = 'https://raw.github.com/zimboincanada/sos/master/sos' . $version . '.zip';
echo $file;

$ch = curl_init($file);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$json = '';
//if( ($json = curl_exec($ch) ) === false)
$json = curl_exec($ch);
echo 'js1=',$json;
//{
 //   echo 'Curl error: ' . curl_error($ch);
//}
//else
//{
 //   echo 'Operation completed without any errors';
//}
echo 'js-',$json;

// Close handle
curl_close($ch);
return;		*/

		error_reporting(0);
		
		try {
			$version = trim($_GET['versionToGet']);
			$success = file_put_contents(
				'C://wamp//www//sos-test//upgrade//sos' . $version . '.zip',
				file_get_contents('https://raw.github.com/zimboincanada/sos/master/sos' . $version . '.zip')
			);

			if ($success == false) {
				$result->success = false;
				$result->message = '0 bytes downloaded: ' . 'https://raw.github.com/zimboincanada/sos/master/sos' . $version . '.zip';
			}
			else
				$result->success = true;
//echo $success;
//echo json_encode($result);
//if (!$result)
//	return 'bad';
//else
//	return 'good';
//die(0);
//		return $result;
		
		}
		catch (Exception $e) {
			$result->success = false;
			$result->message = $e;
		}		
		
		return $result;
	}

	function backupDatabase() {

		$currentVersion = $_GET['currentVersion'];
		$result = new stdClass();
		$result->success = true;

		$folder = 'c:/wamp/www/sos-test/upgrade/';
		$backupFile = $folder . 'sos' . $currentVersion . '.sql';		

		// dump of db to sql text file
		$str = 'c:\wamp\bin\mysql\mysql5.6.17\bin\mysqldump --routines=true --events -u root sos > ' .$backupFile;
		exec($str, $output, $retval);
//echo 'dumping to text file...', $str, ' output=', $output, ' retval=', $retval . '<br>';
		if ($retval != 0) {
			$result->success = false;
			$result->reason = 'Cannot create a file copy of the database.';
//			return $result;		
		}
		
		return $result;
	}
	
	function extractZipFile() {
		$version = trim($_GET['version']);
		$result = new stdClass();
		$result->success = false;
		
		$zip = new ZipArchive;
		$zipFile = 'C:/wamp/www/sos-test/upgrade/sos' . $version . '.zip';
		$res = $zip->open($zipFile);
		if ($res === TRUE) {
			$zip->extractTo('C:/wamp/www/sos-test/upgrade/sos' . $version);
			$zip->close();
			
			// update sos pointer file so that user launches correct version
//			$str = file_get_contents('C:/wamp/www/sos/index.html');
//			$str =str_replace("8.05", "9.09", $str);
//			file_put_contents('C:/wamp/www/sos/index.html', $str);			
			
			$result->success = true;
		} 
		else
			$result->reason = 'Cannot unzip downloaded release: ' . $zipFile;
		
		return $result;
	}
	
	function rollbackDatabase($fromVersion) {

		$result = new stdClass();
		$result->success = true;

		$folder = 'c:/wamp/www/sos/upgrade/';
		$backupFile = $folder . 'sos' . $fromVersion . '.sql';		
$liveDB = 'sos_8.05';
			
		// import previous dump of live data into live sos db
		$str = 'c:\wamp\bin\mysql\mysql5.6.17\bin\mysql --user=root ' . $liveDB . ' < ' . $backupFile;
		$str .= ' 2>&1';
		exec($str, $output, $retval);
//echo 'importing into empty db...', $str;
		
	//	echo json_encode($output) . '<br>';
	//	echo $retval . '<br>';
		
		if ($retval != 0) {
			$result->success = false;
			$result->reason = 'Cannot import backup data into live database.';
		}

		return $result;		
	}
/*
First create the duplicate database:

CREATE DATABASE duplicateddb;
Make sure the user and permissions are all in place and:

 mysqldump -u admin -p originaldb | mysql -u backup -pPassword duplicateddb; 
 */
?>