<?php
//$fileToRestore = $_GET['file'];

//echo json_encode($_POST['test']);
//return;

//$label = $_POST["label"];
//$filename = $label.$_FILES["file2"]["tmp_name"];

$uploaddir = '../uploads/';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
//echo $_FILES['userfile']['tmp_name'];
//echo $uploadfile;
$result = doRestore($uploadfile);

/*if (copy($_FILES['userfile']['tmp_name'], $uploadfile)) {
	$result = doRestore($uploadfile);
}
else {
	$result = new stdClass();
	$result->retval = 1;
	$result->output = ['Failed to upload file.'];
}*/

echo json_encode($result);

function doRestore($backupFile) {	
	$str = 'c:\wamp\bin\mysql\mysql5.6.17\bin\mysql --user=root sos < ' . $backupFile;
	$str .= ' 2>&1';
	
	exec($str, $output, $retval);
	
//	echo json_encode($output) . '<br>';
//	echo $retval . '<br>';
	$result = new stdClass();
	$result->retval = $retval;
	$result->output = $output;
	return $result;
}
?>