<?php
include "db-conx.php";

$id = $_POST['id'];
$churchID = $_POST['churchID'];
$name = $_POST['name'];
$contactID = $_POST['contactID'];
$eventDate = $_POST['eventDate'];
$noWeb = $_POST['noWeb'];
$speaker = $_POST['speaker'];
$bookTable = $_POST['bookTable'];
$attendanceExpected = $_POST['attendanceExpected'];
$address = $_POST['address'];
$city = $_POST['city'];
$county = $_POST['county'];
$postalCode = $_POST['postalCode'];
$region = $_POST['region'];
$accommodationDetails = $_POST['accommodationDetails'];
$attendanceActual = $_POST['attendanceActual'];
$directionDetails = $_POST['directionDetails'];
$gift = $_POST['gift'];
$tourID = $_POST['tourID'];
$notes = $_POST['notes'];
$status = $_POST['status'];
$hostDetails = $_POST['hostDetails'];
$volunteerDetails = $_POST['volunteerDetails'];
$cmiEquipment = $_POST['cmiEquipment'];
$accessTimeDetails = $_POST['accessTimeDetails'];
$presentationType = $_POST['presentationType'];
$webpageID = $_POST['webpageID'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();
	
	$sql = 'insert into events (id, church_id, name, contact_id, event_date, no_web, speaker, attendance_expected, address, city, county, postal_code, region, accommodation_details, book_table, attendance_actual, direction_details, gift, tour_id, notes, status, host_contact_details, volunteer_details, cmi_equipment, access_time_details, presentation_type, webpage_id)
				values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
				on duplicate key
				update church_id=?, name=?, contact_id=?, event_date=?, no_web=?, speaker=?, attendance_expected=?, address=?, city=?, county=?, postal_code=?, region=?, accommodation_details=?, book_table=?, attendance_actual=?, direction_details=?, gift=?, tour_id=?, notes=?, status=?, host_contact_details=?, volunteer_details=?, cmi_equipment=?, access_time_details=?, presentation_type=?, webpage_id=?';
	$sth = $db_handle->prepare($sql);
	$success = $sth->execute(array(
		$id,
		$churchID,
		$name, 
		$contactID, 
		$eventDate, 
		$noWeb,
		$speaker, 
		$attendanceExpected,
		$address, 
		$city, 
		$county, 
		$postalCode, 
		$region, 
		$accommodationDetails, 
		$bookTable, 
		$attendanceActual, 
		$directionDetails, 
		$gift, 
		$tourID, 
		$notes, 
		$status, 
		$hostDetails, 
		$volunteerDetails, 
		$cmiEquipment, 
		$accessTimeDetails, 
		$presentationType,
		$webpageID,
		$churchID,
		$name, 
		$contactID, 
		$eventDate, 
		$noWeb,		
		$speaker, 
		$attendanceExpected,
		$address, 
		$city, 
		$county, 
		$postalCode, 
		$region, 
		$accommodationDetails, 
		$bookTable, 
		$attendanceActual,
		$directionDetails, 
		$gift, 
		$tourID, 
		$notes, 
		$status,
		$hostDetails, 
		$volunteerDetails, 
		$cmiEquipment, 
		$accessTimeDetails,
		$presentationType,
		$webpageID
	));
	
	if ($id == 'new') {
		$id = $db_handle->lastInsertId();
//		addTodoItems($id);
	}
//	else

	$result->sql = $sql;
	$result->success = $success;
	$result->id = $id;
	$result->errorMessage = $sth->errorInfo();
	
	addTalks($id);
	updateTodoItems($id);
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);

function xxxxxxxxxxxxxxxaddTodoItems($eventID) {
	global $db_handle;

//$log = fopen("log.txt", "w") or die("Unable to open file!");

	$d = $db_handle->prepare('select event_todo_items items from settings where id=1');
	$d->execute();
	$d->bindColumn('items', $items);

	$results = array();
    while($row = $d->fetch()) {
        // explode each row and append it to the array.
        $results = array_merge($results, explode(',', $items));
    }

	for ($x=0; $x<sizeof($results); $x++) {
//fwrite('new', $log, $results[$x] . "\n");
		$sql = 'insert into event_todo_items set event_id=?, item=?, complete=0';
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($eventID, $results[$x]));
	}
}

function updateTodoItems($eventID) {
	global $db_handle;

//$log = fopen("log.txt", "w") or die("Unable to open file!");
	$sql = 'delete from event_todo_items where event_id=?';
	$sth = $db_handle->prepare($sql);
	$sth->execute(array($eventID));
//fwrite($log, $status . "  UPDTAE\n");

	$todos = $_POST['eventTodos'];	
	if (sizeof($todos) == 0)
		return;
	
	for ($x=0; $x<sizeof($todos); $x++) {
		$sql = 'insert into event_todo_items set item=?, complete=?, due=?, event_id=?';
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($todos[$x][0], $todos[$x][1], $todos[$x][2], $eventID));
	}
}

function addTalks($eventID) {
	global $db_handle;
	
	$sql = 'delete from event_talks where event_id=?';
	$sth = $db_handle->prepare($sql);
	$sth->execute(array($eventID));
	
	$talks = $_POST['eventTalks'];	
	if (sizeof($talks) == 0)
		return;
	
	for ($x=0; $x<sizeof($talks); $x++) {
		$talk = $talks[$x][0];
		$time = $talks[$x][1];
		$daily = $talks[$x][2];
		
		$sql = 'insert into event_talks set event_id=?, talk=?, time=?, daily=?';
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($eventID, $talk, $time, $daily));
	}
}
?>