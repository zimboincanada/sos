<?php
	/* 	
	
	
	*/

//	echo 'make sure this is not on live database';
//	die(0);
	
	set_time_limit(500);
	$server = "localhost";
	$database = "sos";
	$username = "root";
	$password = "";
	$db_handle = new PDO("mysql:host=$server;dbname=$database", $username, $password);
	
	try {
		
//exceptionList();
//intlSubsData();
//die(0);		
		
		$db_handle->beginTransaction();		
		
		$sql = "CREATE TABLE IF NOT EXISTS `s2add2` (
		  `sos_id` varchar(6) NOT NULL DEFAULT '',
		  `address_2` varchar(50) NOT NULL DEFAULT '',
		  PRIMARY KEY (`sos_id`),
		  KEY `idnumber` (`sos_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();
//die(0);		
		
		$sql = "truncate s2add2";
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();

		
			
		$sql = 'INSERT INTO s2add2 (sos_id) SELECT idnumber FROM sos2ss';					
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();

		$sql = 'update s2add2 set address_2=(select address_2 from customers where id=sos_id)';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();
		
//		while ($row = $sth->fetch()) {
//			insertRecord('P', $row);
//		}		
	
		$db_handle->commit();
	}
	catch (Exception $e) {
		$db_handle->rollback();
	}
	
	function insertRecord($type, $row) {
		global $db_handle;

			$sql = 
				'insert into s2add2 set
				sos_id=?,
				address_2=?
				';
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array(
				$row['idnumber'],
				$row['title']
			));

//echo 'insert: ' . json_encode($row['idnumber'] . $row['digiemail']) . '<br>';

	}	
?>