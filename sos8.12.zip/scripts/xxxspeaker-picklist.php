<?php
include "db-conx.php";

//	$result = "database update fail";

$picklistID = $_POST['picklistID'];
$speakerID = $_POST['speakerID'];
$eventDate = $_POST['eventDate'];
$eventName = $_POST['eventName'];
$picklistData = $_POST['picklistData'];

try {
	$db_handle->beginTransaction();

	// header stuff
	$sql = 'insert into picklists (id, speaker_id, event_date, event_name)
				values (?,?,?,?)
				on duplicate key
				update speaker_id=?, event_date=?, event_name=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$picklistID, 
		$speakerID, 
		$eventDate,
		$eventName,
		$speakerID, 
		$eventDate,
		$eventName
	));
	
	if ($picklistID == '**new*')
		$picklistID = $db_handle->lastInsertId();		
	
	$sql = 'delete from picklist_items where picklist_id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array($picklistID));
	
	for ($x=0; $x<sizeof($picklistData); $x++) {
		
		$sku = $picklistData[$x][0];
		$qty1 = $picklistData[$x][4];
		$qty2 = $picklistData[$x][5];
//			$templateID = $picklistData[$x][5];
		
		$sql = "insert into picklist_items set picklist_id=?, sku=?, qty_1=?, qty_2=?";					
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array(
			$picklistID,
			$sku,
			$qty1,
			$qty2
		));		
	}
	
	$db_handle->commit();
//		$result = 'success';
}
catch (Exception $e) {
	$db_handle->rollback();
}
	
echo json_encode($picklistID);
?>