<?php
include "db-conx.php";

//$path = "../upgrade/sos8.12.zip";
$sosFolder = 'c:/wamp/www/sos';
$sosUpgradeFolder = 'c:/wamp/www/sos-upgrade';
/*
$zip = new ZipArchive();
if ($zip->open($path) === true) {
    for($i = 0; $i < $zip->numFiles; $i++) {
        $filename = $zip->getNameIndex($i);
        $fileinfo = pathinfo($filename);
echo $fileinfo['dirname'], $fileinfo['filename'], '<br>';
//        copy("zip://".$path."#".$filename, "/myDestFolder/".$fileinfo['basename']);
    }                  
    $zip->close();                  
}

die(0);
*/
	
/*	$pathFrom = 'c:/wamp/www/sos-test';
	$pathTo = 'c:/wamp/www/sos-test-123';
	echo rename($pathFrom, $pathTo);
//	echo copy_directory($pathFrom, $pathTo);
//	echo rename_win($pathFrom, $pathTo);
	die(0);
	
*/	

function xxxxxxxxxxxxxxcopy_directory($src,$dst) {
    $dir = opendir($src);
    mkdir($dst);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            if ( is_dir($src . '/' . $file) ) {
                recurse_copy($src . '/' . $file,$dst . '/' . $file);
            }
            else {
                copy($src . '/' . $file,$dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}	
	
function xxxxxxxxxxxxxrename_win($oldfile,$newfile) {
    if (!rename($oldfile,$newfile)) {
        if (copy ($oldfile,$newfile)) {
            unlink($oldfile);
            return TRUE;
        }
        return FALSE;
    }
    return TRUE;
}	
	
/*		$versions = file_get_contents("https://raw.github.com/zimboincanada/sos/master/version-history.txt");
		$split = explode("\n", $versions);

		foreach ($split as $string) {
			echo $string . '<br>';
		}
		
die(0);	
*/
/*
$str = file_get_contents('C:/wamp/www/sos/index.html');
$str =str_replace("8.05", "9.09", $str);
file_put_contents('C:/wamp/www/sos/index.html', $str);			
die(0);
*/
//echo json_encode(backupDatabase('8.05'));
//echo json_encode(rollbackDatabase('8.05'));
//die(0);
	
	switch($_GET['func']) {
		case 'getReleaseInfo': {
			$info = releaseInfo();
			echo json_encode($info);
			break;
		}
		
		case 'execDownload': {
			echo json_encode(execDownload());
			break;
		}
		
		case 'doBackup': {
			echo json_encode(backupDatabase());
			break;
		}
		
		case 'doUnzip': {
			echo json_encode(extractZipFile());
			break;
		}

		case 'moveApp': {
			echo json_encode(moveApp());
			break;
		}
		
		case 'dbChanges': {
			echo json_encode(applyDBChanges());
			break;
		}
		
		case 'rollback': {
			echo json_encode(rollbackDatabase('8.05'));
			break;
		}
	}
	
	function releaseInfo() {
		
		$currentVersion = (float)$_GET['version'];
		$releaseInfo = new stdClass();
		$releaseInfo->isNewRelease = false;

		$versions = file_get_contents("https://raw.github.com/zimboincanada/sos/master/version-history.txt");
		$split = explode("\n", $versions);
		
		foreach ($split as $string) {
			if ((float)$string > $currentVersion) {
				$releaseInfo->isNewRelease = true;
				$releaseInfo->version = $string;
				return $releaseInfo;
			}
		}
		
		return $releaseInfo;
	}

	function execDownload() {
		global $sosFolder, $sosUpgradeFolder;
		
		if (!is_dir($sosUpgradeFolder)){
			// directory does not exist, so lets create it.
			mkdir($sosUpgradeFolder);
		}		
		
		$version = trim($_GET['versionToGet']);
		$target = 	$sosUpgradeFolder . '/sos' . $version . '.zip';
				
		$result = new stdClass();
		error_reporting(0);
		
		try {
			$version = trim($_GET['versionToGet']);
			$success = file_put_contents(
				$target,
				file_get_contents('https://raw.github.com/zimboincanada/sos/master/sos' . $version . '.zip')
			);

			if ($success == false) {
				$result->success = false;
				$result->reason = '0 bytes downloaded: ' . 'https://raw.github.com/zimboincanada/sos/master/sos' . $version . '.zip';
			}
			else
				$result->success = true;		
		}
		catch (Exception $e) {
			$result->success = false;
			$result->reason = $e;
		}		
		
		return $result;
	}

	function backupDatabase() {
		global $sosFolder, $sosUpgradeFolder;		

		$currentVersion = $_GET['currentVersion'];
		$result = new stdClass();
		$result->success = true;

		$backupFile = $sosUpgradeFolder . '/sos' . $currentVersion . '.sql';		

		// dump of db to sql text file
		$str = 'c:\wamp\bin\mysql\mysql5.6.17\bin\mysqldump --routines=true --events -u root sos > ' .$backupFile;
		exec($str, $output, $retval);
//echo 'dumping to text file...', $str, ' output=', $output, ' retval=', $retval . '<br>';
		if ($retval != 0) {
			$result->success = false;
			$result->reason = 'Cannot create a file copy of the database. ' . $backupFile;
		}
		
		return $result;
	}
	
	function extractZipFile() {
		global $sosFolder, $sosUpgradeFolder;		
		
		$version = trim($_GET['version']);
		$result = new stdClass();
		$result->success = false;
		
		$zip = new ZipArchive();
		$zipFile = $sosUpgradeFolder . '/sos' . $version . '.zip';
		$res = $zip->open($zipFile);
		if ($res === TRUE) {
			$zip->extractTo($sosUpgradeFolder . '/sos' . $version);
			$zip->close();
						
			$result->success = true;
		} 
		else
			$result->reason = 'Cannot unzip downloaded release: ' . $zipFile;
		
		return $result;
	}
	
	function moveApp() {
		global $sosFolder, $sosUpgradeFolder;			
		error_reporting(0);		
			
		$currentVersion = trim($_GET['currentVersion']);
		$newVersion = trim($_GET['newVersion']);
		$result = new stdClass();
		$result->success = true;

//		$folder = 'c:/wamp/www/';
		$from = trim($sosFolder);
//$from = 'c:/wamp/www/yalbc';
		$to = $sosFolder . $currentVersion;
//$to = 'c:/wamp/www/yalbcbob';

//		$retval = rename($from, $to);		
		$success = moveFolder($from, $to);		
		
		if (!$success) {
			$result->success = false;
			$result->reason = 'Cannot move current version to backup: ' . $from . ' > ' . $to;
			return $result;
		}

		$from = $sosUpgradeFolder . '/sos' . $newVersion;
		$to = $sosFolder;

		$retval = rename($from, $to);		
		
		if ($retval != 1) {
			$result->success = false;
			$result->reason = 'Cannot move new version to live area: ' . $from . ' > ' . $to;
		}
		
		return $result;
	}	
	
	function applyDBChanges() {
		global $sosFolder, $sosUpgradeFolder, $db_handle;	
		error_reporting(0);				
			
//		$currentVersion = trim($_GET['currentVersion']);
		$newVersion = trim($_GET['version']);
		$result = new stdClass();
		$result->success = true;

//		$from = trim($sosFolder);
//		$to = $sosFolder . $currentVersion;

		$file = $sosUpgradeFolder . '/sos' . $newVersion . '/dbchanges.txt';
		$sql = file_get_contents($file);
		
		if ($sql == false) {
			$result->success = false;
			$result->reason = 'Cannot read database changes file: ' . $file;
			return $result;
		}
		
//		$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
		$st = $db_handle->prepare($sql);
		$result->reason = $st->execute();	
		
		
//		if ($retval != 1) {
//			$result->success = false;
//			$result->reason = 'Cannot move new version to live area: ' . $from . ' > ' . $to;
//		}
		
		return $result;
	}	
	
	function moveFolder($src, $dest){

		// If source is not a directory stop processing
		if(!is_dir($src)) return false;

		// If the destination directory does not exist create it
		if(!is_dir($dest)) { 
			if(!mkdir($dest)) {
				// If the destination directory could not be created stop processing
				return false;
			}    
		}

		// Open the source directory to read in files
		$i = new DirectoryIterator($src);
		foreach($i as $f) {
			if($f->isFile()) {
				rename($f->getRealPath(), "$dest/" . $f->getFilename());
			} else if(!$f->isDot() && $f->isDir()) {
				moveFolder($f->getRealPath(), "$dest/$f");
	//            rmdir($f->getRealPath());
			}
		}
		rmdir($src);
		
		return true;
	}
	
	function xxxxxxxxxxxxxxxrollbackDatabase($fromVersion) {

		$result = new stdClass();
		$result->success = true;

		$folder = 'c:/wamp/www/sos/upgrade/';
		$backupFile = $folder . 'sos' . $fromVersion . '.sql';		
$liveDB = 'sos_8.05';
			
		// import previous dump of live data into live sos db
		$str = 'c:\wamp\bin\mysql\mysql5.6.17\bin\mysql --user=root ' . $liveDB . ' < ' . $backupFile;
		$str .= ' 2>&1';
		exec($str, $output, $retval);
//echo 'importing into empty db...', $str;
		
	//	echo json_encode($output) . '<br>';
	//	echo $retval . '<br>';
		
		if ($retval != 0) {
			$result->success = false;
			$result->reason = 'Cannot import backup data into live database.';
		}

		return $result;		
	}
/*
First create the duplicate database:

CREATE DATABASE duplicateddb;
Make sure the user and permissions are all in place and:

 mysqldump -u admin -p originaldb | mysql -u backup -pPassword duplicateddb; 
 */
?>