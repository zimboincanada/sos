//window.onbeforeunload = function() { return confirmExit(); }
var oChurch = new church();

function xxxxxxxxxxxxconfirmExit() {
	if (oChurch.unsavedEvent)
		return 'There are unsaved changes.';
}

function church() {
	this.init = function(fromForm, churchID) {
		var obj = this;
		this.eventMode = fromForm;
		
		$("#event-talks, #event-todo-items").sortable();		// drag and drop
		
		$("#event-talks").on('sortout', function() {
			obj.singleSpeakerCheck();
		});
				
		if (this.eventMode  == 'church') {
			var options = oSettings.church_status.split(',');
			fillPicklistWithData('church-status', options, options);
			var churchID = getURLParameter('church');
			
			var options = oSettings.regions.split(',');
			fillPicklistWithData('church-region', options, options);			
		}

		if (this.eventMode  == "church") {
			oChurch.setupDetails(churchID);

			if (churchID == 'new')
				this.setOtherTabs(false);
			this.showTab(1);
		}
		
		this.loadPicklists(churchID);

		tinymce.init({ 
			selector: '#event-document-text-edit',
			theme: "modern",
			plugins: [
				"advlist autolink lists link image charmap print preview hr anchor pagebreak",
				"searchreplace wordcount visualblocks visualchars code fullscreen",
				"insertdatetime media nonbreaking save table contextmenu directionality",
				"emoticons template paste textcolor"
			],
			toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
			toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
			image_advtab: true,
			height: 400
		});	
	}

	this.loadPicklists = function(churchID) {
		var options = oSettings.event_status.split(',');
		fillPicklistWithData('event-status', options, options);
		var options = oSettings.event_source.split(',');
		fillPicklistWithData('event-source', options, options);
		var options = oSettings.presentation_type.split(',');
		fillPicklistWithData('event-presentation-type', options, options);
		var options = oSettings.regions.split(',');
		fillPicklistWithData('event-region', options, options);					

		var sql = 'select id, concat(left(short_name, 20), " [", start_date, "]") as name from tours where end_date>="' + today() + '" order by name';
		execSQL(sql, function(data) {
			var options = [], values = [];
			for (var x in data) {
				values.push(data[x].id);
				options.push(data[x].name);
				
			}
			fillPicklistWithData('event-tours', values, options);
$('option').mouseover(function(e) {
    var $target = $(e.target);
    if($target.is('option')) {
        console.log('yeah!');
    };
})	

		});
		
		var sql = 'select id, name from contacts where church_id=' + churchID;
		execSQL(sql, function(data) {
			var options = [], values=[];
			for (var x in data) {
				values.push(data[x].id);
				options.push(data[x].name);
			}
			fillPicklistWithData('event-contact', values, options);
		});
				
		var sql = 'select concat(first_name, " ", last_name) as name from customers where speaker=1';
		execSQL(sql, function(data) {
			var options = [];
			for (var x in data)
				options.push(data[x].name);
			fillPicklistWithData('event-speakers-list', options, options);
		});		
	}
	
	this.showTab = function(tab) {
	
		this.loadPicklists(oChurch.details.id);
		$('.tab').removeClass('active');
		$('#tab-' + tab).addClass('active');

		$('.tab-content').hide();
		$('#tab-' + tab + '-content').show();

		if (tab == 2)
			this.listContacts();
		if (tab == 3)
			this.listEvents();
		if (tab == 4)
			this.listContactHistory();
	}		

	this.setOtherTabs = function(show) {
		if (show) {
			$('#tab-2').show();
			$('#tab-3').show();
			$('#tab-4').show();
		}
		else {
			$('#tab-2').hide();
			$('#tab-3').hide();
			$('#tab-4').hide();
		}
	}		
	
	this.setupDetails = function(id) {
		var sql = 'select * from churches where id=' + id;
		execSQL(sql, function(data) {

			if (id == 'new') {
				oChurch.details = {};
				oChurch.details.id = 'new';
				$('#church-name').val('');
				$('#church-address').val('');
				$('#church-city').val('');
				$('#church-county').val('');
				$('#church-postal-code').val('');
				$('#church-region').val('');
				$('#church-phone').val('');
				var option = $("#church-status option:first").text();
				$('#church-status').val(option);
				$('#church-notes').val('');
			}
			else {
				oChurch.details = data[0];
				$('#church-name').val(oChurch.details.name);
				$('#church-address').val(oChurch.details.address);
				$('#church-city').val(oChurch.details.city);
				$('#church-county').val(oChurch.details.county);
				$('#church-postal-code').val(oChurch.details.postal_code);
				$('#church-region').val(oChurch.details.region);
				$('#church-phone').val(oChurch.details.phone);
				$('#church-status').val(oChurch.details.status);
				$('#church-notes').val(oChurch.details.notes);
			}	

			$(document).attr("title", oChurch.details.name);		// chrome tab name		
		}, false);	
	}

	this.saveDetails = function() {
		if (!formValidated('tab-1-content'))
			return;

		oChurch.copyElementsToObject();

		$.ajax({
			type: 'post',
			url: "scripts/church.php",
			cache: false,
			data: { 
				churchData: JSON.stringify(oChurch.details)
			},
			success: function(result) { 
				if (oChurch.details.id == 'new') {
					oChurch.setOtherTabs(true);
					oChurch.details.id = result.id;
				}
				statusMsg('Church details saved.');
				
				log('MINIMAX CHURCH DETAILS UPDATED', oChurch.details.name);				
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}

	this.copyElementsToObject = function() {
		oChurch.details.name = $('#church-name').val();
		oChurch.details.address = $('#church-address').val();
		oChurch.details.city = $('#church-city').val();
		oChurch.details.county = $('#church-county').val();
		oChurch.details.postal_code = $('#church-postal-code').val();
		oChurch.details.region = $('#church-region').val();
		oChurch.details.phone = $('#church-phone').val();
		oChurch.details.status = $('#church-status').val();
		oChurch.details.notes = $('#church-notes').val();
	}
	
	this.merge = function() {
		
		document.getElementById('merge-form').overlay = doOverlay(true, 'merge-form');
		document.getElementById('merge-form').style.display = 'block';
		
		var b = new cb_browse('merge-form-data');
		var sql = "select * from churches where id<>" + oChurch.details.id;		// cannot merge with itself
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 350;
		b.controls[1] = true;		// print			
		b.columns = ['id','name','address','city'];
		b.colClass = ['hide','merge-name','merge-address'];
		b.colHeadings = ['ID','Name','Address','City'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'name';
		b.fetch = function(data) {
			oChurch.confirmMerge(data[0]);
		}
		b.init();
	}
	
	this.confirmMerge = function(duplicateID) {
		confirmBox(
			"CONFIRM",
			"Are you sure you want to continue?", 
			["Yes-merge the churches", "No"],
			[ function() { oChurch.executeMerge(duplicateID) }, function() {} ]
		);		
	}
	
	this.executeMerge = function(duplicateID) {
		$.ajax({
			type: 'post',
			url: "scripts/merge-church.php",
			cache: false,
			data: { 
				primaryID: oChurch.details.id,
				duplicateID: duplicateID
			},
			success: function(result) { 
				oChurch.closeMerge();
				statusMsg('Merge complete.');
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}
	
	this.closeMerge = function() {
		document.getElementById('merge-form').style.display = 'none';
		doOverlay(false, document.getElementById('merge-form').overlay);
	}	

	// CONTACTS...
	
	this.listContacts = function() {
		var b = new cb_browse('contacts');
		var sql = "select * from contacts where church_id=" + oChurch.details.id;
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print			
		b.columns = ['id','name','role','phone_1','email'];
		b.colClass = ['hide','con-name','con-role','con-phone','con-email'];
		b.colHeadings = ['ID','Name','Role','Phone 1','Email 1'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'name';
		b.deleteFn = [true, function(data) { oChurch.deleteContactCheck(data[0]) } ];				
		b.fetch = function(data) {
			oChurch.editContact(data[0]);
		}
		b.init();
	}

	this.editContact = function(id) {
		document.getElementById('contact-panel').overlay = doOverlay(true, 'contact-panel');
		document.getElementById('contact-panel').style.display = 'block';
		document.getElementById('contact-panel').reset();
		this.currentContact = id;

		if (id == 'new') {
			$('#contact-name').val('');
			$('#contact-role').val('');
			$('#contact-phone-1').val('');
			$('#contact-phone-2').val('');
			$('#contact-email').val('');
			$('#contact-email-2').val('');
			$('#contact-address').val('');
			$('#contact-notes').val('');
		}
		else {
			var sql = 'select * from contacts where id=' + id;
			execSQL(sql, function(data) {
				var contact = data[0];
				$('#contact-name').val(contact.name);
				$('#contact-role').val(contact.role);
				$('#contact-phone-1').val(contact.phone_1);
				$('#contact-phone-2').val(contact.phone_2);
				$('#contact-email').val(contact.email);
				$('#contact-email-2').val(contact.email_2);
				$('#contact-address').val(contact.address);
				$('#contact-notes').val(contact.notes);
			});
		}

		$('#contact-name').focus();
	}

	// close contact dialog
	this.closeContact = function() {
		document.getElementById('contact-panel').style.display = 'none';
		doOverlay(false, document.getElementById('contact-panel').overlay);
	}

	this.saveContact = function() {
		if (!formValidated('contact-panel'))
			return;

		$.ajax({
			type: 'post',
			url: "scripts/contact.php",
			cache: false,
			data: { 
				id: this.currentContact,
				name: $('#contact-name').val(),
				role: $('#contact-role').val(),
				phone1: $('#contact-phone-1').val(),
				phone2: $('#contact-phone-2').val(),
				email: $('#contact-email').val(),
				email2: $('#contact-email-2').val(),
				address: $('#contact-address').val(),
				notes: $('#contact-notes').val(),
				churchID: oChurch.details.id
			},
			success: function(result) { 
				oChurch.closeContact();
				oChurch.listContacts();
				statusMsg('Contact details saved.');
				log('MINIMAX CONTACT UPDATED', oChurch.details.name + ', name=' + $('#contact-name').val());				
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}
	
	this.deleteContactCheck = function(id) {
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to delete this Contact?", 
			["Yes", "No"],
			[ function() { oChurch.deleteContact(id) }, function() {} ]
		);
	}
	
	this.deleteContact = function(id) {
		var sql = 'delete from contacts where id=' + id;
		execSQL(sql, function() {
			oChurch.listContacts();
		});
	}	

	// EVENTS........
	
	this.listEvents = function() {
		var b = new cb_browse('events');
		var sql = "select *, (select group_concat(speaker) from event_talks where event_id=e.id) as speakers, (select group_concat(talk) from event_talks where event_id=e.id) as talks from events e where church_id=" + oChurch.details.id;
		b.preQuery = 'create temporary table report (index(event_date)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print
		b.columns = ['id','event_date','speakers','talks','attendance_actual','status'];
		b.colClass = ['hide','ev-date','ev-speaker','ev-talk','ev-attendance','ev-status'];
		b.colHeadings = ['ID','Event date','Speaker','Talk','Attendance (actual)','Status'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'event_date';
		b.sortReverse = true;
		b.deleteFn = [true, function(data) { oChurch.deleteEventCheck(data[0]) } ];		
		b.fetch = function(data) {
			oChurch.editEvent(data[0]);
		}
		b.init();
		oChurch.events = b;
	}
	
	this.editEvent = function(id) {
		var obj = this;
		oChurch.unsavedEvent = false;
		this.eventTodoItemsCreated = false;
		$('#event-panel').on('change', function() {
			oChurch.unsavedEvent = true;
		});
		
		document.getElementById('event-panel').overlay = doOverlay(true, 'event-panel');
		document.getElementById('event-panel').style.display = 'block';
		this.currentEvent = id;
		$('#event-church-name').html(oChurch.details.name);
		$('#event-talks').html('');

		if (id == 'new') {
			$('#event-name').val('');
			$('#event-contact').val('');
			$('#event-address').val('');
			$('#event-city').val('');
			$('#event-county').val('');
			$('#event-postal-code').val('');
			$('#event-region').val('');
			$('#event-use-church-address').prop('checked', false);
			$('#event-phone').val($('#church-phone').val());
			$('#event-date').val('');
			$('#event-date-to').val('');
			$('#event-no-web').prop('checked', false);
			$('#event-single-speaker').prop('checked', true);
			$('#event-book-table').prop('checked', true);
			$('#event-attendance-expected').val('');
			$('#event-attendance-actual').val('');
			$('#event-attendance-actual-u18').val('');
			$('#event-accommodation-details').val('');
			$('#event-direction-details').val('');
			$('#event-gift').val('');
			$('#event-gift-other').val('');
			$('#event-is-tour').prop('checked', false);
			$('#event-notes').val('');
			var option = $("#event-status option:first").text();
			$('#event-status').val(option);
			$('#event-source').val(option);
			$('#event-host-details').val('');
			$('#event-volunteer-details').val('');
			$('#event-cmi-equipment').val('');
			$('#event-access-time-details').val('');
			$('#event-presentation-type').val('');
			$('#event-webpage-id').val('');
			$('#event-created-date').html(today());
			
			oChurch.addEventTalk('', '', '', false);		// need at least 1 talk
		}
		else {
			var sql = 'select * from events where id=' + id;
			execSQL(sql, function(data) {
				var event = data[0];

				$('#event-name').val(event.name);
				$('#event-contact').val(event.contact_id);
				$('#event-address').val(event.address);
				$('#event-city').val(event.city);
				$('#event-county').val(event.county);
				$('#event-postal-code').val(event.postal_code);
				$('#event-region').val(event.region);
				$('#event-use-church-address').prop('checked', event.use_church_address == 1);
				$('#event-phone').val(event.phone);
				$('#event-date').val(event.event_date);
				$('#event-date-to').val(event.event_date_to);
				$('#event-no-web').prop('checked', event.no_web == 1);
				$('#event-single-speaker').prop('checked', event.single_speaker == 1)
				$('#event-book-table').prop('checked', event.book_table == 1)
				$('#event-attendance-expected').val(event.attendance_expected);
				$('#event-attendance-actual').val(event.attendance_actual);
				$('#event-attendance-actual-u18').val(event.attendance_actual_u18);
				$('#event-accommodation-details').val(event.accommodation_details);
				$('#event-direction-details').val(event.direction_details);
				$('#event-gift').val(event.gift);
				$('#event-gift-other').val(event.gift_other);
				$('#event-tours').val(event.tour_id == 0 ? 1 : event.tour_id);
				$('#event-is-tour').prop('checked', event.tour_id > 0);
				$('#event-notes').val(event.notes);
				$('#event-status').val(event.status);
				$('#event-source').val(event.source);
				$('#event-host-details').val(event.host_contact_details);
				$('#event-volunteer-details').val(event.volunteer_details);
				$('#event-cmi-equipment').val(event.cmi_equipment);
				$('#event-access-time-details').val(event.access_time_details);
				$('#event-presentation-type').val(event.presentation_type);
				$('#event-webpage-id').val(event.webpage_id);
				$('#event-created-date').html(event.created_date.substr(0, 10));

			}, false);
			
			// add event talks
			this.getEventTalks(id);		
			this.singleSpeakerCheck();

			// build todo list for this event
			this.getEventTodoItems(id);						
		}
		
		if ($('#event-is-tour').prop('checked'))
			$('#event-tours').show();
		else
			$('#event-tours').hide();
		
		$('#event-is-tour').on('change', function() {
			if ($('#event-is-tour').prop('checked'))
				$('#event-tours').show();
			else
				$('#event-tours').hide();
		});
		
		global.setTabActive('event-tab-1', 'event-panel-1');
		$("#event-save-btn").show();
	}

	this.listEventSpeakerTalks = function(speaker) {
		var sql = 'select title from talks t, customers c where t.speaker_id=c.id and concat(c.first_name," ",c.last_name)="' + speaker + '" and c.speaker=1';
		execSQL(sql, function(data) {
			var options = [];
			for (var x in data)
				options.push(data[x].title);
			fillPicklistWithData('event-talk-list', options, options);
		});
	}
	
	this.getEventTalks = function(eventID) {
		var sql = 'select * from event_talks where event_id=' + eventID;
		execSQL(sql, function(data) {
			for (var x in data) {
				oChurch.addEventTalk(data[x].speaker, data[x].talk, data[x].time, (data[x].daily == 1));
			}
		}, false);
	}

	this.deleteEventCheck = function(id) {
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to delete this Event?", 
			["Yes", "No"],
			[ function() { oChurch.deleteEvent(id) }, function() {} ]
		);
	}
	
	this.deleteEvent = function(id) {
		var sql = 'delete from events where id=' + id;
		execSQL(sql, function() {
			oChurch.events.refreshData();
		});
	}
	
	this.closeEvent = function() {
		if (oChurch.unsavedEvent) {		
			confirmBox(
				"ATTENTION", 
				"You made changes but haven't saved them.", 
				["Back to Edit", "OK, lose the changes"],
				[ function() {}, function() {				
					document.getElementById('event-panel').style.display = 'none';
					doOverlay(false, document.getElementById('event-panel').overlay);
				} ]
			);		
		}
		else {
			document.getElementById('event-panel').style.display = 'none';
			doOverlay(false, document.getElementById('event-panel').overlay);
		}
	}

	this.saveEvent = function() {
		if (!formValidated('event-panel'))
			return;
			
		var eventTalks = [];
		var talks = $('#event-talks').children();
		for (var x=0; x<talks.length; x++) {
			var speaker = talks[x].getElementsByClassName('event-speaker')[0].value;
			var talk = talks[x].getElementsByClassName('event-talk')[0].value;
			var time = talks[x].getElementsByClassName('event-time')[0].value;
			var daily = talks[x].getElementsByClassName('event-daily')[0].checked;
			eventTalks[x] = [speaker, talk, time, (daily ? 1 : 0)];
		}
		
		if (this.currentEvent == 'new')
			this.createEventTodoItems();		

		var eventTodos = [];
		var todos = $("#event-todo-items").children();
		for (var x=0; x<todos.length; x++) {
			var item = todos[x].getElementsByClassName("event-todo-item")[0].value;
			var complete = todos[x].getElementsByClassName("event-todo-complete")[0].checked;
			var due = todos[x].getElementsByClassName("event-todo-date")[0].value;
			eventTodos[x] = [item, (complete ? 1 : 0), due];	
		}
		
		var isNew = (this.currentEvent == 'new');
		
		$.ajax({
			type: 'post',
			url: "scripts/event.php",
			cache: false,
			data: { 
				id: this.currentEvent,
				name: $('#event-name').val(),
				contactID: $('#event-contact').val(),
				phone: $('#event-phone').val(),
				eventDate: $('#event-date').val(),
				eventDateTo: $('#event-date-to').val(),
				noWeb: $('#event-no-web').prop('checked') == true ? 1 : 0,
				eventTalks: eventTalks,
				singleSpeaker: $('#event-single-speaker').prop('checked') == true ? 1 : 0,
				bookTable: $('#event-book-table').prop('checked') == true ? 1 : 0,
				attendanceExpected: $('#event-attendance-expected').val(),
				address: $('#event-address').val(),
				city: $('#event-city').val(),
				county: $('#event-county').val(),
				postalCode: $('#event-postal-code').val(),
				region: $('#event-region').val(),
				useChurchAddress: $('#event-use-church-address').prop('checked') == true ? 1 : 0,
				accommodationDetails: $('#event-accommodation-details').val(),
				attendanceActual: $('#event-attendance-actual').val(),
				attendanceActualU18: $('#event-attendance-actual-u18').val(),
				directionDetails: $('#event-direction-details').val(),
				gift: $('#event-gift').val(),
				giftOther: $('#event-gift-other').val(),
				tourID: $('#event-is-tour').prop('checked') ? $('#event-tours').val() : 0,
				notes: $('#event-notes').val(),
				status: $('#event-status').val(),
				source: $('#event-source').val(),
				churchID: oChurch.details.id,
				hostDetails: $('#event-host-details').val(),
				volunteerDetails: $('#event-volunteer-details').val(),
				cmiEquipment: $('#event-cmi-equipment').val(),
				accessTimeDetails: $('#event-access-time-details').val(),
				presentationType: $('#event-presentation-type').val(),
				webpageID: $('#event-webpage-id').val(),
				eventTodos: eventTodos
			},
			success: function(result) { 	
				if (isNew)	{	// celebrate
					oChurch.celebrateNewEvent();
				}
					
				oChurch.unsavedEvent = false;				
				oChurch.closeEvent();
				statusMsg('Event details saved.');
			
				if (oChurch.eventMode == 'church')
					oChurch.listEvents();
				else	
					oEvents.listEvents();
				
				log('MINIMAX EVENT UPDATED', oChurch.details.name + ', event date=' + $('#event-date').val());
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}

	this.celebrateNewEvent = function() {	
		$('#system-icon').attr("src", 'images/book-event.gif');
		setTimeout(function() {
			$('#system-icon').attr("src", 'images/sos-icon.gif');
		}, 2000);					
	}
	
	this.setEventAddress = function(set) {
		if (set) {
			$('#event-address').val(oChurch.details.address).prop('disabled', true);
			$('#event-city').val(oChurch.details.city).prop('disabled', true);
			$('#event-county').val(oChurch.details.county).prop('disabled', true);
			$('#event-postal-code').val(oChurch.details.postal_code).prop('disabled', true);
			$('#event-region').val(oChurch.details.region).prop('disabled', true);
		}
		else {
			$('#event-address').val('').prop('disabled', false);
			$('#event-city').val('').prop('disabled', false);
			$('#event-county').val('').prop('disabled', false);
			$('#event-postal-code').val('').prop('disabled', false);
			$('#event-region').val('').prop('disabled', false);
		}
	}
	
	this.setHostDetails = function(set) {
		var address = '';
		if (set) {
			var sql = 'select * from contacts where id=' + $('#event-contact').val();
			execSQL(sql, function(contact) {
				address = contact[0].name + '\n' + contact[0].address + '\n' + contact[0].phone_1 + '\n' + contact[0].phone_2 + '\n' + contact[0].email;
			}, false);
		}
		$('#event-host-details').val(address);
	}
	
	this.addEventTalk = function(theSpeaker, theTalk, theTime, daily) {
		var obj = this;
		
		var line = document.createElement('li');
		document.getElementById('event-talks').appendChild(line);
		line.className = "ui-state-default";

		var handle = document.createElement('span');
		line.appendChild(handle);
		handle.className = "event-talk-handle";
		handle.innerHTML = '&udarr;';
		
		var speaker = document.createElement('input');
		line.appendChild(speaker);
		speaker.className = "event-speaker";
		$(speaker).attr('list', "event-speakers-list");
		speaker.value = theSpeaker;
		$(speaker).on('change', function() { 
			obj.singleSpeakerCheck();
			obj.listEventSpeakerTalks(this.value);
		});
		
		var talk = document.createElement('input');
		line.appendChild(talk);
		talk.className = "event-talk";
		$(talk).attr('list', "event-talk-list");
		talk.value = theTalk;
		
		var time = document.createElement('input');
		line.appendChild(time);
		time.className = "event-time";
		time.type = "time";
		time.value = theTime;
		time.disabled = (daily == 1);

		var cbx = document.createElement('input');
		line.appendChild(cbx);
		cbx.className = "event-daily";
		cbx.type = "checkbox";
		cbx.checked = daily;
		$(cbx).on('click', function() { 
			if (this.checked) {
				time.disabled = true;
				time.value = '';
			}
			else
				time.disabled = false;
		})

		var cbxLabel = document.createElement("label");
		cbxLabel.innerHTML = "DAILY";
		cbxLabel.className = 'event-talk-daily';
		line.appendChild(cbxLabel);
		
		var canx = document.createElement('span');
		line.appendChild(canx);
		canx.innerHTML = "x";
		canx.className = "event-talk-canx";
		canx.onclick = function() {
			oChurch.deleteEventTalk(line);
		}
	}
	
	this.deleteEventTalk = function(line) {
		if ($('#event-talks').children().length == 1)
			cb_alert('You must have at least one talk, even if it\'s TBA');
		else
			document.getElementById('event-talks').removeChild(line);
	}

	this.singleSpeakerCheck = function() {
		var single = $('#event-single-speaker').prop('checked');
		var talks = $('#event-talks').children();
		var firstSpeaker = '';
		for (var x=0; x<talks.length; x++) {
			var speaker = talks[x].getElementsByClassName('event-speaker')[0];
			$(speaker).prop('disabled', false);
			$(speaker).css('visibility', 'visible');
			
			if (x == 0) {
				firstSpeaker = 	$(speaker).val();
			}
			else {
				if (single) {
					$(speaker).val(firstSpeaker);
					$(speaker).prop('disabled', true);
				}
			}
		}
	}
			
	// EVENT TODO ITEMS
	this.eventTodoCheck = function() {
		if ($('#event-date').val() == '')
			cb_alert('Cannot create Todo items without an Event date.')
		else {
			if (this.currentEvent == 'new')
				this.createEventTodoItems();
			else
				this.getEventTodoItems();
			global.setTabActive('event-tab-5', "event-panel-5");
			$("#event-save-btn").show();
		}
	}
	
	this.createEventTodoItems = function() {
		
		if (this.eventTodoItemsCreated) {
			return;
		}

		var obj = this;		
		$('#event-todo-items').html('');
			
		var sql = 'select * from event_todo_item_defaults';
		execSQL(sql, function(defaults) {
			var data = [];
			for (var x in defaults) {
				var basedOnDate =	defaults[x].offset_date_type == 'B' ? $('#event-created-date').html() : $('#event-date').val();		// default based either on 'booking' or 'event'	
				var date = new Date(basedOnDate);
				var newDate = new Date(date);
				newDate.setDate(newDate.getDate() + Number(defaults[x].offset_from_date));
				
				var dd = newDate.getDate();
				var mm = newDate.getMonth() + 1;
				var yyyy = newDate.getFullYear();
				var todoDate = yyyy + '-' + strZero(mm, 2) + '-' + strZero(dd, 2);

				data[x] = { complete: false, item: defaults[x].item, due: todoDate };
				obj.addEventTodoItem(data[x]);							
			}
		}, false);

		this.eventTodoItemsCreated = true;
	}

	this.getEventTodoItems = function() {	
		var obj = this;		
		var sql = 'select * from event_todo_items where event_id=' + this.currentEvent;
		$('#event-todo-items').html('');
				
		execSQL(sql, function(data) {	
			for (var x in data) {
				obj.addEventTodoItem(data[x]);
			}
		});
	}
	
	this.addEventTodoItem = function(data) {
		var line = document.createElement('li');
		document.getElementById('event-todo-items').appendChild(line);
		line.className = "ui-state-default";

		var handle = document.createElement('span');
		line.appendChild(handle);
		handle.className = "event-todo-handle";
		handle.innerHTML = '&udarr;';		
		
		var cbx = document.createElement('input');
		line.appendChild(cbx);
		cbx.type = "checkbox";
		cbx.className = 'event-todo-complete';
		cbx.checked = (data.complete == 1);

		var cbxLabel = document.createElement("input");
		cbxLabel.innerHTML = data.item;
		cbxLabel.value = data.item;
		cbxLabel.className = 'event-todo-item';
		line.appendChild(cbxLabel);
		
		var cbxDate = document.createElement("input");
		cbxDate.type = "date";
		cbxDate.value = data.due;
		cbxDate.className = 'event-todo-date';
		line.appendChild(cbxDate);
	
		var canx = document.createElement('span');
		line.appendChild(canx);
		canx.innerHTML = "x";
		canx.className = "event-todo-canx";
		canx.onclick = function() {
			oChurch.deleteEventTodoItem(line);
		}				
	}
	
	this.deleteEventTodoItem = function(line) {
		if ($('#event-todo-items').children().length == 1)
			cb_alert('You must have at least one ToDo item.');
		else
			document.getElementById('event-todo-items').removeChild(line)
	}
	
	// CONTACT HISTORY........
	this.listContactHistory = function() {
		var b = new cb_browse('contact-history-list');
		var sql = "select *, concat(left(note, 45), '...') as note_brief from contact_history where church_id=" + oChurch.details.id;
		b.preQuery = 'create temporary table report (index(date)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print
		b.columns = ['id','login_id','date','note_brief','note'];
		b.colClass = ['hide','hide','note-date','note-note','hide'];
		b.colHeadings = ['','','Date','Note'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'date';
		b.sortReverse = true;
		b.deleteFn = [true, function(data) { oChurch.deleteNoteCheck(data[0]) } ];		
		b.fetch = function(data, xxx, data2) {
			oChurch.editNote('edit', data2);
		}
		b.init();
		oChurch.notes = b;
	}
	
	this.editNote = function(mode, data) {
		if (mode == 'new') {
			var data = new Object();
			this.currentNote = 'new';
		}
		else
			this.currentNote = data.id;
		
		$('#contact-history-new-btn').hide();
		$('#contact-history-save-btn').show();
		$('#contact-history-note').show();
		
		$('#contact-history-loginID').html(data.login_id);
		$('#contact-history-note').val(data.note);
	}

	this.saveNote = function() {
		if (!formValidated('tab-4-content'))
			return;

		$('#contact-history-new-btn').show();
		$('#contact-history-save-btn').hide();
		$('#contact-history-note').hide();
		
		var sql = 'insert into contact_history set' +
						' id="' + this.currentNote + '"' +
						',church_id="' + this.details.id + '"' +
						',note="' + $('#contact-history-note').val() + '"' +
						',login_id="' + oLogin.uid + '"' +
						' on duplicate key' +
						' update note="' + $('#contact-history-note').val() + '", login_id="' + oLogin.uid +'"';

		execSQL(sql, function() {
			oChurch.notes.refreshData();
			statusMsg('Note saved.');
			log('MINIMAX CONTACT NOTE ADDED', oChurch.details.name);
		});
	}
	
	this.deleteNoteCheck = function(id) {
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to delete this Note?", 
			["Yes", "No"],
			[ function() { oChurch.deleteNote(id) }, function() {} ]
		);
	}
	
	this.deleteNote = function(id) {
		var sql = 'delete from contact_history where id=' + id;
		execSQL(sql, function() {
			oChurch.notes.refreshData();
		});
	}	
	
	this.checkForDuplicate = function() {
		var currentChurch = oChurch.details.id;
		if ($('#church-name').val() == '')
			return;

		var sql = 'select name, address, city from churches where name like "%' + $('#church-name').val() + '%" and id<>' + currentChurch;
		execSQL(sql, function(churches) {

			if (churches.length > 0) {	
				var msg = 'Possible duplicate churches already exist:<br><br>';
				msg += '<table style="display: block; background-color: white; height: 220px; overflow-y: auto; border: 1px solid black">';
				for (var x in churches) {
					msg += '<tr>';
						msg += '<td>';
							msg += '<hr>' + churches[x].name + ', ' + churches[x].address + ', ' + churches[x].city;
						msg += '</td>';
					msg += '</tr>';
				}
				msg += '</table>';
				
				cb_alert(msg);
			}
		});
	}
	
	// DOCUMENTS
	
	this.listEventDocs = function() {		
		var obj = this;
		$('#event-all-documents-panel').hide();
		$('#event-document-container').hide();
		$('#event-documents-panel').slideDown();

		var b = new cb_browse('event-documents');
		var sql = "select name, '' as print, content, id from event_documents ed where event_id=" + oChurch.currentEvent;
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.controls[0] = false;		// no search
		b.displayRecount = false;
		b.columns = ['name','print','content','id'];
		b.colClass = ['ed-name','ed-print','hide','hide'];
		b.colHeadings = ['','','',''];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'name';
		b.rowCallback = function(row, data, data2) { 
			row.children[1].innerHTML = '<img src="images/print.png" style="width: 15px">';
			row.children[1].title = 'Click to print';
			row.children[1].onclick = function(e) { 
				e.stopPropagation(); 
				$('#sos-print-container').html(data2.content);
				window.print();
				$('#sos-print-container').html('');
			}			
		}
		
		b.deleteFn = [true, function(data) { oChurch.deleteEventDocument(data[3]) } ];		
		b.fetch = function(data, xxx, json) {
			var x = screen.width/2 - 1000/2;
			var y = screen.height/2 - 700/2;
			obj.eventDocumentID = json.id;
			obj.eventDocumentOpen();
			$('#event-documents-panel').hide();
			$('#event-document-container').slideDown();
		}
		b.init();
	}
	
	this.deleteEventDocument = function(id) {
		var obj = this;
		var sql = 'delete from event_documents where id=' + id;
		execSQL(sql, function() {
			obj.listEventDocs();
		});
	}
	
	this.getEventSpeakersForWord = function() {
		var eventSpeakers = '';
		var talks = $('#event-talks').children();
		for (var x=0; x<talks.length; x++) {
			var speaker = talks[x].getElementsByClassName('event-speaker')[0].value;
			eventSpeakers += speaker + ' - ';
		}
		return eventSpeakers;
	}
	
	this.getEventTalksForWord = function() {
		var eventTalks = '';
		var talks = $('#event-talks').children();
		for (var x=0; x<talks.length; x++) {
			var talk = talks[x].getElementsByClassName('event-talk')[0].value;
			var time = talks[x].getElementsByClassName('event-time')[0].value;
			eventTalks += talk + " (" + time.substr(0, 5) + ") <br>";
		}
		return eventTalks;
	}
	
	this.getMinistryHistoryForWord = function() {
		var ministryHistory = '';
		var sql = "select *, (select group_concat(talk) from event_talks where event_id=e.id) as talks from events e where e.id<>" + oChurch.currentEvent + " and church_id=" + oChurch.details.id;
		execSQL(sql, function(data) {
			for (var x in data) {
				ministryHistory += data[x].event_date + ' - ' + data[x].talks + " (" +data[x].speaker + ") - " + data[x].attendance_actual + "<br>";
			}			
		}, false);
		return ministryHistory;
	}	
	
	this.listDocuments = function() {
		var obj = this;
		$('#event-documents-panel').slideUp();
		$('#event-all-documents-panel').slideDown();
		
		var b = new cb_browse('event-all-documents');
		var sql = "select id, name, content from document_templates";
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.controls[0] = false;		// no search
		b.displayRecount = false;
		b.columns = ['id','name','content'];
		b.colClass = ['hide','','hide'];
		b.colHeadings = ['','',''];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'name';
		b.fetch = function(data, xxx, json) {
			obj.mailMerge(json);
		}
		b.init();
	}	
	
	this.mailMerge = function(templateDoc) {
		var obj = this;
		var eventTalks = this.getEventTalksForWord();
		var ministryHistory = this.getMinistryHistoryForWord();	
	
		var mmData = [];
		for (var x in global.miniMaxDocFields) {
			mmData[x] = new Array();
			mmData[x][0] = global.miniMaxDocFields[x][1];
			mmData[x][1] = global.miniMaxDocFields[x][2]();
		}
		
		var mergedDoc = templateDoc.content;

		for (var x in mmData) {
			mergedDoc = mergedDoc.replace(new RegExp(mmData[x][0], 'g'), mmData[x][1]);
		}
	
		$.ajax({
			type: 'post',
			url: "scripts/add-event-document.php",
			cache: false,
			data: { 
				name: templateDoc.name,
				content: mergedDoc,
				eventID: oChurch.currentEvent
			},
			success: function(result) { 
				statusMsg('Document added.');	
				obj.listEventDocs();
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}
	
	this.eventDocumentOpen = function() {
		var sql = 'select name, content from event_documents where id=' + this.eventDocumentID;	
		execSQL(sql, function(results) {
			if (results.length == 0) {
				var name  = 'No document found.';
				var content = 'No document found.';
			}
			else {
				var name = results[0].name;
				var content = results[0].content;
			}
				
			$('#event-document-title').html(name);	
			tinymce.get('event-document-text-edit').setContent(content);		
		});
	}

	this.eventDocumentSave = function() {
		var obj = this;

		$.ajax({
			type: 'post',
			url: "scripts/event-document.php",
			cache: false,
			data: { 
				id: obj.eventDocumentID,
				content: tinymce.get('event-document-text-edit').getContent()
			},
			success: function(result) { 
//console.log(oEvents)
				log('MINIMAX DOCUMENT UPDATED', oChurch.details.name + ' > ' + $('#event-date').val() + ' - ' + $('#event-document-title').html());				
				statusMsg('Document saved.');
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});			
	}

	this.eventDocumentClose = function(id) {
		$('#event-document-container').hide();
		$('#event-documents-panel').show();
	}
	
	this.eventDocumentWordExport = function() {
		var obj = this;
		
//		$('#event-document-text-edit').val(tinymce.get('event-document-text-edit').getContent());
//console.log(tinymce.get('event-document-text-edit').getContent());

		var textArea = document.createElement('div');
		document.body.appendChild(textArea);
		textArea.innerHTML = tinymce.get('event-document-text-edit').getContent();
//			textArea.id = 'bob123';
		textArea.style.backgroundColor = 'white';
		global.copyToClipboard(textArea);
		document.body.removeChild(textArea);
	}
	
	this.findOnMap = function(source) {
		var location = '';
		if (source == "church") {
			location += $('#church-address').val();
			location += commaIf($('#church-city').val());
			location += commaIf($('#church-county').val());
			location += commaIf($('#church-postal-code').val());
		}
		else {		// event
			location += $('#event-address').val();
			location += commaIf($('#event-city').val());
			location += commaIf($('#event-county').val());
			location += commaIf($('#event-postal-code').val());
		}
		window.open('https://www.google.co.uk/maps/search/' + location);
	}
	
}
