<?php
	include "db-conx.php";

	$array = array();

	$sth = $db_handle->prepare($_GET['query']);
	if ($sth->execute()) {
		$counter = 0;
		while ($row = $sth->fetch()) {
			$array[$counter] = $row;
			$counter++;
		}
	}
		
	echo json_encode($array);
?>