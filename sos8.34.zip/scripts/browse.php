<?php
include "db-conx.php";

$startRow = $_GET['startRow'];
$rowDepth = $_GET['rowDepth'];
$whereExpr = $_GET['where'];
$groupByExpr = $_GET['groupBy'];
$filterExpr = explode(" ", $_GET['filter']);
$noFilter = $_GET['noFilter'];
$columnsExpr = $_GET['columns'];
$searchColumn = $_GET['searchColumn'];
$searchExact = $_GET['searchExact'];
$sortColumn = $_GET['sortColumn'];
$sortReverse = $_GET['sortReverse'];
if ($sortReverse == 'true')
	$sortColumn .= ' desc';
$preQuery = $_GET['preQuery'];

// merge columns into single column for filtering
if ($searchColumn == 'all') {
	$columns = "CONCAT(";
	for ($x=0; $x<sizeof($columnsExpr); $x++) {
		if ($x==0)
			$columns .= $columnsExpr[$x];
		else
			$columns .= ',' . $columnsExpr[$x];
		$columns .= '," "';		// separate fields with a space
	}
	$columns .= ")";
}
else 
	$columns = $searchColumn;	// unused for now, but may want to allow fuzzy filter later

// build filter expression
if ($noFilter == 'true') {
	$filter='1';
}
else {
	if ($searchColumn == 'all') {
		$filter = "";
		for ($x=0; $x<sizeof($filterExpr); $x++) {
			if ($x==0)
				$filter .= $columns . " like '%" .$filterExpr[$x] . "%'";
			else
				$filter .= ' and ' . $columns . " like '%" .$filterExpr[$x] . "%'";
		}
	}
	else {
		if ($searchExact == 'true')
			$filter = $searchColumn . '="' . $_GET['filter'] . '"';		// exact match required
		else
			$filter = $searchColumn . ' like "%' . $_GET['filter'] . '%"';
	}
}

// build the final query
$sql = $_GET['query'];
$sql .= " where " . $whereExpr . ' and ' . $filter;
if ($groupByExpr != '')
	$sql .= ' group by ' . $groupByExpr;
$sql .= " order by " . $sortColumn;
if ($rowDepth > 0)		// 0=show all records on 1 page
	$sql .= " limit " . $startRow . ',' . $rowDepth;
	
$debugsql = $sql;

// run any pre-query
if ($preQuery != '') {
	$sth = $db_handle->prepare($preQuery);
	$sth->execute();
}

$counter = 0;
$array = Array();
$jsonArray = Array();		// this should have been there from the start instead of $array!
$sth = $db_handle->prepare($sql);
if ($sth->execute()) {
	while($row = $sth->fetch()) {
		$jsonArray[$counter] = $row;		
		for ($x=0; $x<sizeof($columnsExpr); $x++) {
			$array[$counter][$x] = $row[$columnsExpr[$x]];
		}
		$counter++;
	}
}

// need a count of records in returned dataset to determine paging
$sql = $_GET['query'];
$sql .= " where " . $whereExpr . ' and ' . $filter;
if ($groupByExpr != '')
	$sql .= ' group by ' . $groupByExpr;

$count = 0;
$sth = $db_handle->prepare($sql);
if ($sth->execute()) {
	$count = $sth->rowCount();
}
else $count = $sql;

echo json_encode([$count, $array, $debugsql, $jsonArray]);		// 3rd param for debugging
?>