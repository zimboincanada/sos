<?php
include "db-conx.php";

$id = $_POST['id'];
$status = $_POST['status'];
$statusDate = $_POST['statusDate'];
$content = $_POST['content'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();

	$sql = 'update event_documents set status=?, status_date=?, content=? where id=?';
				
	$sth = $db_handle->prepare($sql);
	$success = $sth->execute(array(
		$status, 
		$statusDate, 
		$content, 
		$id
	));
	
	$result->success = $success;
	$result->id = $id;
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);
?>