window.onbeforeunload = function() { return confirmExit(); }
window.onunload = function() { return clearSession(); }
window.onload = startupCode;
function startupCode() {
    dymo.label.framework.init(); 		// initialize dymo printer, then invoke a callback
}

$(document).ready(function() {
    init();
});

function confirmExit() {
    if (oCustomer.unsavedData || global.unsavedSalesOrderData) {       
		var confirmationMessage = 'It looks like you have been editing something. ';
		confirmationMessage += 'If you leave before saving, your changes will be lost.';
		confirmationMessage += (oCustomer.unsavedData ? '\n\nCUSTOMER DATA' : '');
		confirmationMessage += (global.unsavedSalesOrderData ? '\nSALES ORDER DATA' : '');	
        return confirmationMessage;
    }
}

function clearSession() {
	if (global.hasLock)
		setUnlock();		// sets lock flag in customer record to false
}

var systemSettings = new Object();
var oCustomer;

function init() {	
	global.soNumber = 0;				
	global.soEditMode = 'new';						// new | edit
	global.custEditMode = 'new';					// new | edit
	global.unsavedSalesOrderData = false;	// so we can warn if leaving page without saving
	global.hasLock = false;
	global.duplicateID = 0;								// used in 'merge customer' function
	global.subsData = new Array();
	createReferenceData(); 
	global.customerID = getURLParameter('customer');	
	
	oCustomer = new customer();

	if (global.customerID == 'new') {
		global.customerID = 0;
		$('#customer-id').html('*new*');
		$(document).attr("title", '*new*');		// chrome tab name
		if (global.isUK)
			$('#country').val(oSettings.country.toUpperCase());
		else
			$('#country').val(oSettings.country);
	}
	else {
		oCustomer.refreshData();
//console.log('3=',$('#country').val())
		getLock();		// attempt exclusive access
	}
	
	if (global.isUK) {
		$('#uk-flags').show();
//		$('#country').val(oSettings.country.toUpperCase());

//		$('#email1').on('focus', function() {
//			cb_alert("WARNING!<br>You need the customer's permission to use this email address.");
//		})
	}
	else {
		$('#ca-flags').show();
		$('#c-no-cem-label').show();
		$("#phone1").mask("999-999-9999");	
		$('#c-province-label').show();
		$('#t2-subs-province-label').show();
		document.getElementById('postal-code').required = true;
	}
	
	oCustomer.showIfChurchContact();
	
	showTab(1);	
}

function createReferenceData() {
	fillPicklistWithData('province-list', oSettings.provinces, oSettings.provinces);
	systemSettings.country = oSettings.country;
	systemSettings.cmiAddressForLabel = oSettings.cmi_address_2 + '\n' + oSettings.cmi_address_3;
	systemSettings.currentPrint = oSettings.current_print;
	systemSettings.currentDigital = oSettings.current_digital;
	systemSettings.currentJournal = oSettings.current_journal;
	systemSettings.cutoffPeriod = (oSettings.cut_off_period == 1);

	// build dropdown lists
	var lists = [
		['source', oSettings.customer_source],
		['so-payment-type', oSettings.payment_method],
		['so-source', oSettings.sales_order_source], 
		['t2-salutation-list', oSettings.salutation], 
		['t3-salutation-list',oSettings.salutation]
	];		// element ids of select lists
	
	var option;
	for (var y in lists) {
		var dataSet = lists[y][1].split(",");
		document.getElementById(lists[y][0]).innerHTML = '';
		
		for (var x in dataSet) {
			option = document.createElement('option');
			document.getElementById(lists[y][0]).appendChild(option);
			option.value = dataSet[x];
			option.textContent = dataSet[x];
		};	
	};

	// set country input elements; CA want combo box, UK want dropdown list
	if (global.isCA) {
		var countryList = document.createElement('input');
		var country = document.getElementById('country-container').appendChild(countryList);
		country.id = 'country';
		country.setAttribute('list','country-list');	
		fillPicklist('country-list', S_COUNTRIES);

		// same again for customer form in mag sub gift selection
		countryList = document.createElement('input');
		country = document.getElementById('t2-country-container').appendChild(countryList);
		country.id = 't2-subs-country';
		country.setAttribute('list','t2-country-list');
		fillPicklist('t2-country-list', S_COUNTRIES);
	}
	else {
		var countryList = document.createElement('select');
		var country = document.getElementById('country-container').appendChild(countryList);
		country.id = 'country';
		fillPicklist('country', S_COUNTRIES);
		
		// same again for customer form in mag sub gift selection
		countryList = document.createElement('select');
		country = document.getElementById('t2-country-container').appendChild(countryList);
		country.id = 't2-subs-country';
		fillPicklist('t2-subs-country', S_COUNTRIES);
		
		country.required = true;		
	}
	
	fillPicklist('so-popts-type-1', S_PAYMENT_METHOD);
	fillPicklist('so-popts-type-2', S_PAYMENT_METHOD);
	fillPicklist('so-popts-type-3', S_PAYMENT_METHOD);
	fillPicklist('so-popts-type-4', S_PAYMENT_METHOD);
	fillPicklist('so-popts-type-5', S_PAYMENT_METHOD);
	fillPicklist('so-popts-type-6', S_PAYMENT_METHOD);			
	
	// build dropdown lists for recurring donations
	fillPicklist('don-frequency', S_RECURRING_DONATIONS);
	getDonationTypes();
}

// customer class
function customer() {	

	// if customer is a church contact, make it obvious
	this.showIfChurchContact = function() {
		var sql = 'select c.name, c.id from church_contacts cc, churches c where c.id=cc.church_id and cc.contact_id=' + oCustomer.id;
		execSQL(sql, function(data) {
//console.log(sql)			
			if (data.length > 0) {
				$('#customer-church-contact-panel-church-name').html(data[0].name);
				$('#customer-church-contact-panel-church-name').attr('href', 'church.html?church=' + data[0].id);
				$('#customer-church-contact-panel').show();
			}
		});
	}

	this.refreshData = function() {
		this.unsavedData = false;		// so we can warn if leaving page without saving
		document.getElementById('tab-2').style.display = 'inline-block';

		if (oSettings.s2active) {
			document.getElementById('tab-4').style.display = 'inline-block';
			$('#c-create-s2-btn').show();
		}
		else
			document.getElementById('tab-3').style.display = 'inline-block';

		document.getElementById('tab-5').style.display = 'inline-block';
		document.getElementById('tab-6').style.display = 'inline-block';
		
		// unhide btns as these were not possible without a customer number, i.e. new customer
		$('#c-merge-btn').show();	
		$('#c-donations-btn').show();					
		
		global.custEditMode = 'edit';
		getData('getCustomer', global.customerID, function(data) { 
			for (var x in data)
				oCustomer[x] = data[x];
//console.log('1=',data.country)
			fillFields();
			
			var msg = '';
			if (oCustomer.no_mail == 1)
				msg += 'Mail has been returned. Hold all mail.<br><br>';

			if (oCustomer.price_band == 2)	// wholesale
				msg += 'Wholesale customer: remember to charge exact shipping<br><br>';
				
			if (msg != '')
				cb_alert(msg);
			
		}, false);
		
		getDonationIndicator();		
	}

	this.createS2CustomerRecord = function() {
		confirmBox(
			"CONFIRM", 
			"You are about to create a customer account in the S2 database. You should only use this option for International Gift Subscriptions.<p>Do you want to create it?</p>", 
			["Yes", "No"],
			[ function() { 
				var sql = 'insert into s2_log set type="C", customer_id=' + oCustomer.id;
				execSQL(sql, function() {
					statusMsg('Submitting details to S2...');
					execS2("updateS2", '', function() {			
					});
				});

			}, function() {} ]
		)
	}
	
	// S2 functionality: if no mail flag set, alert if customer has subs as they will be set to suspended when customer record is saved
	this.s2suspendSubs = function(action) {

		if (!oSettings.s2active || global.custEditMode == 'new')
			return;
			
		var obj = this;
		var holdMail = $('#no-mail').prop('checked');
//console.log($('#no-mail').prop('checked'))
		
		if (action == 'check')
			statusMsg('Checking S2...');
		
		execS2('getSubscriptions', obj.id, function(subs) {
			var noSubs = true;
			for (var x in subs) {
				if (!subs[x].givesgift) {
					
					if (holdMail && subs[x].status == 'Active') {
						noSubs = false;
						if (action == 'save') {
							var sql = 'insert into s2_log set type="U", sub_id=' + subs[x].subid + ', customer_id=' + oCustomer.id + ', notes="No mail flag set."';
							execSQL(sql, function() {}, false);
						}
					}
					
					if (!holdMail && subs[x].status == 'Suspended') {
						noSubs = false;
						if (action == 'save') {
							var sql = 'insert into s2_log set type="I", sub_id=' + subs[x].subid + ', customer_id=' + oCustomer.id + ', notes="No mail flag unset."';
							execSQL(sql, function() {}, false);
						}
					}
					
				}
			}

			switch (true) {
				case noSubs: { break; }	// no action required
				case action == 'check' && holdMail: {
					cb_alert('This customer has Active subscriptions and they will be set to "Suspended".');
					break;
				}
				case action == 'check' && !holdMail: {
					cb_alert('This customer has Suspended subscriptions and they will be set to "Active".');
					break;
				}
				case action == 'save': {
					execS2("updateS2", '', function() {});
					break;
				}
			}			
		
		});			
	}
}

function fillFields() {
	document.getElementById('customer-id').innerHTML = oCustomer.first_name + ' ' + oCustomer.last_name + ' [' + oCustomer.id + ']';
	$(document).attr("title", oCustomer.first_name + ' ' + oCustomer.last_name + ' ' + oCustomer.organization);	// chrome tab name		
	
	document.getElementById('salutation').value = oCustomer.salutation;
	document.getElementById('first-name').value = oCustomer.first_name;
	document.getElementById('last-name').value = oCustomer.last_name;
	document.getElementById('organization').value = oCustomer.organization;
	document.getElementById('address').value = oCustomer.address;
	document.getElementById('address-2').value = oCustomer.address_2;
	document.getElementById('city').value = oCustomer.city;
	document.getElementById('province').value = oCustomer.province;
	document.getElementById('postal-code').value = oCustomer.postal_code;
	document.getElementById('country').value = oCustomer.country;
//console.log('2=',oCustomer.country, '2a=', document.getElementById('country').value)	
	document.getElementById('phone1').value = oCustomer.phone1;
	document.getElementById('phone2').value = oCustomer.phone2;
	document.getElementById('email1').value = oCustomer.email1;
	document.getElementById('email2').value = oCustomer.email2;
	
	document.getElementById('source').value = oCustomer.source;
	document.getElementById('prayer-news').checked = (oCustomer.prayer_news == 1);
	document.getElementById('update-news').checked = (oCustomer.update_news == 1);
	document.getElementById('c-no-cem').checked = (oCustomer.no_cem == 1);
	document.getElementById('no-mail').checked = (oCustomer.no_mail == 1);
	document.getElementById('price-band').value = oCustomer.price_band;
	
	document.getElementById('c-gift-aid').checked = (oCustomer.gift_aid == 1);
	document.getElementById('c-courtesy-call-complete').checked = (oCustomer.courtesy_call_complete == 1);
	document.getElementById('c-follow-up-required').checked = (oCustomer.follow_up_required == 1);
	document.getElementById('c-friend-of-cmi').checked = (oCustomer.friend_of_cmi == 1);
	
	document.getElementById('notes').value = oCustomer.notes;
	var an = oCustomer.access_number;
	document.getElementById('access-number').value = (an == 0 ? '' : an);	// don't want to see a zero
	
	document.getElementById('account-balance').value = oCustomer.account_balance;
	balanceColorCode(document.getElementById('account-balance'));
	document.getElementById('donations-total').innerHTML = formatCurrency(oCustomer.donation_value);
	document.getElementById('date-added').innerHTML = formatDate(oCustomer.date_added, 1);
	document.getElementById('date-updated').innerHTML = formatDate(oCustomer.date_updated, 1);
}

function updateCustData() {
	var script, query;

	if (!formValidated('section-1'))
		return;

	$.ajax({
		type: 'post',
		url: "scripts/update-data.php",
		cache: false,
		data: { 
			query: 'updateCustomer',
			key: global.customerID,
			salutation: document.getElementById('salutation').value,
			first_name: document.getElementById('first-name').value,
			last_name: document.getElementById('last-name').value,
			organization: document.getElementById('organization').value,
			address: document.getElementById('address').value,
			address_2: document.getElementById('address-2').value,
			city: document.getElementById('city').value,
			province: document.getElementById('province').value,
			postal_code: document.getElementById('postal-code').value,
			country: document.getElementById('country').value,
			phone1: document.getElementById('phone1').value,
			phone2: document.getElementById('phone2').value,
			email1: document.getElementById('email1').value,
			email2: document.getElementById('email2').value,
			source: document.getElementById('source').value,
			gift_aid: document.getElementById('c-gift-aid').checked ? 1 : 0,
			courtesy_call_complete: document.getElementById('c-courtesy-call-complete').checked ? 1 : 0,
			follow_up_required: document.getElementById('c-follow-up-required').checked ? 1 : 0,
			friend_of_cmi: document.getElementById('c-friend-of-cmi').checked ? 1 : 0,
			prayer_news: document.getElementById('prayer-news').checked ? 1 : 0,
			update_news: document.getElementById('update-news').checked ? 1 : 0,
			no_cem: document.getElementById('c-no-cem').checked ? 1 : 0,
			no_mail: document.getElementById('no-mail').checked ? 1 : 0,
			price_band: document.getElementById('price-band').value,
			notes: document.getElementById('notes').value,
			access_number: document.getElementById('access-number').value,
			account_balance: document.getElementById('account-balance').value
		},
		success: function(result) { 	
			if (global.custEditMode == 'new') {		// database returns new unique id
				global.customerID = result.id;
				getLock();		// attempt exclusive access
			}		
			
			statusMsg('Customer details saved.');			
			if (oSettings.s2active) {
				oCustomer.s2suspendSubs('save');
				execS2("updateS2", '', function() {
					oCustomer.refreshData();				
				});
			}
			else
				oCustomer.refreshData();				

			if (global.isUK)
				updateMagSubEmail();
		},
		error: function (xhr, ajaxOptions, thrownError) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});	

}

// UK wants digi email address==customer email1 address 100% of time
function updateMagSubEmail() {
	var sql = 'update mag_subs set digi_email="' + $('#email1').val() + '" where recipient_id=' + global.customerID;
	execSQL(sql, function() {});

	if (oSettings.s2active && global.custEditMode == 'edit') {
		execS2('getSubscriptions', oCustomer.id, function(subs) {
			for (var x in subs) {
				if (!subs[x].givesgift) {
					var sql = 'insert into s2_log set type="E", sub_id=' + subs[x].subid + ', customer_id=' + oCustomer.id + ', email="' + $('#email1').val() + '"';
					execSQL(sql, function() {
					}, false);
				}
			}
			execS2("updateS2", '', function() {});
		});
	}
}

function tabCheck(number) {
	showTab(number);
}
	
function showTab(number) {
	for (var x=1; x<7; x++) {
		var tab = 'tab-' + x;
		var tabDetails = 'tab-details-' + x;
		if (x == number) {
			document.getElementById(tab).className = 'tab active';
			document.getElementById(tabDetails).style.display = 'block';

			if (x == 1) {
				global.helpTopic = 'customer';		
			}
			if (x == 2)	{ 	// create list of sales orders
				global.helpTopic = 'sales-orders';
				getSOs();
			}
			if (x == 3)	{ 	// create list of subs purchased
				global.helpTopic = 'subscriptions';
				getSubs();
			}
			if (x == 4) {
				global.helpTopic = 'subscriptions';
				s2wait(true);		

				execS2("getSubscriptions", oCustomer.id, function(subsData) { 		
					s2wait(false);		
					s2assembleSubsData(subsData);		
				});				
			}
			if (x == 5)	{ 	// list of all current customer's donations
				global.helpTopic = 'customer-donations';
				$('#cd-end-date').val(today());				
				listCustomerDonations();
			}
			if (x == 6)	{ 	// customer notes
				global.helpTopic = 'customer-notes';
				listCustomerNotes();
			}
		}
		else {
			document.getElementById(tab).className = 'tab';
			document.getElementById(tabDetails).style.display = 'none';
		}
	}
}

// creates list of sales orders
function getSOs() {
	var sql = 'select lockdown, lpad(id, 6, "0") as id, left(order_date, 10) as order_date, value, left(notes, 60) as notes' +
				' from sales_orders where customer_id=' + global.customerID + ' order by order_date desc';
	var b = new cb_browse('sales-orders-grid');
	b.preQuery = 'create temporary table report (index(id)) ENGINE=MyISAM (' + sql + ')';
	b.query = 'select * from report';
	b.sortColumn = 'id';
	b.sortReverse = true;
	b.rowDepth = 0;
	b.height = 400;
	b.columns = ['lockdown', 'id', 'order_date', 'value', 'notes'];
	b.colClass = ['sos-lockdown','sos-id','sos-order-date','sos-value','sos-notes'];
	b.colHeadings = ['','ID','Order date','Value','Notes'];
	b.colHeadClass = b.colClass;
	
	if (global.hasLock && (oLogin.sys_admin == 1 || oLogin.delete_sales_order == 1))
		b.deleteFn = [true, function(data) { deleteSOCheck(data[1]) } ];

	b.fetch = function(data) { 		
		var sql = 'select * from sales_orders where id=' + data[1];		
		execSQL(sql, function(soData) {
			editSO('E', soData[0]);
		});
	};
	
	b.rowCallback = function(row, data) { 
		// show 'locked' icon if s/o has been locked down
		if (row.children[0].innerHTML == 1) {	// s/o is locked
			$(row.children[0]).html('<img src="images/locked.png" style="width:100%; vertical-align:bottom; margin-bottom:2px">');
			row.children[0].title = 'This sales order is locked';			
			$(row.children[5]).html('');		// hide the delete icon (delete is not allowed)
		}
		else {
			$(row.children[0]).html('');
		}
	};
			
	b.init();		
}

function deleteSOCheck(soID) {
	
	// if there are any subs records, deny delete option
	var sql = 'select count(*) from sales_order_items where sales_order=' + soID + ' and mag_sub_id>0';
	execSQL(sql, function(result) {
		var num = result[0][0];
		
		if (num > 0)												
			cb_alert('There are ' + num + ' subscription records associated with this order. Please deal with those first before this order can be deleted.');
		else
			confirmBox(
				"CONFIRM", 
				"Do you want to delete this sales order?", 
				["Yes", "No"],
				[ function() { removeSO(soID); }, function() {} ]
			)
	});	
}

// edit a sales order
function editSO(mode, data) {
	if (mode == 'N')
		global.soEditMode = 'new';
	else
		global.soEditMode = 'edit';

	openSO(data);
	document.getElementById('sales-orders').style.display = 'none';
	document.getElementById('so-form').style.display = 'block';
}

function removeSO(soID) {
	$.ajax({
		type: 'post',
		url: "scripts/delete-data.php",
		cache: false,
		data: { 
			query: 'deleteSalesOrder',
			key: soID,
			seminarCustomer: ($('#price-band').val() == 4)
		},
		success: function(result) { 
//console.log(result)		
			getSOs();		// refresh the list
		},
		error: function (xhr, ajaxOptions, thrownError) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});	
}

function balanceColorCode(obj) {
	$('#' + obj.id).removeClass('credit');
	$('#' + obj.id).removeClass('debit');
	
	if (obj.value > 0)
		$('#' + obj.id).addClass('credit');
	
	if (obj.value < 0)
		$('#' + obj.id).addClass('debit');
}

// release record lock on exit of customer tab
function setUnlock() {
	$.ajax({
		type: 'post',
		url: "scripts/update-data.php",
		cache: false,
		async: false,
		data: { 
			query: 'unlockCustomer',
			key: global.customerID
		},
		success: function(result) { 
			setInputs('read');	
		},
		error: function (xhr, ajaxOptions, thrownError) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});			
}

function getLock() {
	$.ajax({
		type: 'post',
		url: "scripts/update-data.php",
		cache: false,
		data: { 
			query: 'lockCustomer',
			key: global.customerID
		},
		success: function(result) { 
			if (result == 1) {
				setInputs('edit');	// enable data entry
				global.hasLock = true;
			}
			else {
				setInputs('read');	
			}
		},
		error: function (xhr, ajaxOptions, thrownError) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});			
}

// mode = edit | read
function setInputs(mode) {
	if (mode == 'edit') {
		$('#lock-msg').hide();
		document.getElementById('section-1').disabled = false;			
		document.getElementById('section-2').disabled = false;			
		document.getElementById('account-balance').disabled = false;			
		$('#c-save-btn').show();
		$('#new-so-btn').show();

		if ((oLogin.sys_admin == 1 || oLogin.edit_sales_order == 1) && global.hasLock)
			$('#so-save').show();	
	}
	else {		// read
		$('#lock-msg').show();
		document.getElementById('section-1').disabled = true;	
		document.getElementById('section-2').disabled = true;	
		document.getElementById('account-balance').disabled = true;	
		$('#c-save-btn').hide();			
		$('#so-save').hide();
		$('#new-so-btn').hide();
	}
}

function getNotesFocus() {
	oCustomer.notesHasFocus = $('#notes').is(':focus');
}

// insert date + user ID into notes field (at cursor position)
function addNotesInfo(text) {
	if (text == undefined)
		text = '';
	
	var cursorPos = 0;		// default=insert text at start of block
	if (oCustomer.notesHasFocus)
		cursorPos = $('#notes').prop('selectionStart');
	var notesInfo = formatDate(today(), 2) + ' ' + oLogin.uid + '\n' + text + '\n\n';
	var v = $('#notes').val();
	var textBefore = v.substring(0,  cursorPos);
	var textAfter  = v.substring(cursorPos, v.length);
	
	$('#notes').val(textBefore + notesInfo + textAfter);
	
	// position cursor at end of inserted text
	document.getElementById('notes').selectionEnd = cursorPos + notesInfo.length -2;	
	document.getElementById('notes').focus();	
};

// alert if trying to add a customer with am email address already in another customer record
function emailDupCheck(email) {
	if (email == '')
		return
	
	var sql = 'select id from customers where email1="' + email + '" or email2="' + email + '"';
	execSQL(sql, function(data) {
		if (data[0] != undefined) {
			var dups = '';
			for (var x in data)
				dups += data[x][0] + ' ';
			cb_alert('Customer(s) already exist with this email address:<br><br>' + dups);
		}
	});
}