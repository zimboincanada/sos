<?php

file_get_contents('ssh2.sftp://user:charles@stage.creation.com:22/path/to/filename');

die('done.');


$ftp_server="ftp.stage.creation.com"; 
$ftp_user_name="charles"; 
$ftp_user_pass="Ba1n35_cm1"; 
$file = "";//tobe uploaded 
$remote_file = ""; 

// set up basic connection 
$conn_id = ftp_connect($ftp_server); 

// login with username and password 
$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass); 

// upload a file 
/*if (ftp_put($conn_id, $remote_file, $file, FTP_ASCII)) { 
    echo "successfully uploaded $file\n"; 
    exit; 
} else { 
    echo "There was a problem while uploading $file\n"; 
    exit; 
    } */
// close the connection 
ftp_close($conn_id); 
?>