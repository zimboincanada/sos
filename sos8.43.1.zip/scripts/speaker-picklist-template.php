<?php
include "db-conx.php";

$result = "database update fail";

$speakerID = $_POST['speakerID'];
$templateID = $_POST['templateID'];
$templateName = $_POST['templateName'];
$templateAttendance = $_POST['templateAttendance'];
$templateData = $_POST['templateData'];

try {
	$db_handle->beginTransaction();
	
	// header stuff
//		$sql = 'insert into picklist_templates set speaker_id=?, name=?';
//		$sth = $db_handle->prepare($sql);
//		$status = $sth->execute(array($_POST['speakerID'], $_POST['templateName']));
	
	$sql = 'insert into picklist_templates (id, speaker_id, name, attendance)
				values (?,?,?,?)
				on duplicate key
				update speaker_id=?, name=?, attendance=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$templateID, 
		$speakerID, 
		$templateName,
		$templateAttendance,
		$speakerID, 
		$templateName,
		$templateAttendance
	));
			
	if ($templateID == 'new')
		$templateID = $db_handle->lastInsertId();
			
	// product items
	$sql = 'delete from picklist_template_items where template_id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array($templateID));
	
	for ($x=0; $x<sizeof($templateData); $x++) {
		
		$sku = $templateData[$x][0];
		$qty = $templateData[$x][2];
		
		$sql = "insert into picklist_template_items set template_id=?, sku=?, qty=?";					
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array(
			$templateID,
			$sku,
			$qty
		));		
	}
	
	$db_handle->commit();
	$result = 'success';
}
catch (Exception $e) {
	$db_handle->rollback();
}
	
echo json_encode($result);
?>