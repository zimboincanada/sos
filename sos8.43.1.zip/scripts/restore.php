<?php
//$fileToRestore = $_GET['file'];


//$label = $_POST["label"];
//$filename = $label.$_FILES["fileToRestore"]["name"];
$filename = $_POST["file"];

//$backupFile = 'C:\Users\Charles\Desktop\bob.txt';
//echo json_encode(doRestore($backupFile));
//die(0);

if (move_uploaded_file($_FILES["file"]["tmp_name"], "../uploads/" . $filename)) {
	$result = doRestore($filename);
}
else {
	$result = new stdClass();
	$result->retval = 1;
	$result->output = ['Failed to upload file.'];
}

echo json_encode($result);

function doRestore($backupFile) {	
	$str = 'c:\wamp\bin\mysql\mysql5.6.17\bin\mysql --user=root sos < ' . $backupFile;
	$str .= ' 2>&1';
	
	exec($str, $output, $retval);
	
//	echo json_encode($output) . '<br>';
//	echo $retval . '<br>';
	$result = new stdClass();
	$result->retval = $retval;
	$result->output = $output;
	return $result;
}
?>