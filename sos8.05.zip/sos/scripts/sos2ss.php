<?php
	/* SOS subs data to S2
	
	
	update sos2ss ss set intoffice_cm=(select donor_id from ig_subs where recipient_id=ss.idnumber limit 1)
	
	*/

	set_time_limit(500);
	$server = "localhost";
	$database = "sos";
	$username = "root";
	$password = "";
	$db_handle = new PDO("mysql:host=$server;dbname=$database", $username, $password);
	
	try {
		
//exceptionList();
//intlSubsData();
//die(0);		
		
		$db_handle->beginTransaction();		
		
		$sql = "CREATE TABLE IF NOT EXISTS `sos2ss` (
		  `idnumber` varchar(6) NOT NULL DEFAULT '',
		  `title` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
		  `init` varchar(10) NOT NULL DEFAULT '',
		  `lname` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
		  `address1` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
		  `address2` varchar(50) NOT NULL DEFAULT '',
		  `town` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
		  `pcode` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
		  `state` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
		  `cname` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
		  `phone` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
		  `mailcent` varchar(5) NOT NULL DEFAULT '',
		  `tag1` int(4) NOT NULL,
		  `tag2` int(4) NOT NULL,
		  `tag3` int(4) NOT NULL,
		  `subgiver` varchar(30) NOT NULL,
		  `cen` varchar(1) NOT NULL DEFAULT '0',
		  `pn` int(1) NOT NULL,
		  `upd` int(1) NOT NULL,
		  `tj` int(1) NOT NULL,
		  `en` int(1) NOT NULL,
		  `subdue` varchar(4) NOT NULL DEFAULT '',
		  `subdonor` varchar(6) NOT NULL DEFAULT '',
		  `tjdue` varchar(3) NOT NULL,
		  `tjdonor` varchar(30) NOT NULL,
		  `last_amended` varchar(10) NOT NULL DEFAULT '',
		  `stats` varchar(10) NOT NULL DEFAULT '',
		  `country` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
		  `email` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
		  `newsub_stats` varchar(6) NOT NULL DEFAULT '',
		  `start_date` varchar(10) NOT NULL DEFAULT '',
		  `dm` int(1) NOT NULL,
		  `dmdue` varchar(4) NOT NULL DEFAULT '',
		  `bm` int(1) NOT NULL,
		  `bmdue` varchar(4) NOT NULL DEFAULT '',
		  `digidonor` varchar(30) NOT NULL DEFAULT '',
		  `digiemail` varchar(40) NOT NULL DEFAULT '',
		  `digijnlemail` varchar(40) NOT NULL DEFAULT '',
		  `intoffice_cm` varchar(10) NOT NULL DEFAULT '',
		  `intoffice_jnl` varchar(10) NOT NULL DEFAULT '',
		  PRIMARY KEY (`idnumber`),
		  KEY `idnumber` (`idnumber`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();
//die(0);		
		
		$sql = "truncate sos2ss";
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();

		
//donorOnlyList();		
//die(0);

		// print					
		$sql = "
			select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			ms.qty as tag1,
			'' as tag2,
			'' as tag3,
			'' as subgiver,
			'1' as cen,
			'' as pn,
			'' as upd,
			'' as tj,
			'' as en,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as subdue,
			if(so.customer_id<>ms.recipient_id,lpad(so.customer_id,6,'0'),'') as subdonor,
			'' as tjdue,
			'' as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			'' as dm,
			'' as dmdue,
			'' as bm,
			'' as bmdue,
			'' as digidonor,
			ms.digi_email as digiemail,
			'' as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='39:2'
			and soi.type='M' and (soi.sub_type='P') and c.no_mail=0
			";		
						
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();

		while ($row = $sth->fetch()) {
			insertRecord('P', $row);
		}		

		// both
		$sql = 
			"select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			ms.qty as tag1,
			'' as tag2,
			'' as tag3,
			'' as subgiver,
			'1' as cen,
			'' as pn,
			'' as upd,
			'' as tj,
			'' as en,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as subdue,
			if(so.customer_id=ms.recipient_id,'',lpad(so.customer_id,6,'0')) as subdonor,
			'' as tjdue,
			'' as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			'' as dm,
			'' as dmdue,
			'1' as bm,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as bmdue,
			'' as digidonor,
			ms.digi_email as digiemail,
			'' as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='39:2'
			and soi.type='M' and (soi.sub_type='B') and c.no_mail=0
			";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();

		while ($row = $sth->fetch()) {
			insertRecord('B', $row);
		}		
		
		// digi only
		$sql = 
			"select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			ms.qty as tag1,
			'' as tag2,
			'' as tag3,
			'' as subgiver,
			'' as cen,
			'' as pn,
			'' as upd,
			'' as tj,
			'' as en,
			'' as subdue,
			if(so.customer_id=ms.recipient_id,'',lpad(so.customer_id,6,'0')) as subdonor,
			'' as tjdue,
			'' as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			'1' as dm,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as dmdue,
			'' as bm,
			'' as bmdue,
			'' as digidonor,
			ms.digi_email as digiemail,
			'' as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='39:2'
			and soi.type='M' and (soi.sub_type='D') and c.no_mail=0
			";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();

		while ($row = $sth->fetch()) {
			insertRecord('D', $row);
		}				
		
		// joc
		$sql = 
			"select lpad(c.id,6,'0') as idnumber, 
			c.salutation as title, 
			'' as init, 
			c.last_name as lname, 
			c.address as address1, 
			'' as address2, 
			c.city as town, 
			c.postal_code as pcode, 
			c.province as state, 
			c.first_name as cname, 
			c.phone1 as phone, 
			'' as mailcent,
			'' as tag1,
			ms.qty as tag2,
			'' as tag3,
			'' as subgiver,
			'' as cen,
			'' as pn,
			'' as upd,
			'1' as tj,
			'' as en,
			'' as subdue,
			'' as subdonor,
			concat(left(ms.last_issue,2),right(ms.last_issue,1),0) as tjdue,
			if(so.customer_id=ms.recipient_id,'',lpad(so.customer_id,6,'0')) as tjdonor,
			'' as last_amended,
			'' as stats,
			c.country as country,
			c.email1 as email,
			'' as newsub_stats,
			'' as start_date,
			'' as dm,
			'' as dmdue,
			'' as bm,
			'' as bmdue,
			'' as digidonor,
			'' as digiemail,
			ms.digi_email as digijnlemail
			from mag_subs ms, customers c, sales_orders so, sales_order_items soi
			where c.id=ms.recipient_id
			and so.id=soi.sales_order
			and ms.id=soi.mag_sub_id
			and ms.status=1
			and ms.last_issue>='31:1'
			and soi.type='M' and (soi.sub_type='J') and c.no_mail=0
			";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();
//echo $sql;
		while ($row = $sth->fetch()) {
			insertRecord('J', $row);
		}				
		
		donorOnlyList();
		exceptionList();
		intlSubsData();		
	
		// set bulks indicator
		$sql = 'update sos2ss set cen="j" where tag1>1';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();
	
		$db_handle->commit();
	}
	catch (Exception $e) {
		$db_handle->rollback();
	}
	
	function insertRecord($type, $row) {
		global $db_handle;

		// test if record for this customer already exists
		$sql = 'select * from sos2ss where idnumber="' . $row['idnumber'] . '"';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();
		$origRow = $sth->fetch();
		if ($origRow['idnumber'] <> '') {	// it does

//			$delete = false;

			// if new record is newer subdue then update first one
			switch ($type) {
				case 'P': {
					if ($row['subdue'] > $origRow['subdue'])
						$subDue = $row['subdue'];
					else
						$subDue = $origRow['subdue'];
					
					$sql = 'update sos2ss set cen="' . $row['cen'] . '", subdue="' . $subDue . '", subdonor="' . $row['subdonor'] . '", tag1=' . $row['tag1'] . ' where idnumber=' . $row['idnumber'];
					break;
				}
				case 'B': {
					if ($row['bmdue'] > $origRow['bmdue'])
						$subDue = $row['bmdue'];
					else
						$subDue = $origRow['bmdue'];

					$sql = 'update sos2ss set bm="' . $row['bm'] . '", bmdue="' . $subDue . '", subdonor="' . $row['subdonor'] . '", digiemail="'. $row['digiemail'] . '" where idnumber=' . $row['idnumber'];
					break;
				}
				case 'D': {
					if ($row['dmdue'] > $origRow['dmdue'])
						$subDue = $row['dmdue'];
					else
						$subDue = $origRow['dmdue'];
					
					$sql = 'update sos2ss set dm="' . $row['dm'] . '", dmdue="' . $subDue . '", digidonor="' . $row['digidonor'] . '", digiemail="'. $row['digiemail'] . '"where idnumber=' . $row['idnumber'];
					break;
				}
				case 'J': {
					if ($row['tjdue'] > $origRow['tjdue'])
						$subDue = $row['tjdue'];
					else
						$subDue = $origRow['tjdue'];
					
					$sql = 'update sos2ss set tj="' . $row['tj'] . '", tjdue="' . $subDue . '", tjdonor="' . $row['tjdonor'] . '", digijnlemail="' . $row['digijnlemail'] . '", tag2=' . $row['tag2'] . ' where idnumber=' . $row['idnumber'];					
					break;
				}
			}
									
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute();
//echo 'update', $type;
			
		}
		else {				
			$sql = 
				'insert into sos2ss set
				idnumber=?,
				title=?,
				init=?,
				lname=?,
				address1=?, 
				address2=?, 
				town=?,
				pcode=?,
				state=?,
				cname=?,
				phone=?,
				mailcent=?,
				tag1=?,
				tag2=?,
				tag3=?,
				subgiver=?,
				cen=?,
				pn=?,
				upd=?,
				tj=?,
				en=?,
				subdue=?,
				subdonor=?,
				tjdue=?,
				tjdonor=?,
				last_amended=?,
				stats=?,
				country=?,
				email=?,
				newsub_stats=?,
				start_date=?,
				dm=?,
				dmdue=?,
				bm=?,
				bmdue=?,
				digidonor=?,
				digiemail=?,
				digijnlemail=?				
				';
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array(
				$row['idnumber'],
				$row['title'],
				$row['init'],
				$row['lname'],
				$row['address1'],
				$row['address2'],
				$row['town'],
				$row['pcode'],
				$row['state'],
				$row['cname'],
				$row['phone'],
				$row['mailcent'],
				$row['tag1'],
				$row['tag2'],
				$row['tag3'],
				$row['subgiver'],
				$row['cen'],
				$row['pn'],
				$row['upd'],
				$row['tj'],
				$row['en'],
				$row['subdue'],
				$row['subdonor'],
				$row['tjdue'],
				$row['tjdonor'],
				$row['last_amended'],
				$row['stats'],
				$row['country'],
				$row['email'],
				$row['newsub_stats'],
				$row['start_date'],
				$row['dm'],
				$row['dmdue'],
				$row['bm'],
				$row['bmdue'],
				$row['digidonor'],
				$row['digiemail'],
				$row['digijnlemail']
			));
//echo 'new', $type;
		}

echo 'insert: ' . json_encode($row['idnumber'] . $row['digiemail']) . '<br>';

	}
	
	function donorOnlyList() {
		global $db_handle;
				
		$sql = 'select subdonor from sos2ss where subdonor<>""';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute();
		while ($row = $sth->fetch()) {
			$donor = $row['subdonor'];
//			if ($donor != '') {		// donors of any kind only
				
				$sql = 'select idnumber from sos2ss where idnumber=' . $donor;
				$sth2 = $db_handle->prepare($sql);
				$status = $sth2->execute();
				$row2 = $sth2->fetch();
				$found = $row2['idnumber'];
				
echo '<br>looking for: ' . $donor;
				if ($found == '') {	// donor only found
				
					$sql = 'select * from customers where id=' . $donor;
					$sth3 = $db_handle->prepare($sql);
					$status3 = $sth3->execute();
					$row3 = $sth3->fetch();
					$lastName = $row3['last_name'];
					
echo ', missing: ' . $donor . ' ' . $lastName;
					$sql = 'insert into sos2ss set title=?, idnumber=?, cname=?, lname=?, address1=?, address2=?, town=?, country=?, pcode=?, phone=?, email=?';
					$sth4 = $db_handle->prepare($sql);
//echo $sql . '<>';
					$status4 = $sth4->execute(array(
						'',
						$donor,
						$row3['first_name'],
						$lastName,
						$row3['address'],
						$row3['address_2'],
						$row3['city'],
						$row3['country'],
						$row3['postal_code'],
						$row3['phone1'],
						$row3['email1']
					));
				}
//					$found = ' * missing';
//				echo 'looking for ' . $donor . ', found ' . $found .'<br>';
//			}
		}
	}
	
	function exceptionList() {
		global $db_handle;
		
		$sql = "CREATE TABLE IF NOT EXISTS `sos2ss_xtra` (
		  `idnumber` varchar(6) NOT NULL DEFAULT '',
		  `title` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
		  `init` varchar(10) NOT NULL DEFAULT '',
		  `lname` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
		  `address1` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
		  `address2` varchar(50) NOT NULL DEFAULT '',
		  `town` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
		  `pcode` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
		  `state` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
		  `cname` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
		  `phone` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
		  `mailcent` varchar(5) NOT NULL DEFAULT '',
		  `tag1` int(4) NOT NULL,
		  `tag2` int(4) NOT NULL,
		  `tag3` int(4) NOT NULL,
		  `subgiver` varchar(30) NOT NULL,
		  `cen` varchar(1) NOT NULL DEFAULT '0',
		  `pn` int(1) NOT NULL,
		  `upd` int(1) NOT NULL,
		  `tj` int(1) NOT NULL,
		  `en` int(1) NOT NULL,
		  `subdue` varchar(4) NOT NULL DEFAULT '',
		  `subdonor` varchar(6) NOT NULL DEFAULT '',
		  `tjdue` varchar(3) NOT NULL,
		  `tjdonor` varchar(30) NOT NULL,
		  `last_amended` varchar(10) NOT NULL DEFAULT '',
		  `stats` varchar(10) NOT NULL DEFAULT '',
		  `country` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
		  `email` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
		  `newsub_stats` varchar(6) NOT NULL DEFAULT '',
		  `start_date` varchar(10) NOT NULL DEFAULT '',
		  `dm` int(1) NOT NULL,
		  `dmdue` varchar(4) NOT NULL DEFAULT '',
		  `bm` int(1) NOT NULL,
		  `bmdue` varchar(4) NOT NULL DEFAULT '',
		  `digidonor` varchar(30) NOT NULL DEFAULT '',
		  `digiemail` varchar(40) NOT NULL DEFAULT '',
		  `digijnlemail` varchar(40) NOT NULL DEFAULT '',
		  `intoffice_cm` varchar(10) NOT NULL DEFAULT '',
		  `intoffice_jnl` varchar(10) NOT NULL DEFAULT '',		  
		  PRIMARY KEY (`idnumber`),
		  KEY `idnumber` (`idnumber`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();
//die(0);		
		
		$sql = "truncate sos2ss_xtra";
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();
		
		$sql = 'update sos2ss set subdue=4020, subdonor=112281 where idnumber=108825;
					INSERT INTO sos2ss_xtra SELECT * FROM sos2ss WHERE idnumber=108825; 
					update sos2ss_xtra set subdue=3940, subdonor=105469 where idnumber=108825';
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();
		
		$sql = '	INSERT INTO sos2ss_xtra SELECT * FROM sos2ss WHERE idnumber=105025; 
					update sos2ss_xtra set bm=0, bmdue="" where idnumber=105025';
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();
		
		$sql = 'update sos2ss set subdue=4020 where idnumber=109979;
					INSERT INTO sos2ss_xtra SELECT * FROM sos2ss WHERE idnumber=109979; 
					update sos2ss_xtra set subdue=4120, cen=1, tag1=1 where idnumber=109979';
		$sth = $db_handle->prepare($sql);
//echo $sql;
		$status = $sth->execute();
	}		
	
	function intlSubsData() {

		global $db_handle;

		$sql = 'CREATE TABLE IF NOT EXISTS `ig_subs` (
			  `recipient_id` varchar(10) NOT NULL,
			  `donor_id` varchar(10) NOT NULL,
			  `donor_country` varchar(3) NOT NULL,
			  `type` varchar(1) NOT NULL
			) ENGINE=InnoDB DEFAULT CHARSET=latin1';
			$sth = $db_handle->prepare($sql);
//echo $sql;
			$sth->execute();			
			
			$sql = "truncate ig_subs";
			$sth = $db_handle->prepare($sql);
	//echo $sql;
			$status = $sth->execute();			

			$sql = "INSERT INTO `ig_subs` (`recipient_id`, `donor_id`, `donor_country`, `type`) VALUES
			('113836', '93305', 'USA', 'M'),
			('113589', '182203', 'AUS', 'M'),
			('112984', '111064', 'AUS', 'M'),
			('112203', '122469', 'SA', 'M'),
			('106477', '161258', 'USA', 'M'),
			('112501', '117376', 'AUS', 'M'),
			('113311', '46528', 'NZ', 'M'),
			('107824', '121106', 'AUS', 'M'),
			('109808', '158548', 'AUS', 'M'),
			('109078', '171575', 'AUS', 'M'),
			('112828', '182861', 'AUS', 'M'),
			('112669', '59364', 'AUS', 'M'),
			('109564', '44941', 'AUS', 'M'),
			('111380', '4916', 'AUS', 'M'),
			('108651', '44277', 'AUS', 'M'),
			('108825', '229229', 'USA', 'M'),
			('108389', '118303', 'AUS', 'M'),
			('111134', '120801', 'SA', 'M'),
			('112271', '46022', 'CAN', 'M'),
			('111600', '38061', 'AUS', 'M'),
			('109869', '83823', 'AUS', 'M'),
			('110274', '38458', 'AUS', 'M'),
			('109525', '225252', 'USA', 'M'),
			('110051', '110141', 'SA', 'M'),
			('109095', '334003', 'CAN', 'M'),
			('113416', '41009', 'AUS', 'M'),
			('111752', '176031', 'USA', 'M'),
			('107032', '112710', 'AUS', 'M'),
			('113465', '80456', 'AUS', 'M'),
			('108754', '182336', 'AUS', 'M'),
			('111978', '121106', 'AUS', 'M'),
			('107461', '120598', 'AUS', 'M'),
			('113378', '42137', 'AUS', 'M'),
			('110873', '9247', 'AUS', 'M'),
			('111977', '121106', 'AUS', 'M'),
			('111979', '121106', 'AUS', 'M'),
			('113448', '186274', 'USA', 'M'),
			('113502', '189458', 'AUS', 'M'),
			('113415', '60186', 'AUS', 'M'),
			('110777', '149555', 'USA', 'M'),
			('109527', '30615', 'AUS', 'M'),
			('110291', '57950', 'NZ', 'M'),
			('112792', '67311', 'AUS', 'M'),
			('113124', '195931', 'AUS', 'M'),
			('113712', '80943', 'AUS', 'M'),
			('113248', '174633', 'NZ', 'M'),
			('113123', '195931', 'AUS', 'M'),
			('107074', '145879', 'AUS', 'M'),
			('113038', '68156', 'USA', 'M'),
			('113212', '39883', 'AUS', 'M'),
			('113036', '68156', 'USA', 'M'),
			('113121', '195931', 'AUS', 'M'),
			('110830', '340717', 'CAN', 'M'),
			('113040', '68156', 'USA', 'M'),
			('113092', '68156', 'USA', 'M'),
			('113119', '184565', 'AUS', 'M'),
			('111712', '192128', 'USA', 'M'),
			('107724', '172671', 'AUS', 'M'),
			('113122', '195931', 'AUS', 'M'),
			('113211', '20440', 'CAN', 'M'),
			('110778', '149555', 'USA', 'M'),
			('107172', '5304', 'AUS', 'M'),
			('109786', '1596', 'AUS', 'M'),
			('113120', '195931', 'AUS', 'M'),
			('104896', '3508', 'AUS', 'M'),
			('112827', '185045', 'AUS', 'M'),
			('105159', '53776', 'AUS', 'M'),
			('112886', '81836', 'AUS', 'M'),
			('107454', '45288', 'AUS', 'M'),
			('112878', '193057', 'AUS', 'M'),
			('111344', '44058', 'AUS', 'M'),
			('112600', '198735', 'AUS', 'M'),
			('112922', '199236', 'AUS', 'M'),
			('112946', '180273', 'AUS', 'M'),
			('110451', '67203', 'AUS', 'M'),
			('107865', '138792', 'USA', 'J'),
			('112721', '18772', 'CAN', 'J'),
			('111101', '37822', 'CAN', 'J'),
			('108467', '155758', 'USA', 'J'),
			('110628', '360889', 'CAN', 'J')";
			$sth = $db_handle->prepare($sql);
//echo $sql;
			$sth->execute();
	
			$sql = 'update sos2ss ss set intoffice_cm=(select concat(left(donor_country,2),"_",donor_id) from ig_subs where recipient_id=ss.idnumber and type="M" limit 1)';
			$sth = $db_handle->prepare($sql);
//echo $sql;
			$sth->execute();
			
			$sql = 'update sos2ss ss set intoffice_jnl=(select concat(left(donor_country,2),"_",donor_id) from ig_subs where recipient_id=ss.idnumber and type="J" limit 1)';
			$sth = $db_handle->prepare($sql);
//echo $sql;
			$sth->execute();
	}
?>