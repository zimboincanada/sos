<?php
include "db-conx.php";

$name = $_POST['name'];
$content = $_POST['content'];
$eventID = $_POST['eventID'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();

	$sql = 'insert into event_documents set name=?, content=?, event_id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$name, 
		$content,
		$eventID
	));
	
	$result->status = 0;
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);
?>