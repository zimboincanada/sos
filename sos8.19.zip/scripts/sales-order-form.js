function showProductOptions(filter) {
	var sql = '';
	switch(filter) {
		case 'products-minus-subs': {
			prepProductGrid(filter);
			break;
		}
		case 'specials': {
			prepProductGrid(filter);
			break;
		}
		case 'new-subs': {
			prepProductGrid(filter);
			break;
		}
		case 'cust-subs': {
			showSubsForRenewal(false);
			break;
		}
		case 'cust-gift-subs': {
			showSubsForRenewal(true);
			break;
		}
		default: {
			prepProductGrid();
		}
	}		
}

function prepProductGrid(filter) {
	var priceBand = document.getElementById('price-band').value;
	var cols = ['sku','more_info','title','qty','price','type','sub_type','term','shipping_calc','digital','s2_id'];
	var colClass = ['p-sku','p-more-info','p-title','p-qty','p-price','p-type','p-subtype','p-term','p-sc','hidden','hidden'];
	var colHeads = ['SKU','','Title','Qty','Price','','','','','',''];

	switch (priceBand) {
		case '2': { 
			cols.push('wholesale_price'); 
			colHeads.push('Wholesale price');
			break; 
		}
		case '3': { 
			cols.push('staff_price'); 
			colHeads.push('Staff price');
			break; 	
		}
		default: { 
			cols.push('special_price','sp_from','sp_to'); 
			colClass.push('p-special-price','p-sp-from','p-sp-to'); 
			colHeads.push('Sale','From','To');
			break; 
		}
	}
	
	var b = new cb_browse('products-table-container');

	var sql = '';
	switch(filter) {
		case 'products-minus-subs': {
			sql = 'select *, "" as more_info from products where status=1 and type<>"M"';
			break;
		}
		case 'specials': {
			var t = today();
			sql = 'select *, "" as more_info from products where status=1 and left(sp_from,10)<="' + t + '" and left(sp_to,10)>="' + t + '"';
			break;
		}
		case 'new-subs': {
			sql = 'select *, "" as more_info from products where status=1 and type="M" and s2_hide_from_list <> 1';
			break;
		}
		default: {
//console.log('using ths')
			sql = 'select *, "" as more_info from products where status=1';
		}
	}	
	
	b.preQuery = 'create temporary table report (index(sku)) ENGINE=MyISAM (' + sql + ')';
	b.query = 'select * from report';
	b.sortColumn = 'sku';
	b.sortReverse = false;
	b.rowDepth = 20;
	b.height = 200;
	b.columns = cols;
	b.colClass = colClass;
	b.colHeadings = colHeads;
	b.colHeadClass = colClass;
		
	b.rowCallback = function(row, data, json) {
//console.log(row, data, json)		

		var sku = row.children[P_SKU].innerHTML;
		var media = (data[P_TYPE] == 'M' ? 'sub' : getMedia(sku));
		var link = 'http://creation.com/store_redirect.php?sku=' + data[P_SKU];
		row.children[P_SKU].innerHTML = '<div class="p-media" onclick=storeLink(event,"' + link + '")>' + media + '</div>' + data[P_SKU];
		
		// more info, i.e. bom items or bulk prices
		// this may be slow loading and require rework!
		var sql = 'select sum(a.cnt) as count from (select count(*) as cnt from product_boms where parent_sku="' + sku + '" union all select count(*) as cnt from products where sku="' + sku + '" and bulk_prices<>"") a';
//console.log(sql)		
		execSQL(sql, function(data) {
			if (data[0].count > 0)
				row.children[P_MORE_INFO].innerHTML = '<img src="images/more-info.png" style="width: 80%; vertical-align:bottom" title="Click to see bill of materials and any bulk prices" onclick="showMoreProductInfo(event, ' + "'" + sku + "'" + ')">';
		});
		
		// gray out expired prices
		if (today() < data[P_FROM] || today() > data[P_TO]) {
			$(row.children[P_ALT_PRICE]).addClass('gray-out-price');	// price
			$(row.children[P_FROM]).addClass('gray-out-price');	// start date
			$(row.children[P_TO]).addClass('gray-out-price');	// end date
		}

		// only show qty in stock for real products on the shelves
		if (data[P_TYPE] == 'P')
			row.children[P_QTY].innerHTML = data[P_QTY];
		else
			row.children[P_QTY].innerHTML = '';
		
	};
	
	b.fetch = function(data) { 		
		b.searchFocus();

		// mag for self
		if (data[P_TYPE] == 'M') {
			validateMagPurchase(data);
			testForDigiEmail(data);
		}

		var sql = 'select * from products where sku="' + data[0] + '"';
		execSQL(sql, function(data) {
			var product = data[0];
			if (product.qty <= 0 && product.type == 'P' && product.digital == 0) {		// warn if qty on hand <= 0
				confirmBox(
					"CONFIRM", 
					"There are no items in stock -- proceed anyway?", 
					["Yes", "No"],
					[ function() { addItem(product, 'N'); soChanged(); }, function() {} ]
				);
			}
			else {
				var numIssues = 0;		// required for s2
				if (product.type == 'M')
					numIssues = product.term * (product.sub_type == 'J' ? 3 : 4);
				addItem(product, 'N', { s2numIssues: numIssues });
				soChanged();
			}
		});
	};

	b.init();
	b.onComplete = function() { b.searchFocus(); };
}

// show more info, i.e. BOM items and bulk prices
function showMoreProductInfo(e, sku) {
	e.stopPropagation();		// prevent add product to basket

	// bom
	var data = getBOM(sku);
	if (data.length > 0)
		var str = '<b>BILL OF MATERIALS</b><br>';
	else
		var str = '';

	for (var x in data)
		str += data[x][4] + 'x ' + data[x][0] + ' ' + data[x][1] + '<br>';

	// bulk prices
	var bulkPrices = getBulkPrices(sku);
	if (bulkPrices.length > 0)
		str += '<br><b>BULK PRICES</b><br>';
		
	for (var x in bulkPrices)
		str += bulkPrices[x].qty + '+ --- ' + formatCurrency(bulkPrices[x].price) + '<br>';
	
	cb_alert(str);
}

function getBulkPrices(sku) {
	var bulkPrices = [];
	var sql = 'select bulk_prices from products where sku="' + sku + '"';
	execSQL(sql, function(data) {
		if (data[0].bulk_prices != '') {
			var bands = data[0].bulk_prices.split(',');
			for (var x in bands) {
				var data = bands[x].split('-');
				bulkPrices.push({ qty: data[0], price: data[1] });
			}
		}
	}, false);

	return bulkPrices;
}

// show info on BOM products
function showBOM(e, sku) {
	e.stopPropagation();		// prevent add product to basket

	var data = getBOM(sku);
	var str = '';

	for (var x in data)
		str += data[x][4] + 'x ' + data[x][0] + ' ' + data[x][1] + '<br>';
	
	cb_alert(str);
}

function validateMagPurchase(productData) {
	$.ajax({
		type: 'get',
		url: "scripts/get-data.php",
		cache: false,
		data: { 
			query: 'getCurrentSub',
			key: global.customerID,
			sub_type: productData[P_SUBTYPE]
		},
		success: function(data) { 
			switch (true) {
				case data == '': { break; }
				case productData[P_TERM] == 'R' && data[0] > systemSettings.currentPrint: { 
					cb_alert('Warning! This customer has an active subscription.');
					break;
				}
				case (data[0] == '99:4'): {
					cb_alert('Warning! This customer has an active subscription.');
					break;
				}
			}
		},
		error: function (xhr) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});	
}

// if product added is digital, warn if customer does not have email address
function testForDigiEmail(productData) {
	var products = getBOM(productData[P_SKU]);
	var isDigital = (productData[P_DIGITAL] == 1);		// this product is digital

	for (var x in products)
		if (products[x][3])
			isDigital = true;		// a BOM item is digital
		
	if (isDigital && $('#email1').val() == '')
		cb_alert('Magazine recipient does not have an email address for this digital product');
}

function getMedia(sku) {
	var str = sku.substr(0, 4);
	switch (str) {
		case '00-1': { media = 'booklet'; break; }
		case '10-1': 
		case '10-2': 
		case '10-3': { media = 'book'; break; }
		case '20-5': { media = 'cd'; break; }
		case '30-4': { media = 'bluray'; break; }
		case '30-9': { media = 'dvd'; break; }
		case '35-1': { media = 'aud/dl'; break; }
		case '35-4': { media = 'mobi'; break; }
		case '35-5': { media = 'epub'; break; }
		case '35-6': { media = 'vid/dl'; break; }
		case '90-7': { media = 'pack'; break; }
		default: media = 'other';
	}
	return media;
}

function storeLink(e, url) {
	e.stopPropagation();		// prevent add product to basket
	window.open(url, "", "width=700, height=600");
}

// close sales order being edited and re-display list of all orders for the customer
function backToList() {
	if (global.unsavedSalesOrderData) {
		confirmBox(
			"CONFIRM", 
			"You have made changes to this sales order. Do you want to abandon them?", 
			["Yes", "No"],
			[ function() { goBackToList(); }, function() {} ]
		)
	}
	else	
		goBackToList();
}

function goBackToList() {
	global.unsavedSalesOrderData = false;
	document.getElementById('sales-orders').style.display = 'block';
	document.getElementById('so-form').style.display = 'none';
	getSOs();		// refresh the list as there might have been data changes
}

// sales order class
function salesOrder() {
	this.basket = new Array();
	
	// returns true if any products in sales order basket is a sub
	this.hasSubs = function() {
		for (var x in this.basket) {
			if (this.basket[x].magSubID > 0)
				return true;
		}
		return false;
	}

	this.clearBasketTest = function() {
		if (this.hasSubs())
			cb_alert('Cannot clear the basket because there are subscriptions linked to the order.');
		else
			this.clearBasket();
	}
	
	// clear all items from s/o
	this.clearBasket = function() {
		this.basket = [];
		document.getElementById('sales-order').innerHTML = '';
		reCalc();
	}
	
	// re-populate the basket display by reading the data
	this.refreshBasket = function() {
		this.clearBasket();
		this.basket = new Array();
		getData('sales_order_items', global.soNumber, function(data) {
			for (var x in data) {
				addItem(data[x], 'E');
			}	
		});
	}
	
	this.clearBasket();
}

// open the sales order form with data (edit), or blank fields (new)
var oSalesOrder;
function openSO(data) {	
	oSalesOrder = new salesOrder();	

	if (oSettings.s2active) {
		prepProductGrid('products-minus-subs');
		$('#products-filter').val('products-minus-subs');
	}
	else {
		$('#products-filter').hide();
		prepProductGrid();
	}
	
	if (oSettings.use_multiple_payment_types == 1)
		$('#so-multiple-pt').show();

	$('#so-lock-icon').hide();
	$('#so-save').addClass('disabled');
	$('#reset-2').on('change', function() { enableSaveBtn(); });
	
	if (global.soEditMode == 'new') {
		global.soNumber = 0;
		document.getElementById('so-id').innerHTML = '*new*';
		var d = new Date();
		var nd = d.toJSON();
		document.getElementById('so-date-created').innerHTML = formatDate(nd, 1);
		document.getElementById('so-date-created').dateValue = nd.substr(0,10);
		$('#so-updated-by').html(global.user.substr(0,12));
		document.getElementById('so-updated-by').title = global.user;		

		// clear all fields
		document.getElementById('reset-1').reset();	// notes/shipping address
		document.getElementById('reset-2').reset();	// source/payment details
		document.getElementById('so-seminar-payment-options').reset();	// multiple payment options
		
		// make dropdowns empty to force user selection of appropriate values, i.e. no default values
		$('#so-source').val('');
		$('#so-payment-type').val('');
		
		// set some defaults
		$('#so-payment-date').val(today());
		$('#so-popts-type-1').val('');
		$('#so-popts-type-2').val('');
		$('#so-popts-type-3').val('');
		$('#so-popts-type-4').val('');
		$('#so-popts-type-5').val('');
		$('#so-popts-type-6').val('');
		
		pOptsButtonCheck();	
		$('#so-save').show();
		enableSaveBtn();

	}
	else {
		global.soNumber = data.id;
		document.getElementById('so-id').innerHTML = strZero(global.soNumber, 6);
		document.getElementById('so-date-created').innerHTML = formatDate(data.order_date, 1);
		document.getElementById('so-date-created').dateValue = data.order_date.substr(0,10);
		$('#so-updated-by').html(data.updated_by.substr(0,12));
		document.getElementById('so-updated-by').title = data.updated_by;
	
		// populate so form
		for (var x in data)
			oSalesOrder[x] = data[x];
		oSalesOrder.refreshBasket();
		getData('sales_order', global.soNumber, fillWithItems);
	}	
}

// notes/shipping address/source/payment details
function fillWithItems(data) {
	document.getElementById('so-notes').value = data[0];
	document.getElementById('so-source').value = data[1];
	document.getElementById('so-payment-type').value = data[2];
	document.getElementById('so-payment-date').value = data[SO_PAYMENT_DATE].substr(0,10);
	document.getElementById('so-add-info').value = data[3];
	document.getElementById('so-ship-address-1').value = data[4];
	document.getElementById('so-ship-address-2').value = data[5];
	document.getElementById('so-ship-address-3').value = data[6];
	document.getElementById('so-ship-address-4').value = data[7];
	document.getElementById('so-ship-address-5').value = data[8];
	document.getElementById('so-ship-address-6').value = data[9];
	document.getElementById('so-ship-address-7').value = data[10];	
	document.getElementById('so-popts-type-1').value = data[SO_PAYMENT_TYPE_1];	
	document.getElementById('so-popts-amt-1').value = data[SO_PAYMENT_AMOUNT_1];	
	document.getElementById('so-popts-info-1').value = data[SO_PAYMENT_INFO_1];	
	document.getElementById('so-popts-type-2').value = data[SO_PAYMENT_TYPE_2];	
	document.getElementById('so-popts-amt-2').value = data[SO_PAYMENT_AMOUNT_2];	
	document.getElementById('so-popts-info-2').value = data[SO_PAYMENT_INFO_2];	
	document.getElementById('so-popts-type-3').value = data[SO_PAYMENT_TYPE_3];	
	document.getElementById('so-popts-amt-3').value = data[SO_PAYMENT_AMOUNT_3];	
	document.getElementById('so-popts-info-3').value = data[SO_PAYMENT_INFO_3];	
	document.getElementById('so-popts-type-4').value = data[SO_PAYMENT_TYPE_4];	
	document.getElementById('so-popts-amt-4').value = data[SO_PAYMENT_AMOUNT_4];	
	document.getElementById('so-popts-info-4').value = data[SO_PAYMENT_INFO_4];	
	document.getElementById('so-popts-type-5').value = data[SO_PAYMENT_TYPE_5];	
	document.getElementById('so-popts-amt-5').value = data[SO_PAYMENT_AMOUNT_5];	
	document.getElementById('so-popts-info-5').value = data[SO_PAYMENT_INFO_5];	
	document.getElementById('so-popts-type-6').value = data[SO_PAYMENT_TYPE_6];	
	document.getElementById('so-popts-amt-6').value = data[SO_PAYMENT_AMOUNT_6];	
	document.getElementById('so-popts-info-6').value = data[SO_PAYMENT_INFO_6];	
	
	pOptsButtonCheck();		
	
	// if sales order period has been closed, prevent saving changes
	if (data[SO_LOCKDOWN] == 1) {
		$('#so-lock-icon').show();
		$('#so-save').hide();
	}
}

function enableSaveBtn() {
	if (oLogin.sys_admin == 1 || oLogin.edit_sales_order == 1)
		$('#so-save').removeClass('disabled');	
}

function addItem(data, mode, extraData) {
	var subRecipient = 0;
	var subTerm = 0;	
	var s2subSaved = false;
		
	if (mode == 'N') {
		
		enableSaveBtn();
				
		var soiID = '';
		var sku = data.sku;
		var title = data.title;
		var price = data.price;
		var pType = data.type;
		var pSubtype = data.sub_type;
		var shippingCalc = data.shipping_calc;
		var isDigital = data.digital;
		var qty = 1;
		var giftAid = 0;
		var backOrder = 0;
		var s2subID = (extraData == undefined) ? 0 : extraData.s2subID;
		var s2renewal = (extraData == undefined) ? 0 : extraData.s2renewal;
		var s2numIssues = (extraData == undefined) ? 0 : extraData.s2numIssues;	
		var s2startIssue = (extraData == undefined || extraData.s2startIssue == undefined) ? 0 : extraData.s2startIssue;	
		var s2endIssue = (extraData == undefined || extraData.s2endIssue == undefined) ? 0 : extraData.s2endIssue;
		var s2defaultRenewStartIssue = (extraData == undefined || extraData.s2defaultRenewStartIssue == undefined) ? 0 : extraData.s2defaultRenewStartIssue;
		var s2createSub = 0;

		// mag sub data
		var magSubID = 0;
		if (pType == 'M') {	
			subTerm = data.term;
			if (s2renewal == 1)
				subRecipient = extraData.subRecipient;
			else
				subRecipient = global.customerID;
			s2createSub = 1;
		}	
		
		// get default gift aid flag from customer record
		if (pType == 'D')
			giftAid = $('#c-gift-aid').prop('checked') ? 1 : 0;
	}
	else {
		var soiID = data.id;
		var sku = data.sku;
		var title = data.title;
		var price = data.price;
		var pType = data.type;
		var pSubtype = data.sub_type;
		var shippingCalc = data.shipping_calc;
		var isDigital = data.digital;
		var qty = data.qty;
		var giftAid = data.gift_aid;
		var backOrder = data.back_order;
		var s2subID = 0;
		var s2renewal = 0;
		var s2numIssues = data.num_issues;
		var s2createSub = 0;
		var s2startIssue = data.first_issue;
		var s2endIssue = data.last_issue;
		var s2defaultRenewStartIssue = '';

		// mag sub data
		var magSubID = data.mag_sub_id;
		if (pType == 'M') {	
			subRecipient = data.recipient_id;
			s2createSub = data.s2_create_sub;
			s2subSaved = true;
		}		

		$('#so-print').removeClass('disabled');
	}			
	
	var row = document.createElement('tr');
	document.getElementById('sales-order').appendChild(row);
	row.className = 'so-row';

	row.onclick = function() { editSOCheck(this, 'edit'); };

	// sku
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = sku;
	field.className = 'sku';

	// info icon
	field = document.createElement('td');
	row.appendChild(field);
	field.className = 'info-icon';
	if (pType == 'M')
		field.innerHTML = updateSubIcon(s2createSub == 0);
	else
		field.innerHTML = updateBOIcon(backOrder == 1);

	// title
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = title;
	field.className = 'title';
	if (pType == 'M') {		// show sub recipient name on hover

		field.onmouseover = (function(field) { 	
			return function(e) { 
				getMagSubName(row);
			}
		})(field);
		field.onmouseout = (function(field) { 
			return function(e) { 
				$('#so-mag-sub-panel').hide();
			}
		})(field);

	}

	// price
	field = document.createElement('td');
	row.appendChild(field);
	if (mode == 'N' && pType == 'P') {
		switch (document.getElementById('price-band').value) {	
			case '1': {		// standard pricing
				// use special price if in valid date range
				if (today() >= data.sp_from && today() <= data.sp_to)
					price = data.special_price;
				break;
			}
			case '2': {		// wholesale
				price = data.wholesale_price;
				break;
			}
			case '3': {		// staff
				price = data.staff_price;
				break;
			}
			case '4': {		// seminar
				// use special price if in valid date range
				if (oSettings.events_use_special_prices == 1 && today() >= data.sp_from && today() <= data.sp_to)
					price = data.special_price;
				
				// else seminar pricing is full RRP
			}
		}
	}		
	field.innerHTML = formatCurrency(price);
	field.className = 'price';
	
	// product type
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = pType;
	field.className = 'product-type hidden';

	// product subtype
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = pSubtype;
	field.className = 'product-subtype hidden';
	
	// does product qualify for shipping?
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = shippingCalc;
	field.className = 'shipping-calc hidden';

	// digital product?
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = isDigital;
	field.className = 'is-digital hidden';
	
	// gift aid flag (UK only)
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = giftAid;
	field.className = 'gift-aid hidden';

	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = qty;
	field.className = 'qty';

	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = formatCurrency(qty * price);
	field.className = 'line-total';	

	// mag sub ID
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = magSubID;
	field.className = 'mag-sub-id hidden';
		
	// mag sub recipient id + name
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = subRecipient;
	field.className = 'sub-recipient hidden';

	// mag product term
	field = document.createElement('td');
	row.appendChild(field);
	field.innerHTML = subTerm;
	field.className = 'sub-term hidden';

	field = document.createElement('td');
	row.appendChild(field);
	if (global.hasLock) {
		field.innerHTML = 'x';
		field.className = 'delete';
		field.onclick = function(e) { 
			e.stopPropagation();		// prevent edit box popping up
			editSOCheck(this.parentNode, 'delete'); 
		}
	}
	else 
		field.className = 'delete-head';	// hide delete icon

	var data = {
		basketID: oSalesOrder.basket.length,
		s2renewal: s2renewal,
		id: soiID,
		sku: sku,
		title: title,
		qty: qty,
		price: price,
		priceSoldAt: price,
		productType: pType,
		productSubType: pSubtype,
		subRecipient: subRecipient,
		backOrder: backOrder,
		s2subID: s2subID,
		magSubID: magSubID,
		s2numIssues: s2numIssues,
		s2createSub: s2createSub,
		s2subSaved: s2subSaved,
		s2startIssue: s2startIssue,
		s2endIssue: s2endIssue,
		s2defaultRenewStartIssue: s2defaultRenewStartIssue,
		term: subTerm
	};
	oSalesOrder.basket.push(data);
	row.basketID = data.basketID;
	reCalc();

	// force scroll to bottom (last product added)
	var el = document.getElementById("sales-order-parent");
	el.scrollTop = el.scrollHeight;	
	
	return row;
}

// displays an icon (or not) if the item is marked as a back order
function updateBOIcon(isBO) {
	if (isBO)
		return '<img src="images/back-order.png" style="width: 100%; padding-right: 4px; vertical-align: bottom" title="This is a back order">';
	else
		return '<div style="width: 100%; padding-right: 2px"></div>';
}

// displays an icon (or not) if the item is marked as do not create s2 sub
function updateSubIcon(isSub) {
	if (isSub && oSettings.s2active)
		return '<img src="images/no-sub.png" style="width: 100%; padding-right: 4px; vertical-align: bottom" title="Do not create an S2 subscription record">';
	else
		return '<div style="width: 100%; padding-right: 2px"></div>';
}

function editSOCheck(row, mode) {
	var magSubID = row.getElementsByClassName('mag-sub-id')[0].innerHTML;
	var sql = 'select count(*) num, s2_id from mag_subs where id="' + magSubID + '"';
	execSQL(sql, function(data) {	
		if (data[0].num > 0) {
			switch (true) {
				case oSettings.s2active && mode == 'edit': {
					cb_alert('There is a subscription record associated with this item and therefore this line item cannot be changed.');
					break;
				}
				case oSettings.s2active && mode == 'delete': {
					statusMsg('Checking for subscriptions...');
					execS2("getSubscription", data[0].s2_id, function(sub) { 	
						if (sub.status == -2)		// sub is cancelled, so ok to delete
							deleteSOIConfirm(row);
						else
							cb_alert('There is an Active subscription record associated with this item. Set it to Cancelled before this line can be deleted.');
						
					}, false);
					break;
				}
				default: {
					cb_alert('There is a subscription record associated with this item. Please deal with that first before this line can be changed.');
					break;
				}
			}
		}
		else {		// no subs
			if (mode == 'edit')
				editItem(row); 
			else
				removeItem(row); 
		}
	});
}			

function deleteSOIConfirm(row) {
	confirmBox(
		"CONFIRM", 
		"Do you want to delete this line item?", 
		["Yes", "No"],
		[ function() { removeItem(row); }, function() {} ]
	);
}

// display the sub recipient name
function getMagSubName(row) {
	var name = '';
	var custID = oSalesOrder.basket[row.basketID].subRecipient;

	var sql = 'select concat(first_name, " ", last_name) as name from customers c where c.id=' + custID;	
	execSQL(sql, function(data) {
		switch (true) {
			case data.length == 0: {
				name = 'Error: no customer found';		// should never happen
				break;
			}
			case custID == global.customerID: {
				break;
			}
			default: {
				name = 'gift to: ' + data[0].name;
			}
		}
		
		$('#so-mag-sub-name').html(name);
		if (name != '')
			$('#so-mag-sub-panel').show();
	});
}

// remove a s/o row
function removeItem(row) {

	// update the basket object
	oSalesOrder.basket.splice(row.basketID, 1);
	for (var x in oSalesOrder.basket)
		oSalesOrder.basket[x].basketID = x;

	// updated the basket's HTML custom attribute
	document.getElementById('sales-order').removeChild(row);
	var rows = document.getElementsByClassName('so-row');
	for (var x=0; x<rows.length; x++)
		rows[x].basketID = x;

	reCalc();
	soChanged();
	if (oSalesOrder.basket.length > 0)
		enableSaveBtn();	
}

// add new row to s/o, and go straight to editing it
function addCustomItem() {
	var row = addItem({
		sku: 'CUSTOM',
		title: 'Custom Item',
		price: 0, 
		type: 'C', 
		sub_type: '', 
		shipping_calc: 0, 
		digital: 0
	}, 'N');
	
	editItem(row);
	soChanged();
}

function addShipping() {
	if (isShipping())
		statusMsg('Shipping already added.');
	else {
		var row = addItem({
			sku: 'SHIPPING',
			title: 'Shipping',
			price: document.getElementById('so-shipping').value, 
			type: 'S', 
			sub_type: '', 
			shipping_calc: 0, 
			digital: 0
		}, 'N');
		soChanged();
	}
}

// determines if there is a shipping line item
function isShipping() {
	var rows = document.getElementsByClassName('so-row');
	for (var x=0; x<rows.length; x++) {
		if (rows[x].getElementsByClassName('product-type')[0].innerHTML == 'S')
			return true;
	}
	return false;
}

// recalculate and display s/o total incl shipping
function reCalc() {
	var lineTotal, soTotal = 0, shipping;
	var totalForShipping = 0;		// separate tally for products that qualify for shipping
	
	var rows = document.getElementsByClassName('so-row');
	if (rows.length == 0) {
		$('#so-save').addClass('disabled');
		$('#so-print').addClass('disabled');
	}

	for (var x=0; x<rows.length; x++) {
		lineTotal = oSalesOrder.basket[x].qty * oSalesOrder.basket[x].price;
		rows[x].getElementsByClassName('line-total')[0].innerHTML = formatCurrency(lineTotal);

		soTotal += lineTotal;
		
		// not all products qualify for shipping, e.g. donations do not
		if (rows[x].getElementsByClassName('shipping-calc')[0].innerHTML == 1)
			totalForShipping += lineTotal;
	}
	document.getElementById('so-total').innerHTML = formatCurrency(soTotal);

	if (global.isUK)
		shipping = getUKShipping(totalForShipping);
	else
		shipping = getCAShipping(totalForShipping);

	if (oCustomer.price_band == 2)		// wholesale
		$('#so-shipping').val(formatCurrency(99999));		// a large number to draw attention
	else
		$('#so-shipping').val(formatCurrency(shipping));
}

function getCAShipping(totalForShipping) {
	var shipping = totalForShipping * (systemSettings.shippingRate/100);
	if (shipping > systemSettings.shippingMaxValue)
		shipping = systemSettings.shippingMaxValue;
	
	return shipping;
}

function getUKShipping(totalForShipping) {
	var isUK = (global.settings[S_COUNTRY].toUpperCase() == $('#country').val().toUpperCase());

	for (var x=0; x<4; x++) {
		rateToTest = global.settings[S_UK_SHIPPING_BAND_4 - x].split(',')[0];
		if (totalForShipping > rateToTest) {
			if (isUK)
				return global.settings[S_UK_SHIPPING_BAND_4 - x].split(',')[1];
			else
				return global.settings[S_UK_SHIPPING_BAND_4 - x].split(',')[2];
		}
	}
	
	return 0;
}

function paymentTypeTest(el) {
	if (global.isUK) {
		if (el.value == global.settings[S_REPORTS_EXCLUDE_PAYMENT_TYPE])
			cb_alert('If you select this payment type it will be EXCLUDED from financial reports.');
	}
}

// save so header record
function saveSO() {
	if ($('#so-save').hasClass('disabled'))
		return;

	if (!formValidated('reset-2'))
		return;

	// multiple payments validation
	setFirstPaymentType();	
	if (!paymentAmtsMatch()) {
		cb_alert('Multiple payment amounts do not equal the sales order total.');
		return;
	}

	statusMsg('Saving sales order...');
	$('#so-print').removeClass('disabled');		// can only print saved SOs coz the print routine reads from the database	
	$('#so-save').addClass('disabled');	

	var script, query;	
		
	if (global.soEditMode == 'new') {
		script = "insert-data.php";
		query = 'addSalesOrder';
	}
	else {
		script = "update-data.php";
		query = 'updateSalesOrder';
	}
	
	$.ajax({
		type: 'post',
		url: "scripts/" + script,
		cache: false,
		data: { 
			query: query,
			key: global.soNumber,	// only needed for edit mode
			customer_id: global.customerID,
			order_date: document.getElementById('so-date-created').dateValue,
			notes: document.getElementById('so-notes').value,
			source: document.getElementById('so-source').value,
			payment_type: document.getElementById('so-payment-type').value,
			payment_date: document.getElementById('so-payment-date').value,
			add_info: document.getElementById('so-add-info').value,
			ship_address_1: document.getElementById('so-ship-address-1').value,
			ship_address_2: document.getElementById('so-ship-address-2').value,
			ship_address_3: document.getElementById('so-ship-address-3').value,
			ship_address_4: document.getElementById('so-ship-address-4').value,
			ship_address_5: document.getElementById('so-ship-address-5').value,
			ship_address_6: document.getElementById('so-ship-address-6').value,
			ship_address_7: document.getElementById('so-ship-address-7').value,
			payment_type_1: document.getElementById('so-popts-type-1').value,
			payment_amount_1: document.getElementById('so-popts-amt-1').value,
			payment_info_1: document.getElementById('so-popts-info-1').value,
			payment_type_2: document.getElementById('so-popts-type-2').value,
			payment_amount_2: document.getElementById('so-popts-amt-2').value,
			payment_info_2: document.getElementById('so-popts-info-2').value,
			payment_type_3: document.getElementById('so-popts-type-3').value,
			payment_amount_3: document.getElementById('so-popts-amt-3').value,
			payment_info_3: document.getElementById('so-popts-info-3').value,
			payment_type_4: document.getElementById('so-popts-type-4').value,
			payment_amount_4: document.getElementById('so-popts-amt-4').value,
			payment_info_4: document.getElementById('so-popts-info-4').value,
			payment_type_5: document.getElementById('so-popts-type-5').value,
			payment_amount_5: document.getElementById('so-popts-amt-5').value,
			payment_info_5: document.getElementById('so-popts-info-5').value,
			payment_type_6: document.getElementById('so-popts-type-6').value,
			payment_amount_6: document.getElementById('so-popts-amt-6').value,
			payment_info_6: document.getElementById('so-popts-info-6').value,
			updated_by: global.user
		},
		success: function(result) { 
			if (global.soEditMode == 'new') {		// database returns new unique id
				global.soNumber = result;
				document.getElementById('so-id').innerHTML = strZero(global.soNumber, 6);
			}
			
			saveSOItems();
			
			if (global.isCA)
				writeShippingSystemData();

			global.soEditMode = 'edit';						// change mode to edit once new one has been saved
			global.unsavedSalesOrderData = false;	// so no warning on leaving page
			
			// update the screen
			$('#so-updated-by').html(global.user);			
			oSalesOrder.updated_by = global.user;
		},
		error: function (xhr) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});		
}

/* 	save each product line	
	
	when updating a SO, first remove all the so items, then add back what is currently in the
	products selected list (easier than trying to establish what's changed line by line)
*/
function saveSOItems() {
	var isSeminarCustomer = ($('#price-band').val() == 4);
	var soiData = new Array();
	var msData = new Array();
	var rows = document.getElementsByClassName('so-row');
	
	for (var x=0; x<rows.length; x++) {
		var sku = rows[x].getElementsByClassName('sku')[0].innerHTML;
		var productType = rows[x].getElementsByClassName('product-type')[0].innerHTML;
		var productSubType = rows[x].getElementsByClassName('product-subtype')[0].innerHTML;		
		var magSubID = rows[x].getElementsByClassName('mag-sub-id')[0].innerHTML;
		var magRecipientID = rows[x].getElementsByClassName('sub-recipient')[0].innerHTML;
		
		// first time creation of mag sub record; once created never changed from within sales order screen			
		msData[x] = new Array(8);
		msData[x][0] = magRecipientID;
		msData[x][1] = rows[x].getElementsByClassName('sub-term')[0].innerHTML;
		msData[x][6] = '';		// 2nd row sku for mag sub
	
		if (productType == 'M' && magSubID == 0) {
			var subData;
			if (oSettings.s2active)
				subData = [oSalesOrder.basket[x].s2startIssue, oSalesOrder.basket[x].s2endIssue, '', '1'];
			else
				subData = calculateSubs(
					'N', 
					magRecipientID, 
					productSubType, 	
					msData[x][1], 	
					'', 
					magRecipientID != global.customerID, 
					$('#so-source').val()
				);
			msData[x][2] = subData[0];		// 1st issue
			msData[x][3] = subData[1];		// last issue
			msData[x][4] = 1;					// active
			msData[x][5] = subData[2];		// notes
			msData[x][6] = subData[3];		// issue status
		}

		soiData[x] = new Array(13);
		soiData[x][0] = global.soNumber;		// sales order #
		soiData[x][1] = sku;
		soiData[x][2] = rows[x].getElementsByClassName('title')[0].innerHTML;
		soiData[x][3] = rows[x].getElementsByClassName('price')[0].innerHTML;		
		soiData[x][4] = rows[x].getElementsByClassName('qty')[0].innerHTML;		
		soiData[x][5] = productType;
		soiData[x][6] = productSubType;		
		soiData[x][7] = rows[x].getElementsByClassName('shipping-calc')[0].innerHTML;		
		soiData[x][8] = magSubID;
		soiData[x][9] = rows[x].getElementsByClassName('gift-aid')[0].innerHTML;
		soiData[x][10] = rows[x].getElementsByClassName('is-digital')[0].innerHTML;
		soiData[x][11] = oSalesOrder.basket[x].backOrder;
		soiData[x][12] = oSalesOrder.basket[x].s2subID;		
		soiData[x][13] = oSalesOrder.basket[x].s2renewal;		
		soiData[x][14] = oSalesOrder.basket[x].s2numIssues;		
		soiData[x][15] = oSalesOrder.basket[x].s2createSub;
		soiData[x][16] = oSalesOrder.basket[x].s2startIssue;
		soiData[x][17] = oSalesOrder.basket[x].s2endIssue;
	}

	$.ajax({
		type: 'post',
		url: "scripts/insert-data.php",
		cache: false,
		data: { 
			query: "addSalesOrderItems",
			salesOrder: global.soNumber,
			create_mags: !isSeminarCustomer,		// do not create mag sub records if customer type=seminar
			soi_data: soiData,
			ms_data: msData,
			customerID: global.customerID
		},
		success: function(result) { 
			execS2("updateS2", '', function() {
				oCustomer.refreshData();
			});			
			updateDonationsTotal();			// because this order may have a donation			
		},
		error: function (xhr) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});	
}

function updateDonationsTotal() {
	$.ajax({
		type: 'get',
		url: "scripts/get-data.php",
		cache: false,
		data: { 
			query: "getDonations",
			key: global.customerID
		},
		success: function(result) {
			// refresh the basket from the database
			oSalesOrder.refreshBasket();
			
			statusMsg('Sales order saved.');
			document.getElementById('donations-total').innerHTML = formatCurrency(result[0]);
		},
		error: function(xhr) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});	
}

function soChanged() {
	global.unsavedSalesOrderData = true;
	$('#so-print').addClass('disabled');
	$('#so-save').removeClass('disabled');
}

function writeShippingSystemData() {
	var isShippingAddress = false;		// assume use customer address
	var sa = new Array();

	// but prepare to use shipping address
	for (var x=1; x<8; x++) {
		var field = '#so-ship-address-' + x;
		sa[x-1] = $(field).val();
		if ($(field).val() != '')
			isShippingAddress = true;
	}
	
	if (!isShippingAddress) {
		sa[0] = $('#salutation').val() + ' ' + $('#first-name').val() + ' ' + $('#last-name').val();
		sa[1] = $('#organization').val();
		sa[2] = $('#address').val();
		sa[3] = $('#city').val();
		sa[4] = $('#province').val();
		sa[5] = $('#postal-code').val();
		sa[6] = $('#country').val();
	}

	// update new canada post shipping system interface file	
	var cCode = '';
	switch (sa[6].toUpperCase()) {
		case 'CANADA': { cCode = 'CA'; break; }
		case 'USA': { cCode = 'US'; break; }
		default: {
			cb_alert("No shipping data will be created for this sales order because the country=" + sa[6] +". <br><br>Valid countries are 'Canada' and 'USA'");
			return;
		}
	}
	
	$.ajax({
		type: 'post',
		url: "scripts/insert-data.php",
		cache: false,
		data: { 
			query: "updateCanadaPost",
			sales_order: global.soNumber,
			name: sa[0],
			company_name:sa[1],
			address: sa[2],
			city: sa[3],
			province: sa[4],
			postal_code: sa[5],
			country_code: cCode
		},
		success: function(result) { 
//			alert('updated canada post')
		},
		error: function (xhr) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});	
}
	
function getSetDate(mode, elem) {
	if (mode == 1) {
		var cal = document.querySelector('#so-order-date');
		cal.focus();
		openDatePicker(cal);
	}
	else {
		document.getElementById('so-date-created').innerHTML = formatDate(elem.value, 1);
		document.getElementById('so-date-created').dateValue = elem.value;
		soChanged();
	}
}

function openDatePicker(inputDateElem) {
    var ev = document.createEvent('KeyboardEvent');
    ev.initKeyboardEvent('keydown', true, true, document.defaultView, 'F4', 0);
    inputDateElem.dispatchEvent(ev);
}
