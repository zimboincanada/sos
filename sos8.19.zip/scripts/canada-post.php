<?php
/* Creates a text file for the shipping system to read and populate screen with address data
*/
include "db-conx.php";

$array = array();
$sql = "select * from canada_post
			 where left(save_date,10)>=?
			 and left(save_date,10)<=?";
$sth = $db_handle->prepare($sql);
if ($sth->execute(array($_GET['start_date'], $_GET['end_date']))) {
	$counter = 0;
	while ($row = $sth->fetch()) {
		$array[$counter][0] = 6;
		$array[$counter][1] = $row['sales_order'];
		$array[$counter][2] = '';
		$array[$counter][3] = '';
		$array[$counter][4] = '';
		$array[$counter][5] = $row['name'];
		$array[$counter][6] = '';
		$array[$counter][7] = $row['company_name'];
		$array[$counter][8] = '';
		$array[$counter][9] = $row['address'];
		$array[$counter][10] = '';
		$array[$counter][11] = $row['city'];
		$array[$counter][12] = $row['province'];
		$array[$counter][13] = $row['postal_code'];
		$array[$counter][14] = $row['country_code'];
		for ($x=15; $x < 66; $x++)
			$array[$counter][$x] = '';
		$array[$counter][23] = 967;		// expedited service
		$array[$counter][63] = 0;
		
		$counter++;
	}		
	
	$filename = $_GET['filename'];
	$f = fopen($filename, 'w');
	foreach ($array as $line) {
		fputcsv($f, $line);
	}
	fclose($f);
	
	echo 1;
}
else echo 0;
?>