function init() {		
	if (!oLogin.hasMenuRights('3'))
		window.location.href = 'index.html';

	global.helpTopic = 'settings';
	fillPicklist('subs-source-to-exclude-sub', S_SO_SOURCE, function() {});
	
	fillPicklist('donation-default-source', S_SO_SOURCE, function() {
		getData('getSettings', '', function(data) { 
			fillPicklist('reports-exclude-payment-type', S_PAYMENT_METHOD, function() {
				fillFields(data); 
				showTab(oLogin.getFirstVisibleTabByClass('tab-label'));
			});

			if (global.isUK) {
				$('#eu-countries-label').show();
				$('#reports-exclude-payment-type-label').show();
			}
		});
	});
}

function fillFields(data) {
	$('#shipping-rate-pct').val(oSettings.shipping_rate_pct);
	document.getElementById('shipping-rate-max').value = data[1];
	document.getElementById('shipping-folder').value = data[S_SHIPPING_FOLDER];
	document.getElementById('backup-folder').value = data[S_BACKUP_FOLDER];
	$('#login-timeout').val(oSettings.login_timeout);
	
	document.getElementById('salutation').value = data[5];
	document.getElementById('customer-source').value = data[2];
	document.getElementById('payment-method').value = data[3];
	document.getElementById('sales-order-source').value = data[4];
	document.getElementById('recurring-donations').value = data[S_RECURRING_DONATIONS];

	document.getElementById('default-country').value = data[S_COUNTRY];
	document.getElementById('countries').value = data[S_COUNTRIES];
	document.getElementById('eu-countries').value = data[S_EU_COUNTRIES];
	document.getElementById('reports-exclude-payment-type').value = data[S_REPORTS_EXCLUDE_PAYMENT_TYPE];
	
	document.getElementById('cmi-address-1').value = data[6];
	document.getElementById('cmi-address-2').value = data[7];
	document.getElementById('cmi-address-3').value = data[8];
	document.getElementById('cmi-address-4').value = data[9];
	document.getElementById('cmi-address-5').value = data[10];
	document.getElementById('cmi-address-6').value = data[11];
	
	document.getElementById('multiple-pt').checked = (oSettings.use_multiple_payment_types == 1);
	document.getElementById('sales-order-gridlines').checked = (oSettings.sales_order_gridlines == 1);
	document.getElementById('sales-order-events-use-special-prices').checked = (oSettings.events_use_special_prices == 1);
	document.getElementById('sales-order-footer').value = data[12];
	$('#back-order-footer').val(oSettings.back_order_slip_text);
	
	document.getElementById('donation-default-source').value = data[S_DONATION_DEFAULT_SOURCE];
	$('#donation-min-amount').val(oSettings.donation_min_amount);
	document.getElementById('donation-letter-1').value = data[S_DONATION_LETTER];
	var text = (oSettings.donation_receipt_footer == '') ? '...' : oSettings.donation_receipt_footer;
//console.log('text=>' + text + '<')		
	$('#donation-letter-2').val(text);
	
	document.getElementById('subs-current-print').value = data[S_CURRENT_PRINT];
	document.getElementById('subs-current-digital').value = data[S_CURRENT_DIGITAL];
	document.getElementById('subs-current-journal').value = data[S_CURRENT_JOURNAL];
	document.getElementById('subs-cut-off-period-p').checked = (data[S_CUT_OFF_PERIOD] == 1);
	document.getElementById('subs-cut-off-period-j').checked = (data[S_CUT_OFF_PERIOD_J] == 1);
	document.getElementById('subs-cut-off-period-d').checked = (data[S_CUT_OFF_PERIOD_D] == 1);
	document.getElementById('subs-country-code').value = data[S_SUBS_COUNTRY_CODE];
	document.getElementById('subs-letters-margin').value = data[S_SUBS_LETTERS_MARGIN];
	document.getElementById('subs-gift-renewal-margin').value = data[S_SUBS_GIFT_RENEWAL_MARGIN];
	document.getElementById('subs-source-to-exclude-sub').value = data[S_SOURCE_TO_EXCLUDE_SUB];
	$('#subs-use-s2').prop('checked', oSettings.s2active == 1);
	$('#subs-sos-server-name').val(oSettings.sos_server_name);
	document.getElementById('subs-letter-1').value = data[S_WELCOME_LETTER];
	document.getElementById('subs-letter-2').value = data[S_GIFT_LETTER];
	document.getElementById('subs-letter-3').value = data[S_GIFT_RENEWAL_LETTER];
	document.getElementById('subs-letter-4').value = data[S_WELCOME_LETTER_J];
	document.getElementById('subs-letter-5').value = data[S_GIFT_LETTER_J];
	document.getElementById('subs-letter-6').value = data[S_GIFT_RENEWAL_LETTER_J];
	
	document.getElementById('tax-band-1').value = data[S_TAX_BAND_1];
	document.getElementById('tax-band-2').value = data[S_TAX_BAND_2];
	document.getElementById('tax-band-3').value = data[S_TAX_BAND_3];
	document.getElementById('tax-band-4').value = data[S_TAX_BAND_4];
	document.getElementById('tax-band-label-1').value = data[S_TAX_BAND_LABEL_1];
	document.getElementById('tax-band-label-2').value = data[S_TAX_BAND_LABEL_2];
	document.getElementById('tax-band-label-3').value = data[S_TAX_BAND_LABEL_3];
	document.getElementById('tax-band-label-4').value = data[S_TAX_BAND_LABEL_4];
	
	$('#uk-shipping-band-1').val(data[S_UK_SHIPPING_BAND_1].split(',')[0]);
	$('#uk-shipping-band-1-uk').val(data[S_UK_SHIPPING_BAND_1].split(',')[1]);
	$('#uk-shipping-band-1-eu').val(data[S_UK_SHIPPING_BAND_1].split(',')[2]);
	$('#uk-shipping-band-2').val(data[S_UK_SHIPPING_BAND_2].split(',')[0]);
	$('#uk-shipping-band-2-uk').val(data[S_UK_SHIPPING_BAND_2].split(',')[1]);
	$('#uk-shipping-band-2-eu').val(data[S_UK_SHIPPING_BAND_2].split(',')[2]);
	$('#uk-shipping-band-3').val(data[S_UK_SHIPPING_BAND_3].split(',')[0]);
	$('#uk-shipping-band-3-uk').val(data[S_UK_SHIPPING_BAND_3].split(',')[1]);
	$('#uk-shipping-band-3-eu').val(data[S_UK_SHIPPING_BAND_3].split(',')[2]);
	$('#uk-shipping-band-4').val(data[S_UK_SHIPPING_BAND_4].split(',')[0]);
	$('#uk-shipping-band-4-uk').val(data[S_UK_SHIPPING_BAND_4].split(',')[1]);
	$('#uk-shipping-band-4-eu').val(data[S_UK_SHIPPING_BAND_4].split(',')[2]);		
	
	$('#ms-church-status').val(oSettings.church_status);
	$('#ms-church-denominations').val(oSettings.church_denominations);
	$('#ms-presentation-type').val(oSettings.presentation_type);
	$('#ms-event-status').val(oSettings.event_status);
	$('#ms-event-source').val(oSettings.event_source);
	$('#ms-regions').val(oSettings.regions);
	$('#ms-event-document-status').val(oSettings.document_status);

	$('#po-pmq').val(oSettings.pmq);
	$('#po-poq').val(oSettings.poq);
	$('#po-calc-months').val(oSettings.po_calc_months);
	$('#inv-use-pack-assembly').prop('checked', oSettings.use_pack_assembly == 1);
	
	tinymce.init({ 
		selector: 'textarea#donation-letter-1',
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "paste print preview media | forecolor backcolor fontselect fontsizeselect",
		image_advtab: true,
		height: 570				
	});
	tinymce.init({ 
		selector: 'textarea#donation-letter-2',
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
		image_advtab: true,
		height: 270				
	});

	tinymce.init({ 
		selector: 'textarea#subs-letter-1',
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
		image_advtab: true,
		height: 270				
	});
	tinymce.init({ 
		selector: 'textarea#subs-letter-2',
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
		image_advtab: true,
		height: 270				
	});
	tinymce.init({ 
		selector: 'textarea#subs-letter-3',
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
		image_advtab: true,
		height: 270				
	});
	tinymce.init({ 
		selector: 'textarea#subs-letter-4',
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
		image_advtab: true,
		height: 270				
	});
	tinymce.init({ 
		selector: 'textarea#subs-letter-5',
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
		image_advtab: true,
		height: 270				
	});
	tinymce.init({ 
		selector: 'textarea#subs-letter-6',
		theme: "modern",
		plugins: [
			"advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
		image_advtab: true,
		height: 270				
	});
	
	getEventTodoDefaults();
}

function getEventTodoDefaults() {
//console.log('get')		
	var sql = 'select * from event_todo_item_defaults';
	$('#ms-todo-defaults').html('');
	$("#ms-todo-defaults").sortable();		// drag and drop
											
	execSQL(sql, function(data) {	
		for (var x in data) {
//console.log(data[x])
			addEventTodoItem(data[x]);
		}
	});
}

function addEventTodoItem(data) {
//console.log('b=',$('#ms-todo-defaults').children().length)				

	var line = document.createElement('li');
	document.getElementById('ms-todo-defaults').appendChild(line);
	line.className = "ui-state-default";

	var handle = document.createElement('span');
	line.appendChild(handle);
	handle.className = "ms-todo-handle";
	handle.innerHTML = '&udarr;';		
	
	var item = document.createElement("input");
	item.innerHTML = data.item;
	item.value = data.item;
	item.className = 'ms-todo-item';
	line.appendChild(item);
	
	var offset = document.createElement("input");
	offset.type = "number";
	offset.value = data.offset_from_date;
	offset.className = 'ms-todo-date-offset';
	line.appendChild(offset);
	
	var dd = document.createElement("select");
	dd.className = 'ms-todo-date-type';
	var newOption = document.createElement("option");
	newOption.text = 'Booking';
	newOption.selected = data.offset_date_type == 'B';
	dd.appendChild(newOption);		
	var newOption = document.createElement("option");
	newOption.text = 'Event';
	newOption.selected = data.offset_date_type == 'E';
	dd.appendChild(newOption);				
	line.appendChild(dd);
	
	var canx = document.createElement('span');
	line.appendChild(canx);
	canx.innerHTML = "x";
	canx.className = "ms-todo-canx";0
	canx.onclick = function() {
		$(line).remove();
	}				
}	

function saveSettings() {
	$('#donation-letter-1').val(tinymce.get('donation-letter-1').getContent());
	
	$.ajax({
		type: 'post',
		url: "scripts/update-data.php",
		cache: false,
		data: { 
			query: 'saveSettings',
			key: 1,
			shipping_rate_pct: document.getElementById('shipping-rate-pct').value,
			shipping_rate_max: document.getElementById('shipping-rate-max').value,
			shipping_folder: document.getElementById('shipping-folder').value,
			salutation: document.getElementById('salutation').value,
			customer_source: document.getElementById('customer-source').value,
			payment_method: document.getElementById('payment-method').value,
			sales_order_source: document.getElementById('sales-order-source').value,
			recurring_donations: document.getElementById('recurring-donations').value,
			country: document.getElementById('default-country').value,
			countries: document.getElementById('countries').value,
			eu_countries: document.getElementById('eu-countries').value,
			reports_exclude_payment_type: document.getElementById('reports-exclude-payment-type').value,				
			backup_folder: document.getElementById('backup-folder').value,
			cmi_address_1: document.getElementById('cmi-address-1').value,
			cmi_address_2: document.getElementById('cmi-address-2').value,
			cmi_address_3: document.getElementById('cmi-address-3').value,
			cmi_address_4: document.getElementById('cmi-address-4').value,
			cmi_address_5: document.getElementById('cmi-address-5').value,
			cmi_address_6: document.getElementById('cmi-address-6').value,
			use_multiple_payment_types: (document.getElementById('multiple-pt').checked ? 1 : 0),
			sales_order_gridlines: (document.getElementById('sales-order-gridlines').checked ? 1 : 0),
			events_use_special_prices: (document.getElementById('sales-order-events-use-special-prices').checked ? 1 : 0),
			sales_order_footer: document.getElementById('sales-order-footer').value,
			back_order_slip_text: $('#back-order-footer').val(),
			donation_default_source: document.getElementById('donation-default-source').value,
			donation_min_amount: $('#donation-min-amount').val(),
			donation_letter: tinymce.get('donation-letter-1').getContent(),
			donation_receipt_footer: tinymce.get('donation-letter-2').getContent(),
			current_print: document.getElementById('subs-current-print').value,
			current_digital: document.getElementById('subs-current-digital').value,
			current_journal: document.getElementById('subs-current-journal').value,
			cut_off_period_p: (document.getElementById('subs-cut-off-period-p').checked ? 1 : 0),
			cut_off_period_j: (document.getElementById('subs-cut-off-period-j').checked ? 1 : 0),
			cut_off_period_d: (document.getElementById('subs-cut-off-period-d').checked ? 1 : 0),
			subs_country_code: document.getElementById('subs-country-code').value,
			subs_letters_margin: document.getElementById('subs-letters-margin').value,
			subs_gift_renewal_margin: document.getElementById('subs-gift-renewal-margin').value,
			subs_source_to_exclude_sub: document.getElementById('subs-source-to-exclude-sub').value,
			s2active: ($('#subs-use-s2').is(':checked') ? 1 : 0),
			sos_server_name: $('#subs-sos-server-name').val(),
			welcome_letter: tinymce.get('subs-letter-1').getContent(),
			gift_letter: tinymce.get('subs-letter-2').getContent(),
			gift_renewal_letter: tinymce.get('subs-letter-3').getContent(),
			welcome_letter_j: tinymce.get('subs-letter-4').getContent(),
			gift_letter_j: tinymce.get('subs-letter-5').getContent(),
			gift_renewal_letter_j: tinymce.get('subs-letter-6').getContent(),
			tax_band_1: document.getElementById('tax-band-1').value,
			tax_band_2: document.getElementById('tax-band-2').value,
			tax_band_3: document.getElementById('tax-band-3').value,
			tax_band_4: document.getElementById('tax-band-4').value,
			tax_band_label_1: document.getElementById('tax-band-label-1').value,
			tax_band_label_2: document.getElementById('tax-band-label-2').value,
			tax_band_label_3: document.getElementById('tax-band-label-3').value,
			tax_band_label_4: document.getElementById('tax-band-label-4').value,
			uk_shipping_band_1: $('#uk-shipping-band-1').val() + ',' + $('#uk-shipping-band-1-uk').val() + ',' + $('#uk-shipping-band-1-eu').val(),
			uk_shipping_band_2: $('#uk-shipping-band-2').val() + ',' + $('#uk-shipping-band-2-uk').val() + ',' + $('#uk-shipping-band-2-eu').val(),
			uk_shipping_band_3: $('#uk-shipping-band-3').val() + ',' + $('#uk-shipping-band-3-uk').val() + ',' + $('#uk-shipping-band-3-eu').val(),
			uk_shipping_band_4: $('#uk-shipping-band-4').val() + ',' + $('#uk-shipping-band-4-uk').val() + ',' + $('#uk-shipping-band-4-eu').val(),
			login_timeout: $('#login-timeout').val(),
			church_status: $('#ms-church-status').val(),
			church_denominations: $('#ms-church-denominations').val(),
			presentation_type: $('#ms-presentation-type').val(),
			event_status: $('#ms-event-status').val(),
			event_source: $('#ms-event-source').val(),
			regions: $('#ms-regions').val(),
			document_status: $('#ms-event-document-status').val(),
			eventTodos: setEventTodoDefaults(),
			pmq: $('#po-pmq').val(),
			poq: $('#po-poq').val(),
			po_calc_months: $('#po-calc-months').val(),
			use_pack_assembly: (document.getElementById('inv-use-pack-assembly').checked ? 1 : 0)
		},
		success: function(result) { 		
//console.log(result)			
			statusMsg('Settings saved.');		
		},
		error: function (xhr, ajaxOptions, thrownError) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});	
}

function setEventTodoDefaults() {
	var defaults = [];
	for (var x=0; x<$('#ms-todo-defaults').children().length; x++) {
		var item = document.getElementsByClassName('ms-todo-item')[x].value;
		var offsetType = document.getElementsByClassName('ms-todo-date-type')[x].value;
		var offsetDays = document.getElementsByClassName('ms-todo-date-offset')[x].value;
		defaults.push([item, offsetType, offsetDays]);
	}
	
	return defaults;
}

function showTab(number) {
	for (var x=1; x<10; x++) {
		var tab = 'settings-label-' + x;
		var tabContent = 'settings-content-' + x;

		$('#' + tab).removeClass('active');
		$('#' + tabContent).hide();
		if (x == number) {
			$('#' + tab).addClass('active');
			$('#' + tabContent).show();

			if (x == 2) {
				if (global.isUK)
					$('#uk-shipping-table').show();
				else
					$('#ca-shipping-table').show();
			}
			
			if (x == 6) {
				$("#subs-current-print").mask("99:9");
				$("#subs-current-digital").mask("99:9");
				$("#subs-current-journal").mask("99:9");

				showSubsLetter(1);
			}
			
			if (x == 5)
				showDonationText(1);
				
			if (x == 8)
				global.setTabActive('ms-tab-1', 'ms-panel-1');
		}
					
		if (x == 5 && global.isUK)	// UK does not have an official tax receipt
			$('#donation-letter-title-2').hide();
		
		if (x == 6)
			showS2Dataset();	
	}
}

function showSubsLetter(number) {
	for (var x=1; x<7; x++) {
			
		var tab = 'subs-letter-title-' + x;
		var tabContent = 'subs-letter-' + x;
		
		$('#' + tab).removeClass('active');
		var editorID = $("#" + tabContent).attr('id');		
		tinymce.get(editorID).hide();		
		tinymce.DOM.hide(editorID);
		if (x == number) {
			$('#' + tab).addClass('active');
			tinymce.get(editorID).show();		
		}			
	}
}	

function showDonationText(number) {
	for (var x=1; x<3; x++) {		
		var tab = 'donation-letter-title-' + x;
		var tabContent = 'donation-letter-' + x;
		
		$('#' + tab).removeClass('active');
		var editorID = $("#" + tabContent).attr('id');		
		tinymce.get(editorID).hide();		
		tinymce.DOM.hide(editorID);
		if (x == number) {
			$('#' + tab).addClass('active');
			tinymce.get(editorID).show();		
		}			
	}	
}

function showS2Dataset() {
	if (oSettings.s2active)
		var str = getS2DataSet();
	else
		var str = 'n/a';
	$('#subs-s2-dataset-text').html('S2 Database =  ' + str.toUpperCase());
}