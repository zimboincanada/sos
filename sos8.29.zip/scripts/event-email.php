<?php
/* 	Sends an email

	usage:
	$.post('send-mail.php', { caller: 'MINIMAX', to: 'addressee email', subject: 'Subject of email', message: 'body of email' }, function() {});
	
	params:
	caller = must be 'mini': to prevent unintended running of this script and sending unwanted emails
	to, subject, message = self-evident
*/
include "db-conx.php";

error_reporting(-1);
ini_set('display_errors', 'On');
//ini_set("SMTP","smtp.gmail.com");
//ini_set("smtp_port","25");
/*
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";	
$headers .= "From: minimax@minimax.com";
mail('c.baines@creation.info', 'test from minimax', 'test message, custard alert', $headers);
die(0);
*/

$alerts = new eventEmail();

$alerts->getAlertParams();

//$today = '2017-09-05';
class eventEmail {
	public function getAlertParams() {
		global $db_handle;
		
		$eventData = new stdClass();
		$sql = 'select * from settings';
		$st = $db_handle->prepare($sql);
		$status = $st->execute();
		$settings = $st->fetch();

echo $settings['event_alert_emails'], $settings['event_alert_long_notice'];

		$this->addressees = $settings['event_alert_emails'];

		$noticePeriodInDays = '+ ' . $settings['event_alert_long_notice'] . ' day';
//$eventDate = $today + $noticePeriodInDays;

		$eventDate = new DateTime($noticePeriodInDays);	// i.e. today + number of days notice
echo $eventDate->format('Y-m-d'); 	// e.g. 2017-09-05

echo '<br>', $noticePeriodInDays, $eventDate->format('Y-m-d');
//die(0);
		$this->getData($eventDate->format('Y-m-d'));	// e.g. 2017-09-05
	}

	public function getData($alertDate) {
		global $db_handle;
		
		$eventData = new stdClass();
		$sql = 'select *, date_format(e.event_date, "%D %M %Y (%W)") as e_date, 
					(select group_concat(speaker) from event_talks where event_id=e.id) as speakers, 
					(select group_concat(talk) from event_talks where event_id=e.id) as talks from events e 
					where e.event_date="' . $alertDate . '"';
		$st = $db_handle->prepare($sql);
		$status = $st->execute();

		while ($event = $st->fetch()) {

echo $event['event_date'] . '<br>';
			$eventData->eventDate = $event['e_date'];
			$eventData->attendanceExpected = $event['attendance_expected'];
			$eventData->address = $event['address'];
			$eventData->city = $event['city'];
			$eventData->county = $event['county'];
			$eventData->speakers = $event['speakers'];
			$eventData->talks = $event['talks'];
			
			$this->constructMail($eventData);
		}
	}

	public function constructMail($eventData) {
		$to = $this->addressees;
		$message = '<div style="border: 1px solid black; padding: 10px; margin-bottom: 10px;">Upcoming event alert!</div>';
		$message .= 'Speaker: <b>' . $eventData->speakers . '</b><br>';
		$message .= 'Event date: <b>' . $eventData->eventDate . '</b><br>';
		$message .= 'Venue: <b>' . $eventData->address . ', ' . $eventData->city . ', ' . $eventData->county . '</b><br>';
		$message .= 'Talk title: <b>' . $eventData->talks . '</b><br>';
		$message .= 'Expected attendance: <b>' . $eventData->attendanceExpected . '</b><br>';

		$this->sendMail($to, $message);
echo $to, $message;
	}

	public function sendMail($to, $message) {
//		C:\wamp\bin\php\php5.5.12\php.exe C:\wamp\www\sos\scripts\event-email.php
		$subject = 'CMI-UK Event Notification';
		$headers = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";	
		$headers .= "From: c.baines@creation.info";
		return mail($to, $subject, $message, $headers);
	}
}
?>