function execS2(query, data, callback) {
	if (!oSettings.s2active) return;
	
	var params;
	
	switch (query) {
		case 'updateS2': {
			params = { 
				query: query,  
				data: ''
			};
			break;
		}
		case 'getSubscriptions': {
			params = { 
				query: query,  
				sosID: data
			};
			break;
		}
		case 'getSubscription': {
			params = { 
				query: query,  
				subID: data
			};
			break;
		}
	}
	
	// construct the name of the s2 keys file, e.g. "uk-test-keys.json"
	var s2keys = global.isUK ? 'uk-' : 'ca-';
	s2keys += getS2DataSet();	// 'test' or 'live'
	s2keys += '-keys.json';
	params.s2keys = s2keys;
	
	$.ajax({
		type: 'get',
		url: "scripts/s2.php",
		cache: false,
		data: params,
		success: function(result) { 
			checkS2PendingUpdates();		
			callback(result);
		},
		error: function (xhr, ajaxOptions, thrownError) {
			cb_alert(xhr.responseText);
		},
		dataType: 'json'
	});
}

function checkS2PendingUpdates() {
	var sql = 'select count(*) as count from s2_log where s2_updated=0';
	
	execSQL(sql, function(result) {
		if (result[0].count == 0)
			$('#header-s2-alert').hide();
		else {
			$('#header-s2-count').html(result[0].count);
			$('#header-s2-alert').show();
		}
	});
}

function showS2PendingUpdates() {
	$('#header-browse-alert-caption').html('S2 UPDATES PENDING');	
	$('#header-browse-alert').slideDown();
	
	var sql = 'select date, id, case' +
				' when type="C" then "Customer create | update"' +
				' when type="S" then "Create subscription"' +
				' when type="R" then "Renew subscription"' +
				' when type="L" then "Update last issue"' +
				' when type="Q" then "Update quantity"' +
				' when type="N" then "Add a note"' +
				' when type="D" then "Remove giver"' +
				' when type="E" then "Update email"' +
				' when type="U" then "Suspend subscription"' +
				' when type="I" then "Reinstate subscription"' +
				' when type="X" then "Cancel subscription" end as type,' +
				' s2_response from s2_log where s2_updated=0';

	var b = new cb_browse('header-browse-alert-data');
	b.preQuery = 'create temporary table report (index(date)) ENGINE=MyISAM (' + sql + ')';
	b.query = 'select * from report';
	b.sortColumn = 'date';
	b.sortReverse = true;
	b.rowDepth = 0;
	b.height = 400;
	b.columns = ['date','type','id','s2_response'];
	b.colClass = ['s2-pending-date','s2-pending-type','s2-pending-id','s2-pending-response'];
	b.colHeadings = ['Timestamp','Type','ID','Response'];
	b.colHeadClass = b.colClass;
	b.deleteFn = [true, function(data) { deleteS2Log(data[2], b) } ];	
	b.fetch = function(data) {
		viewS2txn(data[2]);
	};
	b.init();		
}

function deleteS2Log(id, b) {
	var sql = 'delete from s2_log where id=' + id;
	execSQL(sql, function() {
		b.refreshData();
	});
}

function viewS2txn(id) {
	var sql = 'select * from s2_log where id=' + id;
	execSQL(sql, function(data) {

		var str = '<b>DETAILS SUBMITTED</b><br>' +
			'customer id=' + data[0].customer_id + '<br>' +
			'sub id=' + data[0].sub_id + '<br>' +
			'qty=' + data[0].qty + '<br>' +
			'email=' + data[0].email + '<br>' +
			'notes=' + data[0].notes + '<br>' +
			'cancel=' + data[0].cancel + '<br>' +
			'recipient id=' + data[0].recipient_id + '<br>' +
			'pub id=' + data[0].pub_id + '<br>' +
			'number of issues=' + data[0].num_issues + '<br>' +
			'start issue=' + data[0].start_issue + '<br>' +
			'end issue=' + data[0].end_issue + '<br>' +
			'sales order=' + data[0].sales_order;
		cb_alert(str);
	});
}

function updateS2() {
	statusMsg('Updating S2...');
	closeAlertsBrowse();	
	execS2('updateS2', 0, function() {
		checkS2PendingUpdates();	
	});
}

// returns 'live' or 'test' based on if the real server name == server name in settings
function getS2DataSet() {
	var sql = 'select @@hostname as server_name';
	execSQL(sql, function(data) {
		var serverName = data[0].server_name;
		dataSet = (oSettings.sos_server_name.toUpperCase() == serverName.toUpperCase() ? 'live' : 'test');
	}, false);
	
	return dataSet;
}

//----- RENEWALS code begins

function showSubsForRenewal(giftSubs) {

	$('#products-table-container').html('<div style="background: linear-gradient(to right, white, transparent); padding: 5px"><img src="images/please-wait.gif" style="width: 20px; vertical-align: bottom"><div style="display: inline-block; margin-left: 10px;">Getting subscription data...</div></div>')
	
	execS2("getSubscriptions", oCustomer.id, function(data) { 		
		if (data.status == 'failed') {
			$('#products-table-container').html('');			
			$('#products-table-container').append($('#s2-offline').html());			
			return;
		}

		var subsData = new Array();

		for (var x in data) {
			var sub = data[x];
//console.log(sub)
			switch (true) {
				case sub.status == 'Cancelled': {
					// can't renew canx ones
					break;
				}
				case giftSubs && sub.givesgift: {
					subsData.push(sub);
					break;
				}
				case sub.receivesgift: {
					// ignore
					break;
				}
				case (!giftSubs && !sub.givesgift): {
					subsData.push(sub);
					break;
				}
			}
		}

		var b = new cb_browse('products-table-container');
		for (var x in subsData) {			

			var recipientID = giftSubs ? subsData[x].recipientdetails.accountingid : global.customerID;

			b.arrayData[x] = [ 
				subsData[x].subid, 
				subsData[x].qty, 
				subsData[x].pubdescription, 
				subsData[x].start + ', ' + subsData[x].startdate + ' - ' + subsData[x].expiry + ', ' + subsData[x].expirydate,
				giftSubs ? '<b>gift to:</b> ' + subsData[x].recipientdetails.firstname + ' ' + subsData[x].recipientdetails.lastname : '',
				subsData[x].pubid,
				'',		// icon placeholder
				recipientID,
				subsData[x]
			];			
		}
			
		b.columns = ['id','qty','description','issues'];
		b.colClass = ['s2-renew-col-1','s2-renew-col-2','s2-renew-col-3','s2-renew-col-4','s2-renew-col-5','hidden','','hidden','hidden'];
		b.colHeadings = ['id','Qty','Description','Start-End'];
		b.colHeadClass = b.colClass;
		b.isArray = true;
		b.rowDepth = 0;
		b.sortColumn = 'issues';
		b.displayRecount = false;			
		b.controls[0] = false;		// search
		b.controls[2] = false;		// paging
		b.fetch = function(data, index) { 
			if (data[6] != '')
				cb_alert('This item has already been added to the sales order.');
			else
				addRenewalToBasket(data, index, b); 
		}
		b.init();
	});				
	
}

function addRenewalToBasket(product, index, b) {
//console.log(b)	
	var s2subID = product[0];
	var s2pubID = product[5];

	var sql = 'select * from products where type="M" and s2_id="' + s2pubID + '"';
	execSQL(sql, function(product) {
				
		if (product.length == 0)	// the product does not exist
			cb_alert('Cannot find a publication renewal product.');
		else {

			var numIssues = (product[0].sub_type == 'J' ? 3 : 4);		
			
			// setup some defaults in case user wants to do custom issues
			var start = getNextIssue(s2toSOSSubDateFormat(b.data[index][8].start), product[0].sub_type);
			var end = getNextIssue(s2toSOSSubDateFormat(b.data[index][8].expiry), product[0].sub_type);
			
			product[0].title += ' (renewal)';
			addItem(product[0], 'N', {
				s2subID: s2subID,
				s2renewal: 1,
				s2numIssues: numIssues,
				subRecipient: b.data[index][7],
				s2startIssue: start,		
				s2endIssue: end
			});

			soChanged(); 
			
			// add code here to remove from selectable items
			b.data[index][6] = '<img src="images/added-to-basket.png" style="width: 20px; vertical-align: bottom">';
			b.refreshData();

		}
	}, false);
}

function s2toSOSSubDateFormat(subDate) {
	return subDate.substr(0, 2) + ':' + subDate.substr(2, 1);
//	return '44:1';
}

