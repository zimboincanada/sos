<?php
include "db-conx.php";

$sosFolder = 'c:/wamp/www/sos';
$sosUpgradeFolder = 'c:/wamp/www/sos-upgrade';

switch($_GET['func']) {
	case 'getReleaseInfo': {
		$info = releaseInfo();
		echo json_encode($info);
		break;
	}
	
	case 'execDownload': {
		echo json_encode(execDownload());
		break;
	}
	
	case 'doBackup': {
		echo json_encode(backupDatabase());
		break;
	}
	
	case 'doUnzip': {
		echo json_encode(extractZipFile());
		break;
	}

	case 'moveApp': {
		echo json_encode(moveApp());
		break;
	}
	
	case 'dbChanges': {
		echo json_encode(applyDBChanges());
		break;
	}	
}

function releaseInfo() {
	
//	$currentVersion = (float)$_GET['version'];
	$currentVersion = $_GET['version'];

	$releaseInfo = new stdClass();
	$releaseInfo->isNewRelease = false;

	$versions = file_get_contents("https://raw.github.com/zimboincanada/sos/master/version-history.txt");
	$split = explode("\n", $versions);
	$releaseInfo->versionHistory = $versions;

	foreach ($split as $string) {
//		if ((float)$string > $currentVersion) {
		if (trim($string) > trim($currentVersion)) {
			$releaseInfo->isNewRelease = true;
			$releaseInfo->version = $string;
			return $releaseInfo;
		}
	}
	
	return $releaseInfo;
}

function execDownload() {
	global $sosFolder, $sosUpgradeFolder;
	
	if (!is_dir($sosUpgradeFolder)){
		// directory does not exist, so lets create it.
		mkdir($sosUpgradeFolder);
	}		
	
	$version = trim($_GET['versionToGet']);
	$target = 	$sosUpgradeFolder . '/sos' . $version . '.zip';
			
	$result = new stdClass();
	error_reporting(0);
	
	try {
		$version = trim($_GET['versionToGet']);
		$success = file_put_contents(
			$target,
			file_get_contents('https://raw.github.com/zimboincanada/sos/master/sos' . $version . '.zip')
		);

		if ($success == false) {
			$result->success = false;
			$result->reason = '0 bytes downloaded: ' . 'https://raw.github.com/zimboincanada/sos/master/sos' . $version . '.zip';
		}
		else
			$result->success = true;		
	}
	catch (Exception $e) {
		$result->success = false;
		$result->reason = $e;
	}		
	
	return $result;
}

function backupDatabase() {
	global $sosFolder, $sosUpgradeFolder;		

	$currentVersion = $_GET['currentVersion'];
	$result = new stdClass();
	$result->success = true;

	$backupFile = $sosUpgradeFolder . '/sos' . $currentVersion . '.sql';		

	// dump of db to sql text file
	$str = 'c:\wamp\bin\mysql\mysql5.6.17\bin\mysqldump --routines=true --events -u root sos > ' .$backupFile;
	exec($str, $output, $retval);

	if ($retval != 0) {
		$result->success = false;
		$result->reason = 'Cannot create a file copy of the database. ' . $backupFile;
	}
	
	return $result;
}

function extractZipFile() {
	global $sosFolder, $sosUpgradeFolder;		
	
	$version = trim($_GET['version']);
	$result = new stdClass();
	$result->success = false;
	
	$zip = new ZipArchive();
	$zipFile = $sosUpgradeFolder . '/sos' . $version . '.zip';
	$res = $zip->open($zipFile);
	if ($res === TRUE) {
		$zip->extractTo($sosUpgradeFolder . '/sos' . $version);
		$zip->close();
					
		$result->success = true;
	} 
	else
		$result->reason = 'Cannot unzip downloaded release: ' . $zipFile;
	
	return $result;
}

function moveApp() {
	global $sosFolder, $sosUpgradeFolder;			
	error_reporting(0);		
		
	$currentVersion = trim($_GET['currentVersion']);
	$newVersion = trim($_GET['newVersion']);
	$result = new stdClass();
	$result->success = true;

	$from = trim($sosFolder);
	$to = $sosFolder . $currentVersion;

	$success = moveFolder($from, $to);		
	
	if (!$success) {
		$result->success = false;
		$result->reason = 'Cannot move current version to backup: ' . $from . ' > ' . $to;
		return $result;
	}

	$from = $sosUpgradeFolder . '/sos' . $newVersion;
	$to = $sosFolder;

	$retval = rename($from, $to);		
	
	if ($retval != 1) {
		$result->success = false;
		$result->reason = 'Cannot move new version to live area: ' . $from . ' > ' . $to;
	}
	
	return $result;
}	

function applyDBChanges() {	
	global $sosFolder, $sosUpgradeFolder, $db_handle;	
	error_reporting(0);				
		
	$newVersion = trim($_GET['version']);
	$result = new stdClass();
	$result->success = true;

	$file = $sosUpgradeFolder . '/sos' . $newVersion . '/dbchanges.txt';
	$sql = file_get_contents($file);
	
	if ($sql == false) {
		$result->success = false;
		$result->reason = 'Cannot read database changes file: ' . $file;
		return $result;
	}
	
	$st = $db_handle->prepare($sql);
	$result->reason = $st->execute();	

	return $result;
}	

function moveFolder($src, $dest){

	// If source is not a directory stop processing
	if(!is_dir($src)) return false;

	// If the destination directory does not exist create it
	if(!is_dir($dest)) { 
		if(!mkdir($dest)) {
			// If the destination directory could not be created stop processing
			return false;
		}    
	}

	// Open the source directory to read in files
	$i = new DirectoryIterator($src);
	foreach($i as $f) {
		if($f->isFile()) {
			rename($f->getRealPath(), "$dest/" . $f->getFilename());
		} else if(!$f->isDot() && $f->isDir()) {
			moveFolder($f->getRealPath(), "$dest/$f");
		}
	}
	rmdir($src);
	
	return true;
}
?>