<?php
include "db-conx.php";
include "../3rd-party/s2/s2-api.php";

//$s2 = new subsApi();
$result = "database update fail";
$query = $_POST['query'];
	
switch($query) {	
	case 'stockAdjustment': {
		try {
			$db_handle->beginTransaction();		

			$sku = $_POST['sku'];
			$qty = $_POST['qty'];
			$notes = $_POST['notes'];
				
			// 1. add stock adj record
			$sql = 'insert into stock_adjustments (sku, qty, notes) values(?,?,?)';
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($sku, $qty, $notes));
												
			// update qty on hand
			updateInventory(1, $sku, $qty, 0);
			
			$result = $db_handle->commit();
		}
		catch (Exception $e) {
			$db_handle->rollback();
		}
		break;
	}

	case 'updateCanadaPost': {
		$sql = "insert into canada_post
					(sales_order, name, company_name, address, city, province, postal_code, country_code)
					values (?,?,?,?,?,?,?,?)
					on duplicate key update
					sales_order = values(sales_order),
					name = values(name),
					company_name = values(company_name),
					address = values(address),
					city = values(city),
					province = values(province),
					postal_code = values(postal_code),
					country_code = values(country_code),
					save_date = now()";
					
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($_POST['sales_order'],
												$_POST['name'],
												$_POST['company_name'],
												$_POST['address'],
												$_POST['city'],
												$_POST['province'],
												$_POST['postal_code'],
												$_POST['country_code']
												));		
		break;
	}

	case 'saveSubsRecord': {
		$sql = "insert into mag_subs
					(id, recipient_id, first_issue, last_issue, status, notes, digi_email, qty, issue_status)
					values (?,?,?,?,?,?,?,?,?)
					on duplicate key update
					recipient_id = values(recipient_id),
					first_issue = values(first_issue),
					last_issue = values(last_issue),
					status = values(status),
					notes = values(notes),
					digi_email = values(digi_email),
					qty = values(qty),
					issue_status = values(issue_status)";
					
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($_POST['ms_id'],
															$_POST['recipient_id'],
															$_POST['first_issue'],
															$_POST['last_issue'],
															$_POST['status'],
															$_POST['notes'],
															$_POST['digi_email'],
															$_POST['qty'],
															$_POST['issue_status']
															));		
		break;
	}

	case 'recurringDonation': {
		$sql = "insert into donations 
					(customer_id, amount, start_date, frequency, sku)
					values (?,?,?,?,?)
					on duplicate key update
					amount = values(amount),
					start_date = values(start_date),
					frequency = values(frequency),
					sku = values(sku)";
					
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($_POST['customer_id'],
															$_POST['amount'],
															$_POST['start_date'],
															$_POST['frequency'],
															$_POST['sku']
															));		

		break;
	}
			
	case 'addSalesOrder': {
		$sql = "insert into sales_orders
					(customer_id, order_date, notes, source, payment_type, payment_date, add_info,
					ship_address_1, ship_address_2, ship_address_3, ship_address_4, 
					ship_address_5, ship_address_6, ship_address_7,
					payment_type_1, payment_amount_1, payment_info_1,
					payment_type_2, payment_amount_2, payment_info_2,
					payment_type_3, payment_amount_3, payment_info_3,
					payment_type_4, payment_amount_4, payment_info_4,
					payment_type_5, payment_amount_5, payment_info_5,
					payment_type_6, payment_amount_6, payment_info_6,
					updated_by)
					values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($_POST['customer_id'], 
															$_POST['order_date'],
															$_POST['notes'],
															$_POST['source'],
															$_POST['payment_type'],												
															$_POST['payment_date'],												
															$_POST['add_info'],										
															$_POST['ship_address_1'],
															$_POST['ship_address_2'],													
															$_POST['ship_address_3'],													
															$_POST['ship_address_4'],													
															$_POST['ship_address_5'],													
															$_POST['ship_address_6'],											
															$_POST['ship_address_7'],													
															$_POST['payment_type_1'],												
															$_POST['payment_amount_1'],												
															$_POST['payment_info_1'],									
															$_POST['payment_type_2'],												
															$_POST['payment_amount_2'],												
															$_POST['payment_info_2'],									
															$_POST['payment_type_3'],												
															$_POST['payment_amount_3'],												
															$_POST['payment_info_3'],									
															$_POST['payment_type_4'],												
															$_POST['payment_amount_4'],												
															$_POST['payment_info_4'],									
															$_POST['payment_type_5'],												
															$_POST['payment_amount_5'],												
															$_POST['payment_info_5'],									
															$_POST['payment_type_6'],												
															$_POST['payment_amount_6'],												
															$_POST['payment_info_6'],					
															$_POST['updated_by']							
															));
		
		if ($status) {		// need the id back to display onscreen and for saves on edit
			$result = $db_handle->lastInsertId();
		}
		
		break;
	}

	// called from save button on sales order form
	case 'addSalesOrderItems': {
		try {
			$db_handle->beginTransaction();							
			
			$soNumber = $_POST['salesOrder'];
			$createMags = $_POST['create_mags'];
			$customerID = $_POST['customerID'];

			// step 0: reverse the inventory product qtys as they will be rewritten further down				
			$sql = "select sku, qty from sales_order_items where sales_order=?";
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($soNumber));
			while ($data = $sth->fetch()) {
				$sku = $data['sku'];
				$qty = $data['qty'];
				updateInventory(1, $sku, -$qty, 0);
			}

			// step 1: clear any s/o items from current s/order
			$sql = "delete from sales_order_items where sales_order=?";
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($soNumber));
						
			// step 2: write s/o items (and mag sub records, if any)
			$dataSet = $_POST['soi_data'];
			$msData = $_POST['ms_data'];

			for ($x=0; $x<sizeof($dataSet); $x++) {					
				$a = $dataSet[$x][0];
				$sku = $dataSet[$x][1];
				$c = $dataSet[$x][2];
				$d = $dataSet[$x][3];
				$qty = $dataSet[$x][4];
				$type = $dataSet[$x][5];	
				$g = $dataSet[$x][6];
				$h = $dataSet[$x][7];
				$magSubID = $dataSet[$x][8];
				$giftAid = $dataSet[$x][9];
				$isDigital = $dataSet[$x][10];
				$backOrder = $dataSet[$x][11];
				$s2subID = $dataSet[$x][12];
				$s2renewal = $dataSet[$x][13];
				$s2numIssues = $dataSet[$x][14];
				$s2createSub = $dataSet[$x][15];
				$s2startIssue = $dataSet[$x][16];
				$s2endIssue = $dataSet[$x][17];

				// first time creation of mag sub record; once created never changed from within sales order screen
				if ($type == 'M' && $magSubID == 0 && $createMags == 'true') {
					$recipientID = $msData[$x][0];
					$term = $msData[$x][1];
					$firstIssue = $msData[$x][2];
					$lastIssue = $msData[$x][3];
					$status = $msData[$x][4];
					$notes = $msData[$x][5];
					$issueStatus = $msData[$x][6];
					
					$sql = "select email1 from customers where id='" . $recipientID . "'";
					$sth = $db_handle->prepare($sql);
					$sth->execute();
					$record = $sth->fetch();
					$digiEmail = $record['email1'];

					$sql = "insert into mag_subs
								(recipient_id, first_issue, last_issue, status, notes, qty, term, digi_email, issue_status, num_issues)
								values (?,?,?,?,?,?,?,?,?,?)";
					$sth = $db_handle->prepare($sql);
					$status = $sth->execute(array($recipientID, $firstIssue, $lastIssue, $status, $notes, $qty, $term, $digiEmail, $issueStatus, $s2numIssues));
					$magSubID = $db_handle->lastInsertId();	

					if ($s2createSub == 1)
						writeS2Record($customerID, $recipientID, $qty, $soNumber, $s2subID, $s2renewal, $s2numIssues, $sku, $s2startIssue, $s2endIssue, $digiEmail, $magSubID);
				}
									
				$sql = "insert into sales_order_items
							(sales_order, sku, title, price, qty, type, sub_type, shipping_calc, mag_sub_id, gift_aid, digital, back_order, s2_create_sub)
							values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($a, $sku, $c, $d, $qty, $type, $g, $h, $magSubID, $giftAid, $isDigital, $backOrder, $s2createSub));
				$soiID = $db_handle->lastInsertId();
				
				// add BOM records, if any
				$packValue = addBOMData($sku, $soiID);
				$sql = "update sales_order_items set pack_value=?, bom=1 where id=" . $soiID . " and " . $packValue . ">0";
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($packValue));
			
				updateInventory(1, $sku, $qty, 0);
			}

			// step 3: update s/o value based on items in the basket
			$sql = "call update_so_value(?)";
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($soNumber));
			
			$db_handle->commit();
		}
		catch (Exception $e) {
			$db_handle->rollback();
		}			

		break;
	}
	
	case 'log': {
		$sql = "insert into log (action, detail) values (?,?)";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($_POST['action'], $_POST['details']));	
		
		if ($status) $result = 'success';			
		break;
	}
			
	// batch insert of monthly PADs/EFTs
	case 'recurringDonationsBatch': {
		
		try {
			$db_handle->beginTransaction();
			
			$dataSet = $_POST['data'];
			for ($x=0; $x< sizeof($dataSet); $x++) {
			
				// step 1 - insert sales order record
				$sql = "insert into sales_orders
								(customer_id, order_date, source, payment_type, payment_date, notes, payment_type_1, payment_amount_1)
								values (?,?,?,?,?,?,?,?)";
						
				$sth = $db_handle->prepare($sql);
				$sth->execute(array(
					$dataSet[$x][0], 
					$dataSet[$x][1],
					$dataSet[$x][2],
					$dataSet[$x][3],
					$dataSet[$x][1],		// payment date=order date
					'Recurring donation',
					$dataSet[$x][3],		// payment type 1
					$dataSet[$x][5]		// amount
				));
				
				$soID = $db_handle->lastInsertId();

				// need some details about the product
				$sql = "select * from products where sku=?";							
				$sth = $db_handle->prepare($sql);
				$sth->execute(array($dataSet[$x][4]));
				$product = $sth->fetch();

				// step 2 - insert sales order item record
				$sql = "insert into sales_order_items
								(sales_order, sku, title, price, qty, type, sub_type, shipping_calc, mag_sub_id, gift_aid)
								values (?,?,?,?,?,?,?,?,?,?)";
						
				$sth = $db_handle->prepare($sql);
				$sth->execute(array(
					$soID, 
					$dataSet[$x][4],
					$product['title'],
					$dataSet[$x][5],
					1,
					$product['type'],
					$product['sub_type'],
					$product['shipping_calc'],
					0,
					$dataSet[$x][6],
				));		

				// step 3 - update sales order value
				$sql = "call update_so_value(?)";
				$sth = $db_handle->prepare($sql);
				$sth->execute(array($soID));
			}
			
			$db_handle->commit();
			$result = 'success';
		}
		catch (Exception $e) {
			$db_handle->rollback();
		}			
				
		break;
	}
	
	case 'updatePO': {		// update qty received
		try {
			$db_handle->beginTransaction();
			
			$poID = $_POST['po_number'];

			$sql = 'update purchase_orders set status=?, exchange_rate=?, overhead_pct=? where id=?';
			$sth = $db_handle->prepare($sql);
			$sth->execute(array($_POST['status'], $_POST['exchange_rate'], $_POST['overhead_pct'], $poID, ));
			
			// clear out existing data, then re-add below
			$sql = "delete from purchase_order_items where po_id=?";
			$sth = $db_handle->prepare($sql);
			$sth->execute(array($poID));
			
			// add the po items
			$poBasketData = $_POST['po_basket_data'];
			for ($x=0; $x<sizeof($poBasketData); $x++) {	
				$sql = "insert into purchase_order_items
							(po_id, sku, qty_ordered, qty_received, cost)
							values (?,?,?,?,?)";
				$sth = $db_handle->prepare($sql);
				$sth->execute(array($poID, $poBasketData[$x][0], $poBasketData[$x][2], $poBasketData[$x][3], $poBasketData[$x][4]));
			}

			if ($_POST['status'] == 2) {		// mark as complete
				$sql = 'update purchase_orders set receive_date=? where id=?';
				$sth = $db_handle->prepare($sql);
				$sth->execute(array(date("Y-m-d"), $poID));
				
				$poBasketData = $_POST['po_basket_data'];
				for ($x=0; $x<sizeof($poBasketData); $x++) {

					// calculate landed cost
					$unitCost = $poBasketData[$x][4];			
					$landedCost = $unitCost / $_POST['exchange_rate'] * (1 + ($_POST['overhead_pct'] / 100));					
					updateInventory(2, $poBasketData[$x][0], -$poBasketData[$x][3], $landedCost);

					// create stock adjustment record
					$sql = "insert into stock_adjustments
								(sku, qty, notes)
								values (?,?,?)";
					$sth = $db_handle->prepare($sql);
					$sth->execute(array($poBasketData[$x][0], -$poBasketData[$x][3], 'PO#' . $poID));
				}
			}
			
			$db_handle->commit();
		}
		catch (Exception $e) {
			$db_handle->rollback();
		}				
		break;
	}		
}

echo json_encode($result);	
	
//---	
	
function writeS2Record($customerID, $recipientID, $qty, $soID, $s2subID, $s2renewal, $s2numIssues, $sku, $s2startIssue, $s2endIssue, $email, $magSubID) {
	global $db_handle;

	if ($s2endIssue != '')	// user wants a custom end issue
		$s2numIssues = 0;

	if ($s2renewal == '1') {
		$sql = 'insert into s2_log set 
					type=?,
					sub_id=?,
					sales_order=?,
					num_issues=?,
					end_issue=?,
					customer_id=?';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array('R', $s2subID, $soID, $s2numIssues, s2format($s2endIssue), $customerID));
	}
	else {	// new sub
		$pubID = getS2pubID($sku);

		$sql = "insert into s2_log
					(type, recipient_id, customer_id, pub_id, qty, num_issues, sales_order, start_issue, end_issue, email, mag_sub_id)
					values (?,?,?,?,?,?,?,?,?,?,?)";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array('S', $recipientID, $customerID, $pubID, $qty, $s2numIssues, $soID, s2format($s2startIssue), s2format($s2endIssue), $email, $magSubID));
	}
	
	// also write a reference to the customer record in case the customer record doesn't already exist in s2
	$sql = 'insert into s2_log set type=?, customer_id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array('C', $customerID));
	
	// if this is a gift sub, write a reference to the customer recipient record in case it doesn't already exist in s2
	if ($customerID != $recipientID) {
		$sql = 'insert into s2_log set type=?, customer_id=?';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array('C', $recipientID));	
	}
}	

// changes 39:4 to 3940
function s2format($input) {
	$a = substr($input, 0, 2);
	$b = substr($input, 3, 1);
	$c = '0';
	
	return $a . $b . $c;
}

/* 	update inventory qty
	$mode: 1=update qty only, 2=update cost (must supply $cost)
	$qty = the amount to reduce by.
*/
function updateInventory($mode, $sku, $qty, $cost) {
	global $db_handle;
	
	$sql = "select qty from products where sku=?";							
	$sth = $db_handle->prepare($sql);
	$sth->execute(array($sku));
	$product = $sth->fetch();
	$oldQty = $product['qty'];
									
	$newQty = $oldQty - $qty;

	if ($mode == 1) {
		$sql = "update products set qty=? where sku=?";						
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($newQty, $sku));
	}
	else {
		$sql = "update products set qty=?, previous_cost=cost, cost=? where sku=?";						
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($newQty, $cost, $sku));
	}
	
	// update all the BOM items, if there are any:
	// get a list of all the products that make up the pack (i.e. $sku)
//	$sql = "select * from products where find_in_set(sku, (select bom from products where sku='" . $sku . "'))";
	$sql = "select sku, qty from product_boms where parent_sku='" . $sku . "'";
	$sth = $db_handle->prepare($sql);
	$sth->execute();

	// for each of the products that make up a pack, update qty
	while ($data = $sth->fetch()) {
		$sql = "select qty from products where sku=?";							
		$sth2 = $db_handle->prepare($sql);
		$sth2->execute(array($data['sku']));
		$product = $sth2->fetch();
		
		$oldQty = $product['qty'];										
		$newQty = $oldQty - ($qty * $data['qty']);		
		
		if ($mode == 1) {
			$sql = "update products set qty=? where sku=?";						
			$sth2 = $db_handle->prepare($sql);
			$sth2->execute(array($newQty, $data['sku']));
		}
		else {
			$sql = "update products set qty=?, previous_cost=cost, cost=? where sku=?";						
			$sth2 = $db_handle->prepare($sql);
			$sth2->execute(array($newQty, $cost, $data['sku']));
		}
	}	
}

// BOM records added here; they will first have been deleted along with all of the
// soi records as set up in the cascade relationship.
function addBOMData($sku, $soi_id) {
	global $db_handle;
	$packValue = 0.00;
	
	// get a list of all the products that make up the pack (i.e. $sku)
	$sql = "select pb.sku, p.title, p.sub_type, p.price, p.digital, pb.qty from product_boms pb, products p where p.sku=pb.sku and pb.parent_sku='" . $sku . "'";
	$sth = $db_handle->prepare($sql);
	$sth->execute();

	// for each of the products that make up a pack, add a sobi record
	while ($data = $sth->fetch()) {
		$sql = "insert into sales_order_bom_items
					(soi_id, sku, title, sub_type, price, digital, qty)
					values (?,?,?,?,?,?,?)";
		$sth2 = $db_handle->prepare($sql);
		$sth2->execute(array($soi_id, $data['sku'], $data['title'], $data['sub_type'], $data['price'], $data['digital'], $data['qty']));
		$packValue += $data['price'] * $data['qty'];
	}
	
	return $packValue;
}

function getS2pubID($sku) {
	global $db_handle;

	$sql = "select * from products where sku=?";
	$st = $db_handle->prepare($sql);
	$st->execute(array($sku));
	$product = $st->fetch();
		
	return $product['s2_id'];
}
?>