var oChurch = new church();

function church() {
	this.init = function(fromForm, churchID) {
		this.eventMode = fromForm;
//		subSystemLabel('mini,church');
		
		$("#event-talks, #event-todo-items").sortable();		// drag and drop
		
//  $( function() {
//    $( "#sortable" ).disableSelection();
//  } );			
		if (this.eventMode  == 'church') {
//var options = ['Cold', 'Warm', 'Hot'];		// CB - get from settings
			var options = oSettings.church_status.split(',');
			fillPicklistWithData('church-status', options, options);
			var churchID = getURLParameter('church');
			
			var options = oSettings.regions.split(',');
			fillPicklistWithData('church-region', options, options);			
		}
//var options = ['Phone contact made','Awaiting finalization','Suspended','Active','Complete'];

		if (this.eventMode  == "church") {
			oChurch.setupDetails(churchID);

			if (churchID == 'new')
				this.setOtherTabs(false);
			this.showTab(1);
		}
		
		this.loadPicklists(churchID);
	}

	this.loadPicklists = function(churchID) {
		var options = oSettings.event_status.split(',');
		fillPicklistWithData('event-status', options, options);
//var options = ['Public meeting','Sunday AM','Sunday PM','Bookstall/Exhibit'];
		var options = oSettings.presentation_type.split(',');
		fillPicklistWithData('event-presentation-type', options, options);
		var options = oSettings.regions.split(',');
		fillPicklistWithData('event-region', options, options);					

//var options = [1,2,3,4];
//			fillPicklistWithData('event-tours', options, options);
		var sql = 'select id, concat(left(name, 27), " -- ", start_date) as name from tours';
		execSQL(sql, function(data) {
			var options = [], values = [];
			for (var x in data) {
				values.push(data[x].id);
				options.push(data[x].name);
			}
			fillPicklistWithData('event-tours', values, options);
		});
		
		var sql = 'select title from talks';
		execSQL(sql, function(data) {
			var options = [];
			for (var x in data)
				options.push(data[x].title);
			fillPicklistWithData('event-talk-list', options, options);
		});

		var sql = 'select id, name from contacts where church_id=' + churchID;
		execSQL(sql, function(data) {
			var options = [], values=[];
			for (var x in data) {
				values.push(data[x].id);
				options.push(data[x].name);
			}
			fillPicklistWithData('event-contact', values, options);
//console.log('data=',data)
		});
				
		var sql = 'select concat(first_name, " ", last_name) as name from customers where price_band=4';
		execSQL(sql, function(data) {
			var options = [];
			for (var x in data)
				options.push(data[x].name);
			fillPicklistWithData('event-speaker-list', options, options);
		});		
	}
	
	this.showTab = function(tab) {
	
		this.loadPicklists(oChurch.details.id);
		
		$('.tab').removeClass('active');
		$('#tab-' + tab).addClass('active');

		$('.tab-content').hide();
		$('#tab-' + tab + '-content').show();

		if (tab == 2)
			this.listContacts();
		if (tab == 3)
			this.listEvents();
		if (tab == 4)
			this.listContactHistory();
	}		

	this.setOtherTabs = function(show) {
		if (show) {
			$('#tab-2').show();
			$('#tab-3').show();
			$('#tab-4').show();
		}
		else {
			$('#tab-2').hide();
			$('#tab-3').hide();
			$('#tab-4').hide();
		}
	}		
	
	this.setupDetails = function(id) {
		var sql = 'select * from churches where id=' + id;
		execSQL(sql, function(data) {

			if (id == 'new') {
				oChurch.details = {};
				oChurch.details.id = 'new';
				$('#church-name').val('');
				$('#church-address').val('');
				$('#church-city').val('');
				$('#church-county').val('');
				$('#church-postal-code').val('');
				$('#church-region').val('');
				$('#church-phone').val('');
				var option = $("#church-status option:first").text();
				$('#church-status').val(option);
				$('#church-notes').val('');
			}
			else {
				oChurch.details = data[0];
//console.log(data[0])
				$('#church-name').val(oChurch.details.name);
				$('#church-address').val(oChurch.details.address);
				$('#church-city').val(oChurch.details.city);
				$('#church-county').val(oChurch.details.county);
				$('#church-postal-code').val(oChurch.details.postal_code);
				$('#church-region').val(oChurch.details.region);
				$('#church-phone').val(oChurch.details.phone);
				$('#church-status').val(oChurch.details.status);
				$('#church-notes').val(oChurch.details.notes);
			}	

			$(document).attr("title", oChurch.details.name);	// chrome tab name		
		}, false);	
	}

	this.saveDetails = function() {
		if (!formValidated('tab-1-content'))
			return;

		oChurch.copyElementsToObject();

		$.ajax({
			type: 'post',
			url: "scripts/church.php",
			cache: false,
			data: { 
				churchData: JSON.stringify(oChurch.details)
			},
			success: function(result) { 
//console.log(oChurch.details, result)
				if (oChurch.details.id == 'new') {
					oChurch.setOtherTabs(true);
					oChurch.details.id = result.id;
				}
				statusMsg('Church details saved.');
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}

	this.copyElementsToObject = function() {
		oChurch.details.name = $('#church-name').val();
		oChurch.details.address = $('#church-address').val();
		oChurch.details.city = $('#church-city').val();
		oChurch.details.county = $('#church-county').val();
		oChurch.details.postal_code = $('#church-postal-code').val();
		oChurch.details.region = $('#church-region').val();
		oChurch.details.phone = $('#church-phone').val();
		oChurch.details.status = $('#church-status').val();
		oChurch.details.notes = $('#church-notes').val();
	}
	
	this.merge = function() {
		
		document.getElementById('merge-form').overlay = doOverlay(true, 'merge-form');
		document.getElementById('merge-form').style.display = 'block';
		
		var b = new cb_browse('merge-form-data');
		var sql = "select * from churches where id<>" + oChurch.details.id;		// cannot merge with itself
//console.log(sql)
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 350;
		b.controls[1] = true;		// print			
		b.columns = ['id','name','address','city'];
		b.colClass = ['hide','merge-name','merge-address'];
		b.colHeadings = ['ID','Name','Address','City'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'name';
//		b.sortReverse = true;
		b.fetch = function(data) {
			oChurch.confirmMerge(data[0]);
		}
		b.init();
	}
	
	this.confirmMerge = function(duplicateID) {
		confirmBox(
			"CONFIRM",
			"Are you sure you want to continue?", 
			["Yes-merge the churches", "No"],
			[ function() { oChurch.executeMerge(duplicateID) }, function() {} ]
		);		
	}
	
	this.executeMerge = function(duplicateID) {
		$.ajax({
			type: 'post',
			url: "scripts/merge-church.php",
			cache: false,
			data: { 
				primaryID: oChurch.details.id,
				duplicateID: duplicateID
			},
			success: function(result) { 
//console.log(result)
				oChurch.closeMerge();
//				oChurch.listContacts();
				statusMsg('Merge complete.');
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}
	
	this.closeMerge = function() {
		document.getElementById('merge-form').style.display = 'none';
		doOverlay(false, document.getElementById('merge-form').overlay);
	}	

	// CONTACTS...
	
	this.listContacts = function() {
		var b = new cb_browse('contacts');
		var sql = "select * from contacts where church_id=" + oChurch.details.id;
//console.log(sql)
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print			
		b.columns = ['id','name','role','phone_1','email'];
		b.colClass = ['hide','con-name','con-role','con-phone','con-email'];
		b.colHeadings = ['ID','Name','Role','Phone 1','Email 1'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'name';
		b.deleteFn = [true, function(data) { oChurch.deleteContactCheck(data[0]) } ];				
//		b.sortReverse = true;
		b.fetch = function(data) {
			oChurch.editContact(data[0]);
		}
		b.init();
	}

	this.editContact = function(id) {
		document.getElementById('contact-panel').overlay = doOverlay(true, 'contact-panel');
		document.getElementById('contact-panel').style.display = 'block';
		document.getElementById('contact-panel').reset();
		this.currentContact = id;

		if (id == 'new') {
			$('#contact-name').val('');
			$('#contact-role').val('');
			$('#contact-phone-1').val('');
			$('#contact-phone-2').val('');
			$('#contact-email').val('');
			$('#contact-email-2').val('');
			$('#contact-address').val('');
			$('#contact-notes').val('');
		}
		else {
			var sql = 'select * from contacts where id=' + id;
			execSQL(sql, function(data) {
				var contact = data[0];
				$('#contact-name').val(contact.name);
				$('#contact-role').val(contact.role);
				$('#contact-phone-1').val(contact.phone_1);
				$('#contact-phone-2').val(contact.phone_2);
				$('#contact-email').val(contact.email);
				$('#contact-email-2').val(contact.email_2);
				$('#contact-address').val(contact.address);
				$('#contact-notes').val(contact.notes);
			});
		}

		$('#contact-name').focus();
	}

	// close contact dialog
	this.closeContact = function() {
		document.getElementById('contact-panel').style.display = 'none';
		doOverlay(false, document.getElementById('contact-panel').overlay);
	}

	this.saveContact = function() {
		if (!formValidated('contact-panel'))
			return;

		$.ajax({
			type: 'post',
			url: "scripts/contact.php",
			cache: false,
			data: { 
				id: this.currentContact,
				name: $('#contact-name').val(),
				role: $('#contact-role').val(),
				phone1: $('#contact-phone-1').val(),
				phone2: $('#contact-phone-2').val(),
				email: $('#contact-email').val(),
				email2: $('#contact-email-2').val(),
				address: $('#contact-address').val(),
				notes: $('#contact-notes').val(),
				churchID: oChurch.details.id
			},
			success: function(result) { 
//console.log(result)
				oChurch.closeContact();
				oChurch.listContacts();
				statusMsg('Contact details saved.');
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}
	
	this.deleteContactCheck = function(id) {
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to delete this Contact?", 
			["Yes", "No"],
			[ function() { oChurch.deleteContact(id) }, function() {} ]
		);
	}
	
	this.deleteContact = function(id) {
		var sql = 'delete from contacts where id=' + id;
		execSQL(sql, function() {
			oChurch.listContacts();
		});
	}	

	// EVENTS........
	
	this.listEvents = function() {
		var b = new cb_browse('events');
		var sql = "select *, (select group_concat(talk) from event_talks where event_id=e.id) as talks from events e where church_id=" + oChurch.details.id;
//console.log(sql)
		b.preQuery = 'create temporary table report (index(event_date)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print
		b.columns = ['id','event_date','speaker','talks','attendance_actual','status'];
		b.colClass = ['hide','ev-date','ev-speaker','ev-talk','ev-attendance','ev-status'];
		b.colHeadings = ['ID','Event date','Speaker','Talk','Attendance (actual)','Status'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'event_date';
		b.sortReverse = true;
		b.deleteFn = [true, function(data) { oChurch.deleteEventCheck(data[0]) } ];		
		b.fetch = function(data) {
			oChurch.editEvent(data[0]);
		}
		b.init();
		oChurch.events = b;
	}
	
	this.editEvent = function(id) {
		oChurch.unsavedEvent = false;
		this.eventTodoItemsCreated = false;
		$('#event-panel').on('change', function() {
			oChurch.unsavedEvent = true;
		});
		
		document.getElementById('event-panel').overlay = doOverlay(true, 'event-panel');
		document.getElementById('event-panel').style.display = 'block';
		document.getElementById('event-panel').reset();
		this.currentEvent = id;
		$('#event-church-name').html(oChurch.details.name);
		$('#event-talks').html('');

		if (id == 'new') {
			$('#event-name').val('');
			$('#event-contact').val('');
			$('#event-address').val('');
			$('#event-city').val('');
			$('#event-county').val('');
			$('#event-postal-code').val('');
			$('#event-region').val('');
			$('#event-date').val('');
			$('#event-no-web').prop('checked', false);
//			$('#event-talk').val('');
			$('#event-speaker').val('');
			$('#event-book-table').prop('checked', true);
			$('#event-attendance-expected').val('');
			$('#event-attendance-actual').val('');
			$('#event-accommodation-details').val('');
			$('#event-direction-details').val('');
			$('#event-gift').val('');
			$('#event-is-tour').prop('checked', false);
			$('#event-notes').val('');
			var option = $("#event-status option:first").text();
			$('#event-status').val(option);
			$('#event-host-details').val('');
			$('#event-volunteer-details').val('');
			$('#event-cmi-equipment').val('');
			$('#event-access-time-details').val('');
			$('#event-presentation-type').val('');
			$('#event-webpage-id').val('');
			$('#event-created-date').html(today());
			
			oChurch.addEventTalk('', '', false);		// need at least 1 talk
		}
		else {
			var sql = 'select * from events where id=' + id;
			execSQL(sql, function(data) {
				var event = data[0];
//console.log('ev=',event)

				$('#event-name').val(event.name);
				$('#event-contact').val(event.contact_id);
				$('#event-address').val(event.address);
				$('#event-city').val(event.city);
				$('#event-county').val(event.county);
				$('#event-postal-code').val(event.postal_code);
				$('#event-region').val(event.region);
				$('#event-date').val(event.event_date);
				$('#event-no-web').prop('checked', event.no_web == 1);
//				$('#event-talk').val(event.talk);
				$('#event-speaker').val(event.speaker);
				$('#event-book-table').prop('checked', event.book_table == 1)
				$('#event-attendance-expected').val(event.attendance_expected);
				$('#event-attendance-actual').val(event.attendance_actual);
				$('#event-accommodation-details').val(event.accommodation_details);
				$('#event-direction-details').val(event.direction_details);
				$('#event-gift').val(event.gift);
				$('#event-tours').val(event.tour_id == 0 ? 1 : event.tour_id);
				$('#event-is-tour').prop('checked', event.tour_id > 0);
				$('#event-notes').val(event.notes);
				$('#event-status').val(event.status);
				$('#event-host-details').val(event.host_contact_details);
				$('#event-volunteer-details').val(event.volunteer_details);
				$('#event-cmi-equipment').val(event.cmi_equipment);
				$('#event-access-time-details').val(event.access_time_details);
				$('#event-presentation-type').val(event.presentation_type);
				$('#event-webpage-id').val(event.webpage_id);
				$('#event-created-date').html(event.created_date.substr(0, 10));

			}, false);
			
			// add event talks
			this.getEventTalks(id);		

			// build todo list for this event
			this.getEventTodoItems(id);						
		}
		
		if ($('#event-is-tour').prop('checked'))
			$('#event-tours').show();
		else
			$('#event-tours').hide();
		
		$('#event-is-tour').on('change', function() {
			if ($('#event-is-tour').prop('checked'))
				$('#event-tours').show();
			else
				$('#event-tours').hide();
		});
		
//		$('#event-venue-address').focus();
		global.setTabActive('event-tab-1', 'event-panel-1');
	}
	
	this.getEventTalks = function(eventID) {
		var sql = 'select * from event_talks where event_id=' + eventID;
		execSQL(sql, function(data) {
			for (var x in data) {
				oChurch.addEventTalk(data[x].talk, data[x].time, (data[x].daily == 1));
			}
		});
	}

	this.deleteEventCheck = function(id) {
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to delete this Event?", 
			["Yes", "No"],
			[ function() { oChurch.deleteEvent(id) }, function() {} ]
		);
	}
	
	this.deleteEvent = function(id) {
		var sql = 'delete from events where id=' + id;
		execSQL(sql, function() {
			oChurch.events.refreshData();
		});
	}
	
	this.closeEvent = function() {
		if (oChurch.unsavedEvent) {		
			confirmBox(
				"ATTENTION", 
				"You made changes but haven't saved them.", 
				["Back to Edit", "OK, lose the changes"],
				[ function() {}, function() {				
					document.getElementById('event-panel').style.display = 'none';
					doOverlay(false, document.getElementById('event-panel').overlay);
				} ]
			);		
		}
		else {
			document.getElementById('event-panel').style.display = 'none';
			doOverlay(false, document.getElementById('event-panel').overlay);
		}
	}

	this.saveEvent = function() {
		if (!formValidated('event-panel'))
			return;
			
		var eventTalks = [];
		var talks = $('#event-talks').children();
		for (var x=0; x<talks.length; x++) {
			var talk = talks[x].getElementsByClassName('event-talk')[0].value;
			var time = talks[x].getElementsByClassName('event-time')[0].value;
			var daily = talks[x].getElementsByClassName('event-daily')[0].checked;
			eventTalks[x] = [talk, time, (daily ? 1 : 0)];
		}
		
		if (this.currentEvent == 'new')
			this.createEventTodoItems();		

		var eventTodos = [];
		var todos = $("#event-todo-items").children();
		for (var x=0; x<todos.length; x++) {
			var item = todos[x].getElementsByClassName("event-todo-item")[0].value;
			var complete = todos[x].getElementsByClassName("event-todo-complete")[0].checked;
			var due = todos[x].getElementsByClassName("event-todo-date")[0].value;
			eventTodos[x] = [item, (complete ? 1 : 0), due];
//console.log(eventTodos[x])			
		}
		
		var isNew = (this.currentEvent == 'new');
		
		$.ajax({
			type: 'post',
			url: "scripts/event.php",
			cache: false,
			data: { 
				id: this.currentEvent,
				name: $('#event-name').val(),
				contactID: $('#event-contact').val(),
				eventDate: $('#event-date').val(),
				noWeb: $('#event-no-web').prop('checked') == true ? 1 : 0,
				eventTalks: eventTalks,
				speaker: $('#event-speaker').val(),
				bookTable: $('#event-book-table').prop('checked') == true ? 1 : 0,
				attendanceExpected: $('#event-attendance-expected').val(),
				address: $('#event-address').val(),
				city: $('#event-city').val(),
				county: $('#event-county').val(),
				postalCode: $('#event-postal-code').val(),
				region: $('#event-region').val(),
				accommodationDetails: $('#event-accommodation-details').val(),
				attendanceActual: $('#event-attendance-actual').val(),
				directionDetails: $('#event-direction-details').val(),
				gift: $('#event-gift').val(),
				tourID: $('#event-is-tour').prop('checked') ? $('#event-tours').val() : 0,
				notes: $('#event-notes').val(),
				status: $('#event-status').val(),
				churchID: oChurch.details.id,
				hostDetails: $('#event-host-details').val(),
				volunteerDetails: $('#event-volunteer-details').val(),
				cmiEquipment: $('#event-cmi-equipment').val(),
				accessTimeDetails: $('#event-access-time-details').val(),
				presentationType: $('#event-presentation-type').val(),
				webpageID: $('#event-webpage-id').val(),
				eventTodos: eventTodos
			},
			success: function(result) { 
//console.log(result)			
				if (isNew)	{	// celebrate
					oChurch.celebrateNewEvent();
				}
					
//console.log(result)
				oChurch.unsavedEvent = false;				
				oChurch.closeEvent();
				statusMsg('Event details saved.');
//console.log('mode=',this.eventMode)				
				if (oChurch.eventMode == 'church')
					oChurch.listEvents();
				else	
					oEvents.listEvents();
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}

	this.celebrateNewEvent = function() {
//		var audio = new Audio('images/book-event.mp3');						
//		audio.play();
		
		$('#system-icon').attr("src", 'images/book-event.gif');
		setTimeout(function() {
			$('#system-icon').attr("src", 'images/sos-icon.gif');
		}, 2000);					
	}
	
	this.setEventAddress = function(set) {
		if (set) {
			$('#event-address').val(oChurch.details.address);
			$('#event-city').val(oChurch.details.city);
			$('#event-county').val(oChurch.details.county);
			$('#event-postal-code').val(oChurch.details.postal_code);
			$('#event-region').val(oChurch.details.region);
		}
		else {
			$('#event-address').val('');
			$('#event-city').val('');
			$('#event-county').val('');
			$('#event-postal-code').val('');
			$('#event-region').val('');
		}
	}
	
	this.setHostDetails = function(set) {
		var address = '';
		if (set) {
			var sql = 'select * from contacts where id=' + $('#event-contact').val();
			execSQL(sql, function(contact) {
				address = contact[0].name + '\n' + contact[0].address + '\n' + contact[0].phone_1 + '\n' + contact[0].phone_2 + '\n' + contact[0].email;
			}, false);
		}
		$('#event-host-details').val(address);
	}
	
	this.addEventTalk = function(theTalk, theTime, daily) {
		var line = document.createElement('li');
		document.getElementById('event-talks').appendChild(line);
		line.className = "ui-state-default";

		var handle = document.createElement('span');
		line.appendChild(handle);
		handle.className = "event-talk-handle";
		handle.innerHTML = '&udarr;';
		
		var talk = document.createElement('input');
		line.appendChild(talk);
		talk.className = "event-talk";
		$(talk).attr('list', "event-talk-list");
		talk.value = theTalk;
		
		var time = document.createElement('input');
		line.appendChild(time);
		time.className = "event-time";
		time.type = "time";
		time.value = theTime;
		time.disabled = (daily == 1);

		var cbx = document.createElement('input');
		line.appendChild(cbx);
		cbx.className = "event-daily";
		cbx.type = "checkbox";
//cbx.id = 'bob';
		cbx.checked = daily;
		$(cbx).on('click', function() { 
//console.log(this.checked); 
			if (this.checked) {
				time.disabled = true;
				time.value = '';
			}
			else
				time.disabled = false;
		})

		var cbxLabel = document.createElement("label");
		//newlabel.setAttribute("for",cbx.id);
		cbxLabel.innerHTML = "DAILY";
		cbxLabel.className = 'event-talk-daily';
		line.appendChild(cbxLabel);
		
		var canx = document.createElement('span');
		line.appendChild(canx);
		canx.innerHTML = "x";
		canx.className = "event-talk-canx";
		canx.onclick = function() {
			oChurch.deleteEventTalk(line);
		}
	}
	
	this.deleteEventTalk = function(line) {
		if ($('#event-talks').children().length == 1)
			cb_alert('You must have at least one talk, even if it\'s TBA');
		else
			document.getElementById('event-talks').removeChild(line)
	}
	
	// Word templates follows............
	
	this.listWordDocs = function() {
		$.post('scripts/list-word-templates.php', { 
			templatePath: oSettings.word_template_path 
		}, 
		function(files) {
//	console.log(result)		
			var b = new cb_browse('events-documents');
			b.rowDepth = 0;
			b.height = 250;
//				b.controls[1] = true;		// print
			b.columns = ['filename'];
			b.colClass = [''];
			b.colHeadings = ['Template'];
			b.colHeadClass = b.colClass;
			b.sortColumn = 'filename';
			b.isArray = true;
//			b.deleteFn = [true, function(data) { oChurch.deleteEventCheck(data[0]) } ];		
			b.fetch = function(data) {
//console.log(data)
				oChurch.createWordDoc(data[0]);
			}
			b.arrayData = [];
			files = JSON.parse(files);
			for (var x in files) {
//console.log(files[x])
				b.arrayData[x] = [files[x]];
			}
			b.init();
		
		});		
	}

	this.getEventTalksForWord = function() {
		var eventTalks = '';
		var talks = $('#event-talks').children();
		for (var x=0; x<talks.length; x++) {
			var talk = talks[x].getElementsByClassName('event-talk')[0].value;
			var time = talks[x].getElementsByClassName('event-time')[0].value;
			eventTalks += talk + " (" + time.substr(0, 5) + ") {CRLF}";
		}
		return eventTalks;
	}
	
	this.getMinistryHistoryForWord = function() {
		var ministryHistory = '';
		var sql = "select *, (select group_concat(talk) from event_talks where event_id=e.id) as talks from events e where e.id<>" + oChurch.currentEvent + " and church_id=" + oChurch.details.id;
		execSQL(sql, function(data) {
			for (var x in data) {
				ministryHistory += data[x].event_date + ' - ' + data[x].talks + " (" +data[x].speaker + ") - " + data[x].attendance_actual + "{CRLF}";
			}			
		}, false);
		return ministryHistory;
	}
	
	this.preserveCRLF = function(value) {
		var newValue = value.replace(/\n/g, "{CRLF}");
		return newValue;
	}
	
	this.createWordDoc = function(sourceFile) {
//console.log(sourceFile)
//console.log('host-det=',$('#event-host-details').val(), this.bob())
		var eventTalks = this.getEventTalksForWord();
		var ministryHistory = this.getMinistryHistoryForWord();	
//		ministryHistory = 'event date, speaker, talk, attendance';

//return
		var mmData = {
			'{TODAY}': formatDate(today(), 3),
			'{SPEAKER}': $('#event-speaker').val(),
			'{EVENT-DATE}': formatDate($('#event-date').val(), 3),
			'{CHURCH}': oChurch.details.name,
			'{VENUE-ADDRESS}': $('#event-address').val() + '{CRLF}' + $('#event-city').val() + '{CRLF}' + $('#event-county').val() + '{CRLF}' + $('#event-postal-code').val(),
			'{DIRECTION-DETAILS}': $('#event-direction-details').val(),
			'{CONTACT}': $('#event-contact option:selected').text(),
			'{VOLUNTEER-DETAILS}': $('#event-volunteer-details').val(),
			'{CMI-EQUIPMENT}': $('#event-cmi-equipment').val(),
			'{HOST-CONTACT-DETAILS}': this.preserveCRLF($('#event-host-details').val()),
			'{ACCESS-DETAILS}': $('#event-access-time-details').val(),
			'{EXPECTED-ATTENDANCE}': $('#event-attendance-expected').val(),
			'{BOOK-TABLE}': $('#event-book-table').prop('checked') ? 'Yes' : 'No',
			'{NOTES}': $('#event-notes').val(),
			'{ACCOMMODATION-DETAILS}': $('#event-accommodation-details').val(),
			'{TALKS-TIMES}': eventTalks,
			'{MINISTRY-HISTORY}': ministryHistory,
			'{GIFT}': $('#event-gift').val()
		};
		
		//mmData = encodeURIComponent(mmData);

//console.log(mmData)
//return
		$.ajax({
			type: 'post',
			url: "scripts/copy-word-template.php",
			cache: false,
			data: { 
				templatePath: oSettings.word_template_path,
				sourceFile: sourceFile, 
				mmData: mmData
			},
			success: function(result) { 
//	console.log(result)		
				window.open("uploads/" + sourceFile);

	/*			    var frame = document.getElementById("iframe");
		window.onload = setTimeout(function(){
			frame.src="scripts/test-target.docx";
		},100);*/
		

			},
			error: function(xhr,a,b) {
				cb_alert('?' + xhr.responseText + a + b);
	//			cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});	
	}	
	
	// EVENT TODO ITEMS
	this.eventTodoCheck = function() {
		if ($('#event-date').val() == '')
			cb_alert('Cannot create Todo items without an Event date.')
		else {
			if (this.currentEvent == 'new')
				this.createEventTodoItems();
			else
				this.getEventTodoItems();
			global.setTabActive('event-tab-5', "event-panel-5");
		}
	}
	
	this.createEventTodoItems = function() {
		
		if (this.eventTodoItemsCreated) {
			return;
		}

		var obj = this;		
//		var eventID = this.currentEvent;
		$('#event-todo-items').html('');
		
/*		var items = oSettings.event_todo_items.split(',');
		var data = [];
		for (var x in items) {
//				data[x] = { complete: false, item: items[x] };
//				this.addEventTodoItem(data[x]);			
		}
*/
		
		var sql = 'select * from event_todo_item_defaults';
		execSQL(sql, function(defaults) {
			var data = [];
			for (var x in defaults) {
				var basedOnDate =	defaults[x].offset_date_type == 'B' ? $('#event-created-date').html() : $('#event-date').val();		// default based either on 'booking' or 'event'
//console.log(today(), defaults, defaults[x].offset_date_type, basedOnDate)				
				var date = new Date(basedOnDate);
				var newDate = new Date(date);
				newDate.setDate(newDate.getDate() + Number(defaults[x].offset_from_date));
				
				var dd = newDate.getDate();
				var mm = newDate.getMonth() + 1;
				var yyyy = newDate.getFullYear();
				var todoDate = yyyy + '-' + strZero(mm, 2) + '-' + strZero(dd, 2);
	
//console.log(newDate, todoDate)	

				data[x] = { complete: false, item: defaults[x].item, due: todoDate };
				obj.addEventTodoItem(data[x]);							
			}
		}, false);

		this.eventTodoItemsCreated = true;
	}

	this.getEventTodoItems = function() {
//console.log('get')		
		var obj = this;		
		var sql = 'select * from event_todo_items where event_id=' + this.currentEvent;
		$('#event-todo-items').html('');
				
		execSQL(sql, function(data) {	
			for (var x in data) {
//console.log(data[x])
				obj.addEventTodoItem(data[x]);
			}
		});
	}
	
	this.addEventTodoItem = function(data) {
		var line = document.createElement('li');
		document.getElementById('event-todo-items').appendChild(line);
		line.className = "ui-state-default";

		var handle = document.createElement('span');
		line.appendChild(handle);
		handle.className = "event-todo-handle";
		handle.innerHTML = '&udarr;';		
		
		var cbx = document.createElement('input');
		line.appendChild(cbx);
		cbx.type = "checkbox";
		cbx.className = 'event-todo-complete';
		cbx.checked = (data.complete == 1);

		var cbxLabel = document.createElement("input");
		cbxLabel.innerHTML = data.item;
		cbxLabel.value = data.item;
		cbxLabel.className = 'event-todo-item';
		line.appendChild(cbxLabel);
		
		var cbxDate = document.createElement("input");
		cbxDate.type = "date";
		cbxDate.value = data.due;
		cbxDate.className = 'event-todo-date';
		line.appendChild(cbxDate);
	
		var canx = document.createElement('span');
		line.appendChild(canx);
		canx.innerHTML = "x";
		canx.className = "event-todo-canx";
		canx.onclick = function() {
			oChurch.deleteEventTodoItem(line);
		}				
	}
	
	this.deleteEventTodoItem = function(line) {
		if ($('#event-todo-items').children().length == 1)
			cb_alert('You must have at least one ToDo item.');
		else
			document.getElementById('event-todo-items').removeChild(line)
	}
	
	// CONTACT HISTORY........
	this.listContactHistory = function() {
		var b = new cb_browse('contact-history-list');
		var sql = "select *, concat(left(note, 45), '...') as note_brief from contact_history where church_id=" + oChurch.details.id;
//console.log(sql)
		b.preQuery = 'create temporary table report (index(date)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print
		b.columns = ['id','login_id','date','note_brief','note'];
		b.colClass = ['hide','hide','note-date','note-note','hide'];
		b.colHeadings = ['','','Date','Note'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'date';
		b.sortReverse = true;
		b.deleteFn = [true, function(data) { oChurch.deleteNoteCheck(data[0]) } ];		
		b.fetch = function(data, xxx, data2) {
//console.log(xxx,yyy)
			oChurch.editNote('edit', data2);
		}
		b.init();
		oChurch.notes = b;
	}
	
	this.editNote = function(mode, data) {
//console.log(mode, data)
		if (mode == 'new') {
			var data = new Object();
			this.currentNote = 'new';
		}
		else
			this.currentNote = data.id;
		
		$('#contact-history-new-btn').hide();
		$('#contact-history-save-btn').show();
		$('#contact-history-note').show();
		
		$('#contact-history-loginID').html(data.login_id);
		$('#contact-history-note').val(data.note);
	}

	this.saveNote = function() {
		if (!formValidated('tab-4-content'))
			return;

		$('#contact-history-new-btn').show();
		$('#contact-history-save-btn').hide();
		$('#contact-history-note').hide();
		
		var sql = 'insert into contact_history set' +
						' id="' + this.currentNote + '"' +
						',church_id="' + this.details.id + '"' +
						',note="' + $('#contact-history-note').val() + '"' +
						',login_id="' + oLogin.uid + '"' +
						' on duplicate key' +
						' update note="' + $('#contact-history-note').val() + '", login_id="' + oLogin.uid +'"';
//console.log(sql)
		execSQL(sql, function() {
			oChurch.notes.refreshData();
			statusMsg('Note saved.');
		});
	}
	
	this.deleteNoteCheck = function(id) {
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to delete this Note?", 
			["Yes", "No"],
			[ function() { oChurch.deleteNote(id) }, function() {} ]
		);
	}
	
	this.deleteNote = function(id) {
		var sql = 'delete from contact_history where id=' + id;
		execSQL(sql, function() {
			oChurch.notes.refreshData();
		});
	}	
	
	this.checkForDuplicate = function() {
		if ($('#church-name').val() == '')
			return;
//console.log('checking')
		var sql = 'select name, address, city from churches where name like "%' + $('#church-name').val() + '%"';
		execSQL(sql, function(churches) {
//console.log(sql, churches)
			if (churches.length > 0) {
//console.log(churches);			
				var msg = 'Possible duplicate churches already exist:<br><br>';
				msg += '<table style="display: block; background-color: white; height: 220px; overflow-y: auto; border: 1px solid black">';
				for (var x in churches) {
					msg += '<tr>';
						msg += '<td>';
							msg += '<hr>' + churches[x].name + ', ' + churches[x].address + ', ' + churches[x].city;
						msg += '</td>';
					msg += '</tr>';
				}
				msg += '</table>';
				
				cb_alert(msg);
			}
		});
	}
	
}
