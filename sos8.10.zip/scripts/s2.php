<?php
require '../3rd-party/s2/s2-api.php';
include 'db-conx.php';

$s2 = new subsApi($_GET['s2keys']);
//$s2 = new subsApi('uk-test-keys.json');

$query = $_GET['query'];
$result = '';

switch ($query) {
	case 'updateS2': {
		// order by type so that 'C' is first. Subs updates depend on 'C' records existing in s2
		$sql = 'select * from s2_log where s2_updated=0 order by type';	
		$st = $db_handle->prepare($sql);
		$st->execute();

		while ($logRecord = $st->fetch()) {
			
			// mark it as 'in progress' (=2) so that any rapid calls to updateS2() won't duplicate the requests
			$sql = 'update s2_log set s2_updated=2 where id=?';
			$st2 = $db_handle->prepare($sql);
			$st2->execute(array($logRecord['id']));	
			
			switch($logRecord['type']) {
				case 'C': {
					$result = s2updateCustomer($logRecord['id'], $logRecord['customer_id']);
					break;
				}
				case 'S': {	// create new sub
					$result = s2createSubscription($logRecord['id'], $logRecord['recipient_id'], $logRecord['customer_id'], $logRecord['num_issues'], $logRecord['qty'], $logRecord['pub_id'], $logRecord['start_issue'], $logRecord['end_issue'], $logRecord['email'], $logRecord['mag_sub_id']);
					break;
				}				
				case 'R': {	// renewal
					s2renewSubscription($logRecord['id'], $logRecord['sub_id'], $logRecord['num_issues']);
					break;
				}
				case 'L': {		// last issue
					updateLastIssue($logRecord['id'], $logRecord['sub_id'], $logRecord['end_issue'], $logRecord['notes']);
					break;
				}
				case 'Q': {	// quantity
					updateQuantity($logRecord['id'], $logRecord['sub_id'], $logRecord['qty']);
					break;
				}
				case 'N': {	// note
					addNote($logRecord['id'], $logRecord['sub_id'], $logRecord['notes']);
					break;
				}
				case 'X': {	// cancel sub
					cancelSubscription($logRecord['id'], $logRecord['sub_id'], $logRecord['notes']);
					break;
				}
				case 'D': {	// remove giver
					removeGiver($logRecord['id'], $logRecord['sub_id'], $logRecord['notes']);
					break;
				}
			}
		}
		break;
	}

	case 'getSubscriptions': {
		$fedID = getFedID($_GET['sosID']);

		if ($fedID == 'no customer') {
			$result = '';
		}
		else
			$result = $s2->getCustomerSubscriptions($fedID);
		break;
	}	

	case 'getSubscription': {
		$result = $s2->getSubscription($_GET['subID']);		
		break;
	}
	
}

echo json_encode($result);


function getFedID($sosID) {
	global $db_handle, $s2;
	
	$fedID = '';
	$result = ($s2->searchCustomersByAccountingId($sosID));

//echo 'hh='. json_encode($result);	
//echo $result['conxStatus'];	
//echo '-->' . isset($result['status']);	

	if (isset($result->status)) {
		if ($result->status == 'failed') {		// connection error
		// nothing to be done
		}
		elseif ($result->status == 'notice') {		
			$fedID = 'no customer';		// s2 customer record not found
		}
	}
	else {		// there is an existing s2 record
		$fedID = $result->federationid;
	}	
	
	return $fedID;
}

/*	Creates OR updates s2 customer record. 
*/
function s2updateCustomer($logID, $sosID) {
	global $db_handle, $s2;
	
	// look up the SOS customer record
	$sql = 'select * from customers where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($sosID));		
	$customer = $st->fetch();

	// set up data needed for s2
	$data = array(
		'webstoreid' => '',
		'title' => $customer['salutation'],
		'firstname' => $customer['first_name'],
		'lastname' => $customer['last_name'],
		'addr1' => $customer['address'],
		'addr2' => $customer['address_2'],
		'city' => $customer['city'],
		'state' => $customer['province'],
		'postcode' => $customer['postal_code'],
		'country' => $customer['country'],
		'email' => $customer['email1']
	);
	
	$fedID = getFedID($sosID);
	
	if ($fedID == 'no customer') {		// s2 record not found, so create one
		$data['accountingid'] = $customer['id'];
		$result = $s2->createCustomer(json_encode($data));
	}
	else {		// there is a pre-existing s2 record
		$data['federationid'] = $fedID;
		$result = $s2->updateCustomer(json_encode($data));
	}

	if ($result->status == 'success') {
		// mark all the s2_log record(s) that refer to this customer as 's2 updated'
		$updated = 1;	
	} 
	else {
		$updated = 0;
	}
	$msg = $result->message;

	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($msg, $updated, $logID));

	return $result;
}

// creates a single subscription - using '$id' which is the SOS s2_log ID
function s2createSubscription($id, $recipientID, $donorID, $numIssues, $qty, $pubID, $startIssue, $endIssue, $email, $magSubID) {
	global $db_handle, $s2;
	$updated = 0;
	$result = '';
	$s2ID = 0;

	$s2donorID = getFedID($donorID);

	// establish if this is a gift sub
	if ($donorID == $recipientID) {		// it's a sub for self
		$s2recipientID = $s2donorID;
		$s2donorID = '';
	}
	else {		// gift sub
		$s2recipientID = getFedID($recipientID);
	}
	
	if (($s2recipientID != '' && $s2recipientID == 'no customer') || ($s2donorID != '' && $s2donorID == 'no customer')) {
		$response = 'No customer found';
	}
	else {
		$data = array(
			'federationid' => $s2recipientID,
			'issuecount' => $numIssues,
			'qty' => $qty,
			'analytics' => array( 
				'sourceid' => '',
				'event_id' => '',
			),
			'pubid' => $pubID,
			'giverid' => $s2donorID,
			'email' => $email
		);	
		
		if ($startIssue != 0) {		// this has custom start and end issue numbers
			$data['customStartIssue'] = $startIssue;
			$data['customExpiryIssue'] = $endIssue;
		}
//echo json_encode($data);
		
		$result = $s2->createSubscription(json_encode($data));
		$response = $result->message;		
		if ($result->status == 'success') {
			$updated = 1;	// s2 successfully updated so flag the s2_log record, i.e. update has been done
			
			// and provide the vital link between s2 and sos, i.e. the s2 sub_id
			$s2ID = $result->subid;
			$sql = 'update mag_subs set s2_id=? where id=?';
			$st = $db_handle->prepare($sql);
			$st->execute(array($s2ID, $magSubID));					
		}
	}
	
	$sql = 'update s2_log set s2_response=?, s2_updated=?, sub_id=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($response, $updated, $s2ID, $id));	

	return $result;
}

// renews a single subscription - using '$id' which is the SOS s2_log ID
function s2renewSubscription($id, $subID, $numIssues) {
	global $db_handle, $s2;

	$data = array(
		'subid' => $subID,
		'issuecount' => $numIssues
	);	
	$result = $s2->renewSubscription(json_encode($data));
	if ($result->status == 'success')
		$updated = 1;	// s2 successfully updated so flag the s2_log record, i.e. update has been done
	else
		$updated = 0;
	
	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($result->message, $updated, $id));	
	
	return $result;
}

function updateLastIssue($s2logID, $subID, $lastIssue, $note) {
	global $db_handle, $s2;
	
	$newExpiry = substr($lastIssue, 0, 2) . substr($lastIssue, 3, 1) . '0';
	
	$data = array(
		'subId' => $subID,
		'reason' => $note,
		'newExpiry' => $newExpiry
	);

	$updated = 0;
	$result = $s2->adjustExpiry(json_encode($data));
	if ($result->status == 'success')
		$updated = 1;
		
	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($result->message, $updated, $s2logID));	

	return $result;
}

function updateQuantity($s2logID, $subID, $qty) {
	global $db_handle, $s2;
	
	$data = array(
		'subid' => $subID,
		'newqty' => $qty
	);

	$updated = 0;
	$result = $s2->adjustBulks(json_encode($data));
	if ($result->status == 'success')
		$updated = 1;
		
	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($result->message, $updated, $s2logID));	

	return $result;
}

function addNote($s2logID, $subID, $note) {
	global $db_handle, $s2;
	
	$updated = 0;
	$result = $s2->commentSubscription($subID, $note);
	if ($result->status == 'success')
		$updated = 1;
		
	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($result->message, $updated, $s2logID));	

	return $result;
}

function cancelSubscription($s2logID, $subID, $note) {
	global $db_handle, $s2;
	
	$data = array(
		'subId' => $subID,
		'reason' => $note
	);	
	
	$updated = 0;
	$result = $s2->cancelNow(json_encode($data));
	if ($result->status == 'success')
		$updated = 1;
		
	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($result->message, $updated, $s2logID));	

	return $result;
}

function removeGiver($s2logID, $subID, $note) {
	global $db_handle, $s2;
	
	$updated = 0;
	$result = $s2->removeRelationshipFromSub($subID, $note);
	if ($result->status == 'success')
		$updated = 1;
		
	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($result->message, $updated, $s2logID));	

	return $result;
}
?>