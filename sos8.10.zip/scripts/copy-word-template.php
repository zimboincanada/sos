<?php
require_once '../3rd-party/PHPWord/PHPWord.php';

/*
$PHPWord = new PHPWord();

$document = $PHPWord->loadTemplate('Template.docx');

$document->setValue('Value1', 'Sun');
$document->setValue('Value2', 'Mercury');
$document->setValue('Value3', 'Venus');
$document->setValue('Value4', 'Earth');
$document->setValue('Value5', 'Mars');
$document->setValue('Value6', 'Jupiter');
$document->setValue('Value7', 'Saturnz');
$document->setValue('Value8', 'Uranus');
$document->setValue('Value9', 'Neptun');
$document->setValue('Value10', 'Pluto');

$document->setValue('weekday', date('l'));
$document->setValue('time', date('H:i'));

$document->save('Solarsystem.docx');
*/

$replacements = $_POST['mmData'];
$templatePath = $_POST['templatePath'];
$templateName = $templatePath . $_POST['sourceFile'];
$newFile = '../uploads/' . $_POST['sourceFile'];

echo mailMerge($templateName, $newFile, $replacements);

function mailMerge($templateFile, $newFile, $replacements) {
	
	$PHPWord = new PHPWord();
	
	if (!copy($templateFile, $newFile)) {		// make a duplicate so we don't overwrite the template
		return false; 	// could not duplicate template
	}
	
	$document = $PHPWord->loadTemplate($newFile);

	foreach ($replacements as $key => $value) {
		$document->setValue($key, htmlspecialchars($value));
	}
	$document->setValue("{CRLF}", "<w:br/>");
		
	$document->save($newFile);	
	
	return true;
}

/*
function bob() {
	//$data = 'this is a drill';
	//echo $data;
	//$data = str_replace("drill", "banana", $data);
	//echo $data;
	//die(0);

	//echo 'begin';
	//$replacements = array('{CHURCH}' => 'Church of the Lukewarm', '{SPEAKER}' => 'Philip Bell');
	$replacements = $_POST['mmData'];
	$templatePath = $_POST['templatePath'];
	$templateName = $templatePath . $_POST['sourceFile'];
	//$templateName = 'c:/wamp/www/sos/word_templates/' . $_POST['sourceFile'];
	$newFile = '../uploads/' . $_POST['sourceFile'];
	//$templateName = 'C:/wamp/www/sos//test-source.docx';

	echo mailMerge($templateName, $newFile, $replacements);
	//echo 'all done';
	//echo json_encode($replacements);
}

function mailMerge($templateFile, $newFile, $row) {
//echo 'starting MM...';
	if (!copy($templateFile, $newFile)) {		// make a duplicate so we don't overwrite the template
//echo 'NOT copied.';
		return false; 	// could not duplicate template
	}
	
//echo 'copied.';
	$zip = new ZipArchive();
	if ($zip->open($newFile, ZIPARCHIVE::CHECKCONS) !== TRUE) {
//echo 'not a DOCx';
		return false; 	// probably not a docx file
	}

//echo 'replacing...';

	$file = substr($templateFile, -4) == '.odt' ? 'content.xml' : 'word/document.xml';
	$data = $zip->getFromName($file);


//	for ($x=0; $x<sizeof($row); $x++) {
//		$key = 'key';
//		$value = 'value';
//echo '>'.  $key . '-' . $value . '<';
//		$data = str_replace($key, $value, $data);	
//	}

	foreach ($row as $key => $value) {
//echo '<br>>'.  $key . '-' . $value . '<' ;
		$data = str_replace($key, $value, $data);
	}
	$data = str_replace("{CRLF}", "<w:br/>", $data);
	
//$bob = '</w:tab xml:space="preserve">';
//$bob = '<w:tab w:val="left" w:leader="dot" w:pos="1440"/>some text';	// works
//$bob = '&#x9;some text';
	
//	$data = str_replace("{TAB}", $bob, $data);
//$data = str_replace("Person Name", "BobBob", $data);
	
//echo '<br>after=' . $data;
		
	$zip->deleteName($file);
	$zip->addFromString($file, $data);
	$zip->close();
	
	return true;
} */
?>