<?php
//	include "db-conx.php";
	
	
/*		$versions = file_get_contents("https://raw.github.com/zimboincanada/sos/master/version-history.txt");
		$split = explode("\n", $versions);

		foreach ($split as $string) {
			echo $string . '<br>';
		}
		
die(0);	
*/
	
	switch($_GET['func']) {
		case 'getReleaseInfo': {
			$info = releaseInfo();
			echo json_encode($info);
			break;
		}
		
		case 'execDownload': {
			echo execDownload();
			break;
		}
		
		case 'doUnzip': {
			echo extractZipFile();
			break;
		}

		case 'xxxxxxxxxxxxxxrenameAppFolder': {
			$result = rename("c:/wamp/www/sos/8.05", "sosbob");
//			$result = rename("test", "test_bob");
//			$result = rename(realpath(dirname(__FILE__)).'\sos',realpath(dirname(__FILE__)).'\sos_bob');
echo json_encode($result);
			break;
		}

	}
	
	function releaseInfo() {
		
		$currentVersion = (float)$_GET['version'];
		$releaseInfo = new stdClass();
		$releaseInfo->isNewRelease = false;

/*		$file = "releases.txt";
		$fopen = fopen($file, "r");
		$fread = fread($fopen,filesize($file));
		fclose($fopen);

		$remove = "\n";
		$split = explode($remove, $fread);
*/
		$versions = file_get_contents("https://raw.github.com/zimboincanada/sos/master/version-history.txt");
		$split = explode("\n", $versions);
		
		foreach ($split as $string) {
			if ((float)$string > $currentVersion) {
				$releaseInfo->isNewRelease = true;
				$releaseInfo->version = $string;
				return $releaseInfo;
			}
//echo $string;
		}
		
		return $releaseInfo;
	}

	function execDownload() {
		$result = file_put_contents(
			'C://wamp//www//sos//sos8.05.zip',
			file_get_contents( 'https://raw.github.com/zimboincanada/sos/master/sos8.05.zip' )
		);
		return $result;
	}

	function extractZipFile() {
		$zip = new ZipArchive;
		$res = $zip->open('C:/wamp/www/sos/sos8.05.zip');
		if ($res === TRUE) {
//			$zip->extractTo('/myzips/extract_path/');
			$zip->extractTo('C:/wamp/www/sos/9.00');
			$zip->close();
			echo 'woot!';
		} 
		else {
			echo 'doh!';
		}
	}

	function xxxxxxxxxxxxxxrenameAppFolder() {
		$zip = new ZipArchive;
		$res = $zip->open('C:/wamp/www/sos/data/test.zip');
		if ($res === TRUE) {
//			$zip->extractTo('/myzips/extract_path/');
			$zip->extractTo('C:/wamp/www/sos/data/bob/');
			$zip->close();
			echo 'woot!';
		} 
		else {
			echo 'doh!';
		}
		return rename(oldname, newname);
	}



?>