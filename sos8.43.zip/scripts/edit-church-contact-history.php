<?php
include "db-conx.php";

$noteID = $_POST['noteID'];
$churchID = $_POST['churchID'];
$note = $_POST['note'];
$followUp = $_POST['followUp'];
$loginID = $_POST['loginID'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();
		
/*		var sql = 'insert into contact_history set' +
						' id="' + this.currentNoteID + '"' +
						',church_id="' + oChurch.details.id + '"' +
						',note="' + $('#contact-history-note').val() + '"' +
						',follow_up="' + $('#contact-history-note-follow-up').val() + '"' +
						',login_id="' + $('#contact-history-note-owner').val() + '"' +
						' on duplicate key' +
						' update note="' + $('#contact-history-note').val() + '", login_id="' + $('#contact-history-note-owner').val() +'", follow_up="' + $('#contact-history-note-follow-up').val() + '"';
*/		
	$sql = 'insert into contact_history (id, church_id, note, follow_up, login_id)
				values (?,?,?,?,?)
				on duplicate key
				update note=?, login_id=?, follow_up=?';
	$sth = $db_handle->prepare($sql);
	$success = $sth->execute(array(
		$noteID,
		$churchID, 
		$note, 
		$followUp, 
		$loginID, 
		$note, 
		$loginID, 
		$followUp
	));
	
	if ($noteID == 'new') {
		$noteID = $db_handle->lastInsertId();
	}

	$result->sql = $sql;
	$result->success = $success;
	$result->id = $noteID;
	$result->errorMessage = $sth->errorInfo();
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);
?>