<?php
include "db-conx.php";

$id = $_POST['id'];
$name = $_POST['name'];
$shortName = $_POST['shortName'];
$startDate = $_POST['startDate'];
$endDate = $_POST['endDate'];
$region = $_POST['region'];
$isFull = $_POST['isFull'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();
		
	$sql = 'insert into tours (id, name, short_name, start_date, end_date, region, is_full)
				values (?,?,?,?,?,?,?)
				on duplicate key
				update name=?, short_name=?, start_date=?, end_date=?, region=?, is_full=?';
	$sth = $db_handle->prepare($sql);
	$success = $sth->execute(array(
		$id,
		$name, 
		$shortName, 
		$startDate, 
		$endDate, 
		$region,
		$isFull,
		$name, 
		$shortName, 
		$startDate, 
		$endDate, 
		$region,
		$isFull
	));
	
	if ($id == 'new') {
		$id = $db_handle->lastInsertId();
	}

	$result->sql = $sql;
	$result->success = $success;
	$result->id = $id;
	$result->errorMessage = $sth->errorInfo();
	
	updateTodoItems($id);
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);

function updateTodoItems($tourID) {
	global $db_handle;

	$sql = 'delete from tour_todo_items where tour_id=?';
	$sth = $db_handle->prepare($sql);
	$sth->execute(array($tourID));

	$todos = $_POST['tourTodos'];	
	if (sizeof($todos) == 0)
		return;
	
	for ($x=0; $x<sizeof($todos); $x++) {
		$sql = 'insert into tour_todo_items set item=?, complete=?, due=?, event_planner=?, tour_id=?';
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($todos[$x][0], $todos[$x][1], $todos[$x][2], $todos[$x][3], $tourID));
	}
}
?>