<?php

/* 	update inventory qty
	$mode: 	0=stock adjust ($qty only)
					1=sales order ($qty only); delete PO if status == 2
					2=po receipting (must supply $cost)
					3=execute mode 0 (with inverse qty) plus mode 1
	$qty = the amount to adjust by.


if mode == 1 and CA and isPack
	if customer type=event then 
		deduct from pack invnmetory
	else 
		assemble-on-the-fly
end if

*/
function updateInventory($mode, $sku, $qty, $cost) {

	if ($mode == 3) {
		$seminarCustomer = $_POST['seminarCustomer'];
		if ($seminarCustomer == 'false' && isPack($sku) && usePackAssembly())		// assemble pack before can sell it
			actuallyUpdateInventory(0, $sku, -$qty, $cost);
			
		actuallyUpdateInventory(1, $sku, $qty, $cost);
	}
	else
		actuallyUpdateInventory($mode, $sku, $qty, $cost);
}

function actuallyUpdateInventory($mode, $sku, $qty, $cost) {
	global $db_handle;
	
	if ($mode == 0 || $mode == 1) {
		$sql = "update products set qty=qty-? where sku=?";						
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($qty, $sku));
	}
	else {
		$sql = "update products set qty=qty-?, previous_cost=cost, cost=? where sku=?";						
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($qty, $cost, $sku));
	}

	switch ($mode) {
		case 0: {
			if (usePackAssembly())
				$qty = -$qty;		// reduce pack, increase bom items and vice versa
			else
				return;	// don't reduce bom items
			break;
		}
	
		case 1: {
			if (usePackAssembly())		// CA
				return;	// don't reduce bom items
			break;
		}
		
		case 2: {
			return;	// don't reduce bom items
			break;
		}
	}
	
	// update all the BOM items, if there are any:
	// get a list of all the products that make up the pack (i.e. $sku)
	$sql = "select sku, qty from product_boms where parent_sku='" . $sku . "'";
	$sth = $db_handle->prepare($sql);
	$sth->execute();

	// for each of the products that make up a pack, update qty
	while ($data = $sth->fetch()) {	
		if ($mode == 0 || $mode == 1) {
			$sql = "update products set qty=qty-? where sku=?";						
			$sth2 = $db_handle->prepare($sql);
			$sth2->execute(array($qty, $data['sku']));
		}
		else {
			$sql = "update products set qty=qty-?, previous_cost=cost, cost=? where sku=?";						
			$sth2 = $db_handle->prepare($sql);
			$sth2->execute(array($qty, $cost, $data['sku']));
		}
	}		
}

function usePackAssembly() {
	global $db_handle;

	$sql = "select use_pack_assembly from settings limit 1";
	$st = $db_handle->prepare($sql);
	$st->execute();
	$settings = $st->fetch();

	return ($settings['use_pack_assembly'] == 1);
}


function isPack($sku) {
	global $db_handle;

	$sql = "select pack from products where sku=?";
	$st = $db_handle->prepare($sql);
	$st->execute(array($sku));
	$product = $st->fetch();
		
	return ($product['pack'] == 1);
}
?>