<?php
include "db-conx.php";

$id = $_POST['id'];
$churchID = $_POST['churchID'];
$name = $_POST['name'];
$contactName = $_POST['contactName'];
$phone = $_POST['phone'];
$eventDate = $_POST['eventDate'];
$eventDateTo = $_POST['eventDateTo'];
$noWeb = $_POST['noWeb'];
$singleSpeaker = $_POST['singleSpeaker'];
$bookTable = $_POST['bookTable'];
$eventPlanner = $_POST['eventPlanner'];
$attendanceExpected = $_POST['attendanceExpected'];
$address = $_POST['address'];
$city = $_POST['city'];
$county = $_POST['county'];
$postalCode = $_POST['postalCode'];
$region = $_POST['region'];
$useChurchAddress = $_POST['useChurchAddress'];
$accommodationDetails = $_POST['accommodationDetails'];
$attendanceActual = $_POST['attendanceActual'];
$attendanceActualU18 = $_POST['attendanceActualU18'];
$directionDetails = $_POST['directionDetails'];
$giftPledged = $_POST['giftPledged'];
$gift = $_POST['gift'];
$giftOther = $_POST['giftOther'];
$tourID = $_POST['tourID'];
$notes = $_POST['notes'];
$status = $_POST['status'];
$source = $_POST['source'];
$hostDetails = $_POST['hostDetails'];
$volunteerDetails = $_POST['volunteerDetails'];
$cmiEquipment = $_POST['cmiEquipment'];
$accessTimeDetails = $_POST['accessTimeDetails'];
$mealDetails = $_POST['mealDetails'];
$itineraryNotes = $_POST['itineraryNotes'];
$presentationType = $_POST['presentationType'];
$webpageID = $_POST['webpageID'];
$magSubs = $_POST['magSubs'];
$infobytes = $_POST['infobytes'];
$comments = $_POST['comments'];
$salesCash = $_POST['salesCash'];
$salesCheque = $_POST['salesCheque'];
$salesCard = $_POST['salesCard'];
$salesInvoice = $_POST['salesInvoice'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();
	
	$sql = 'insert into events (id, church_id, name, contact_name, phone, event_date, event_date_to, no_web, single_speaker, attendance_expected, address, city, county, postal_code, region, use_church_address, accommodation_details, book_table, event_planner, attendance_actual, attendance_actual_u18, direction_details, gift_pledged, gift, gift_other, tour_id, notes, status, source, host_contact_details, volunteer_details, cmi_equipment, access_time_details, meal_details, presentation_type, webpage_id, magsubs, infobytes, comments, sales_cash, sales_cheque, sales_card, sales_invoice, itinerary_notes)
				values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
				on duplicate key
				update church_id=?, name=?, contact_name=?, phone=?, event_date=?, event_date_to=?, no_web=?, single_speaker=?, attendance_expected=?, address=?, city=?, county=?, postal_code=?, region=?, use_church_address=?, accommodation_details=?, book_table=?, event_planner=?, attendance_actual=?, attendance_actual_u18=?, direction_details=?, gift_pledged=?, gift=?, gift_other=?, tour_id=?, notes=?, status=?, source=?, host_contact_details=?, volunteer_details=?, cmi_equipment=?, access_time_details=?, meal_details=?, presentation_type=?, webpage_id=?, magsubs=?, infobytes=?, comments=?, sales_cash=?, sales_cheque=?, sales_card=?, sales_invoice=?, itinerary_notes=?';
	$sth = $db_handle->prepare($sql);
	$success = $sth->execute(array(
		$id,
		$churchID,
		$name, 
		$contactName, 
		$phone, 
		$eventDate, 
		$eventDateTo, 
		$noWeb,
		$singleSpeaker, 
		$attendanceExpected,
		$address, 
		$city, 
		$county, 
		$postalCode, 
		$region, 
		$useChurchAddress, 
		$accommodationDetails, 
		$bookTable, 
		$eventPlanner, 
		$attendanceActual, 
		$attendanceActualU18, 
		$directionDetails, 
		$giftPledged, 
		$gift, 
		$giftOther, 
		$tourID, 
		$notes, 
		$status, 
		$source, 
		$hostDetails, 
		$volunteerDetails, 
		$cmiEquipment, 
		$accessTimeDetails, 
		$mealDetails, 
		$presentationType,
		$webpageID,
		$magSubs,
		$infobytes,
		$comments,
		$salesCash,
		$salesCheque,
		$salesCard,
		$salesInvoice,
		$itineraryNotes,
		$churchID,
		$name, 
		$contactName, 
		$phone, 
		$eventDate, 
		$eventDateTo, 
		$noWeb,		
		$singleSpeaker, 
		$attendanceExpected,
		$address, 
		$city, 
		$county, 
		$postalCode, 
		$region, 
		$useChurchAddress, 
		$accommodationDetails, 
		$bookTable, 
		$eventPlanner, 
		$attendanceActual,
		$attendanceActualU18,
		$directionDetails, 
		$giftPledged, 
		$gift, 
		$giftOther, 
		$tourID, 
		$notes, 
		$status,
		$source,
		$hostDetails, 
		$volunteerDetails, 
		$cmiEquipment, 
		$accessTimeDetails,
		$mealDetails,
		$presentationType,
		$webpageID,
		$magSubs,
		$infobytes,
		$comments,
		$salesCash,
		$salesCheque,
		$salesCard,
		$salesInvoice,
		$itineraryNotes
	));
	
	if ($id == 'new') {
		$id = $db_handle->lastInsertId();
	}

	$result->sql = $sql;
	$result->success = $success;
	$result->id = $id;
	$result->errorMessage = $sth->errorInfo();
	
	addTalks($id);
	updateTodoItems($id);
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);

function updateTodoItems($eventID) {
	global $db_handle;

	$sql = 'delete from event_todo_items where event_id=?';
	$sth = $db_handle->prepare($sql);
	$sth->execute(array($eventID));

	$todos = $_POST['eventTodos'];	
	if (sizeof($todos) == 0)
		return;
	
	for ($x=0; $x<sizeof($todos); $x++) {
		$sql = 'insert into event_todo_items set item=?, complete=?, due=?, event_planner=?, event_id=?';
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($todos[$x][0], $todos[$x][1], $todos[$x][2], $todos[$x][3], $eventID));
	}
}

function addTalks($eventID) {
	global $db_handle;
	
	$sql = 'delete from event_talks where event_id=?';
	$sth = $db_handle->prepare($sql);
	$sth->execute(array($eventID));
	
	$talks = $_POST['eventTalks'];	
	if (sizeof($talks) == 0)
		return;
	
	for ($x=0; $x<sizeof($talks); $x++) {
		$speaker = $talks[$x][0];
		$talk = $talks[$x][1];
		$date = $talks[$x][2];
		$time = $talks[$x][3];
		$daily = $talks[$x][4];
		
		$sql = 'insert into event_talks set event_id=?, speaker=?, talk=?, talk_date=?, time=?, daily=?';
		$sth = $db_handle->prepare($sql);
		$sth->execute(array($eventID, $speaker, $talk, $date, $time, $daily));
	}
}
?>