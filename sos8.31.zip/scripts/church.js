window.onbeforeunload = function() { return confirmExit(); }
var oChurch = new church();
var oContact = new contact();
var oEvent = new event();
var oContactHistory = new contactHistory();

function confirmExit() {
	if (oChurch.unsavedChurch) {
		var confirmationMessage = 'It looks like you have been editing something. ';
		confirmationMessage += 'If you leave before saving, your changes will be lost.';
		return confirmationMessage;		
	}
}

function church() {
	this.init = function(fromForm, churchID) {
		var obj = this;
		this.eventMode = fromForm;
		
		this.unsavedChurch = false;
		$('#tab-1-content').on('change keyup', function () { obj.unsavedChurch = true; });

		if (global.isUK) {
			$('#church-county-label').show();
			$('#event-county-label').show();
//			$('#church-phone-label').on('click', function() { 
//				$('#church-phone-label').removeAttr("href");
//				$('#church-phone-label').click();
//				return false;
//			});	// dont have ring central
		}
		else {
			$('#church-province-label').show();
		}
		
		$("#event-talks, #event-todo-items").sortable();		// drag and drop
		
		$("#event-talks").on('sortout', function() {
			oEvent.singleSpeakerCheck();
		});
				
		if (this.eventMode == 'church') {
			var options = oSettings.church_status.split(',');
			fillPicklistWithData('church-status', options, options);
			var churchID = getURLParameter('church');
			
			var options = oSettings.provinces;
			fillPicklistWithData('church-province', options, options);			

			var options = oSettings.regions.split(',');
			fillPicklistWithData('church-region', options, options);			
			
			var options = oSettings.church_denominations.split(',');
			fillPicklistWithData('church-denomination', options, options);			

			oChurch.setupDetails(churchID);

			if (churchID == 'new')
				this.setOtherTabs(false);
			
			if (getURLParameter('tab') == 'contact_history')
				this.showTab(4);
			else if (getURLParameter('tab') == 'events') {
				this.showTab(3);
				oEvent.editEvent(getURLParameter('event_id'));
			}
			else
				this.showTab(1);
		}
		
		this.loadPicklists(churchID);

		tinymce.init({ 
			selector: '#event-document-text-edit',
			theme: "modern",
			plugins: [
				"advlist autolink lists link image charmap print preview hr anchor pagebreak",
				"searchreplace wordcount visualblocks visualchars code fullscreen",
				"insertdatetime media nonbreaking save table contextmenu directionality",
				"emoticons template paste textcolor"
			],
			toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
			toolbar2: "print preview media | forecolor backcolor fontselect fontsizeselect",
			image_advtab: true,
			height: 400
		});	
	}

	this.loadPicklists = function(churchID) {
		var options = oSettings.event_status.split(',');
		fillPicklistWithData('event-status', options, options);
		var options = oSettings.event_source.split(',');
		fillPicklistWithData('event-source', options, options);
//		var options = oSettings.presentation_type.split(',');
//		fillPicklistWithData('event-presentation-type', options, options);

		var options = oSettings.regions.split(',');
		fillPicklistWithData('event-region', options, options);					
		var options = oLogin.users;
		fillPicklistWithData('event-ep', options, options);					
		var options = oSettings.document_status.split(',');
		fillPicklistWithData('event-document-status', options, options);					

		var sql = 'select id, concat(left(short_name, 20), " [", start_date, "]") as name from tours where end_date>="' + today() + '" order by name';
		execSQL(sql, function(data) {
			var options = [], values = [];
			for (var x in data) {
				values.push(data[x].id);
				options.push(data[x].name);
			}
			fillPicklistWithData('event-tours', values, options);
$('option').mouseover(function(e) {
    var $target = $(e.target);
    if($target.is('option')) {
        console.log('yeah!');
    };
})	

		});
		
		var sql = 'select cc.contact_id, concat(c.first_name, " ", c.last_name) as name from church_contacts cc, customers c where c.id=cc.contact_id and cc.church_id=' + churchID;
//console.log(sql)		
		execSQL(sql, function(data) {
			var options = [], values=[];
			for (var x in data) {
//console.log(data[x])				
				values.push(data[x].contact_id);
				options.push(data[x].name);
			}
			fillPicklistWithData('event-contact', values, options);
		});
				
		var sql = 'select concat(first_name, " ", last_name) as name from customers where speaker=1';
		execSQL(sql, function(data) {
			var options = [];
			for (var x in data)
				options.push(data[x].name);
			fillPicklistWithData('event-speakers-list', options, options);
		});		
	}
	
	this.showTab = function(tab) {
	
		this.loadPicklists(oChurch.details.id);
		$('.tab').removeClass('active');
		$('#tab-' + tab).addClass('active');

		$('.tab-content').hide();
		$('#tab-' + tab + '-content').show();

		if (tab == 2)
			this.listContacts();
		if (tab == 3)
			this.listEvents();
		if (tab == 4)
			this.listContactHistory();
	}		

	this.setOtherTabs = function(show) {
		if (show) {
			$('#tab-2').show();
			$('#tab-3').show();
			$('#tab-4').show();
		}
		else {
			$('#tab-2').hide();
			$('#tab-3').hide();
			$('#tab-4').hide();
		}
	}		
	
	this.setupDetails = function(id) {
		var sql = 'select * from churches where id=' + id;
		execSQL(sql, function(data) {

			if (id == 'new') {
				oChurch.details = {};
				oChurch.details.id = 'new';
				$('#church-name').val('');
				$('#church-address').val('');
				$('#church-city').val('');
				$('#church-county').val('');
				$('#church-province').val('');
				$('#church-postal-code').val('');
				$('#church-region').val('');
				$('#church-phone').val('');
				$('#church-email').val('');
				$('#church-denomination').val('');
				var option = $("#church-status option:first").text();
				$('#church-status').val(option);
				$('#church-notes').val('');
				$('#church-website').val('');
				$('#church-mailing-address').val('');
			}
			else {
				oChurch.details = data[0];
				$('#church-name').val(oChurch.details.name);
				$('#church-address').val(oChurch.details.address);
				$('#church-city').val(oChurch.details.city);
				$('#church-county').val(oChurch.details.county);
				$('#church-province').val(oChurch.details.province);
				$('#church-postal-code').val(oChurch.details.postal_code);
				$('#church-region').val(oChurch.details.region);
				$('#church-phone').val(oChurch.details.phone);
				$('#church-email').val(oChurch.details.email);
				$('#church-denomination').val(oChurch.details.denomination);
				$('#church-status').val(oChurch.details.status);
				$('#church-notes').val(oChurch.details.notes);
				$('#church-website').val(oChurch.details.website);
				$('#church-mailing-address').val(oChurch.details.mailing_address);
			}	

			$(document).attr("title", oChurch.details.name);		// chrome tab name		
			$('#church-panel-name').html(oChurch.details.name);
			
		}, false);	
	}

	this.xxxxxxxxxupdateTabName = function() {
		$('#church-panel-name').html('bobr');
	};

	this.saveDetails = function() {
		var obj = this;
		if (!formValidated('tab-1-content'))
			return;

		oChurch.copyElementsToObject();

		$.ajax({
			type: 'post',
			url: "scripts/church.php",
			cache: false,
			data: { 
				churchData: JSON.stringify(oChurch.details)
			},
			success: function(result) { 
//console.log(result)
				if (oChurch.details.id == 'new') {
					oChurch.setOtherTabs(true);
					oChurch.details.id = result.id;
				}
				statusMsg('Church details saved.');
				obj.unsavedChurch = false;
				$('#church-panel-name').html(oChurch.details.name);
				log('EPIC CHURCH DETAILS UPDATED', oChurch.details.name);				
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}

	this.copyElementsToObject = function() {
		oChurch.details.name = $('#church-name').val();
		oChurch.details.address = $('#church-address').val();
		oChurch.details.city = $('#church-city').val();
		oChurch.details.county = $('#church-county').val();
		oChurch.details.province = $('#church-province').val();
		oChurch.details.postal_code = $('#church-postal-code').val();
		oChurch.details.region = $('#church-region').val();
		oChurch.details.phone = $('#church-phone').val();
		oChurch.details.email = $('#church-email').val();
		oChurch.details.denomination = $('#church-denomination').val();
		oChurch.details.status = $('#church-status').val();
		oChurch.details.notes = $('#church-notes').val();
		oChurch.details.website = $('#church-website').val();
		oChurch.details.mailing_address = $('#church-mailing-address').val();
	}
	
	this.merge = function() {
		
		document.getElementById('merge-form').overlay = doOverlay(true, 'merge-form');
		document.getElementById('merge-form').style.display = 'block';
		
		var b = new cb_browse('merge-form-data');
		var sql = "select * from churches where id<>" + oChurch.details.id;		// cannot merge with itself
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 350;
		b.controls[1] = true;		// print			
		b.columns = ['id','name','address','city'];
		b.colClass = ['hide','merge-name','merge-address'];
		b.colHeadings = ['ID','Name','Address','City'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'name';
		b.fetch = function(data) {
			oChurch.confirmMerge(data[0]);
		}
		b.init();
	}
	
	this.confirmMerge = function(duplicateID) {
		confirmBox(
			"CONFIRM",
			"Are you sure you want to continue?", 
			["Yes-merge the churches", "No"],
			[ function() { oChurch.executeMerge(duplicateID) }, function() {} ]
		);		
	}
	
	this.executeMerge = function(duplicateID) {
		$.ajax({
			type: 'post',
			url: "scripts/merge-church.php",
			cache: false,
			data: { 
				primaryID: oChurch.details.id,
				duplicateID: duplicateID
			},
			success: function(result) { 
				oChurch.closeMerge();
				statusMsg('Merge complete.');
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}
	
	this.closeMerge = function() {
		document.getElementById('merge-form').style.display = 'none';
		doOverlay(false, document.getElementById('merge-form').overlay);
	}	

	this.listContacts = function() {
		var b = new cb_browse('contacts');
		var sql = "select cc.id, c.id as customer_id, c.first_name, c.last_name, role, c.phone1, c.email1 from church_contacts cc, customers c where cc.contact_id=c.id and cc.church_id=" + oChurch.details.id;
//console.log(sql)
		b.preQuery = 'create temporary table report (index(last_name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print			
		b.columns = ['id', 'customer_id', 'first_name', 'last_name','role','phone1','email1'];
		b.colClass = ['hide', 'hide', 'con-name', 'con-name', 'con-role','con-phone','con-email'];
		b.colHeadings = ['ID','','First name','Last name','Role','Phone 1','Email 1'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'last_name';
		b.deleteFn = [true, function(xxx, yyy, json) { oContact.deleteCheck(json.id) } ];				
		b.fetch = function(xxx, yyy, json) {
//console.log(json)			
			oContact.edit(json.customer_id);
		}
		b.init();
	}
	
	this.listEvents = function() {
		var b = new cb_browse('events');
		var sql = "select *, ifnull((select group_concat(distinct speaker) from event_talks where event_id=e.id),'') as speakers, ifnull((select group_concat(distinct talk) from event_talks where event_id=e.id),'') as talks from events e where church_id=" + oChurch.details.id;
		b.preQuery = 'create temporary table report (index(event_date)) ENGINE=MyISAM (' + sql + ')';
//console.log(b.preQuery)		
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print
		b.columns = ['id','event_date','speakers','talks','attendance_actual','status'];
		b.colClass = ['hide','ev-date','ev-speaker','ev-talk','ev-attendance','ev-status'];
		b.colHeadings = ['ID','Event date','Speaker','Talk','Attendance (actual)','Status'];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'event_date';
		b.sortReverse = true;
		b.deleteFn = [true, function(data) { oChurch.deleteEventCheck(data[0]) } ];		
		b.fetch = function(data) {
			oEvent.editEvent(data[0]);
		}
		b.init();
		oChurch.events = b;
	}	
	
	this.deleteEventCheck = function(id) {
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to delete this Event?", 
			["Yes", "No"],
			[ function() { oChurch.deleteEvent(id) }, function() {} ]
		);
	}
	
	this.deleteEvent = function(id) {
		var sql = 'delete from events where id=' + id;
		execSQL(sql, function() {
			oChurch.events.refreshData();
		});
	}
	
	// CONTACT HISTORY........
	this.listContactHistory = function() {
		var b = new cb_browse('contact-history-list');
		var sql = "select *, concat(left(note, 85), '...') as note_brief from contact_history where church_id=" + oChurch.details.id;
		b.preQuery = 'create temporary table report (index(date)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.height = 250;
		b.controls[1] = true;		// print
		b.columns = ['id','date','note_brief','login_id','note', 'follow_up'];
		b.colClass = ['hide','note-date','note-note','note-ep','hide', 'note-follow-up'];
		b.colHeadings = ['','Date','Note','Note author', ''];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'date';
		b.sortReverse = true;
		b.deleteFn = [true, function(xxx, yyy, json) { oContactHistory.deleteCheck(json.id) } ];		
		b.rowCallback = function(row, b, json) {
//		console.log(a)
//		console.log(b)
//		console.log(c)
			var fld = row.getElementsByClassName('note-follow-up')[0];		
			if (json.follow_up == '0000-00-00')
				fld.innerHTML = '';
			else
//console.log('fld=',fld)
				fld.innerHTML = '<img src="images/follow-up.png" style="width: 20px; vertical-align: bottom;" title="Follow up required">';
		}
		b.fetch = function(xxx, yyy, json) {	
			oContactHistory.edit(json.id, json.note, json.follow_up);
		}
		b.init();
		oContactHistory.browse = b;
	}
	
	this.checkForDuplicate = function() {
		var currentChurch = oChurch.details.id;
		if ($('#church-name').val() == '')
			return;

		var sql = 'select name, address, city from churches where name like "%' + $('#church-name').val() + '%" and id<>' + currentChurch;
		execSQL(sql, function(churches) {

			if (churches.length > 0) {	
				var msg = 'Possible duplicate churches already exist:<br><br>';
				msg += '<table style="display: block; background-color: white; height: 220px; overflow-y: auto; border: 1px solid black">';
				for (var x in churches) {
					msg += '<tr>';
						msg += '<td>';
							msg += '<hr>' + churches[x].name + ', ' + churches[x].address + ', ' + churches[x].city;
						msg += '</td>';
					msg += '</tr>';
				}
				msg += '</table>';
				
				cb_alert(msg);
			}
		});
	}
	
	this.findOnMap = function(source) {
		var location = '';
		if (source == "church") {
			if (global.isUK) {
				location += $('#church-address').val();
				location += commaIf($('#church-city').val());
				location += commaIf($('#church-county').val());
				location += commaIf($('#church-postal-code').val());
			}
			else {
				location += $('#church-address').val();
				location += commaIf($('#church-city').val());
				location += commaIf($('#church-region').val());
				location += commaIf($('#church-postal-code').val());
			}
		}
		else {		// event
			location += $('#event-address').val();
			location += commaIf($('#event-city').val());
			location += commaIf($('#event-county').val());
			location += commaIf($('#event-postal-code').val());
		}
		window.open('https://www.google.co.uk/maps/search/' + location);
	}
	
	this.gotoWebsite = function() {
		var url = 'http://www.' + $('#church-website').val();
//console.log('url=',url)
		window.open(url);
	}
	
	this.launchEmail = function(target) {			
		$(target).attr("href", "mailto:" + $("#church-email").val());
	}	
	
	this.launchPhone = function(target) {
//console.log("tel:" + $("#church-phone").val());		
//return
		$(target).attr("href", "tel:" + $("#church-phone").val());
	}
	
}
