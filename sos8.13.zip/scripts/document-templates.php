<?php
include "db-conx.php";

$id = $_POST['id'];
$name = $_POST['name'];
$content = $_POST['content'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();

	$sql = 'insert into document_templates (id, name, content)
				values (?,?,?)
				on duplicate key
				update name=?, content=?';
				
	$sth = $db_handle->prepare($sql);
	$success = $sth->execute(array(
		$id,
		$name, 
		$content, 
		$name,
		$content
	));
	
	if ($id == 'new')
		$id = $db_handle->lastInsertId();		

	$result->success = $success;
	$result->id = $id;
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);
?>