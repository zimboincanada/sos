$(document).ready(function() {	// report 23 uses dymo
	dymo.label.framework.init(); 		// initialize dymo printer, then invoke a callback
});

var activeBrowse = new Object();

function getReportParams() {
	var reportNum = getURLParameter('report');
	var report = '#report-' + reportNum;
	$(report).show();

	switch (Number(reportNum)) {			
		case 7: {
			document.getElementById('r7-tax-year').value = today().substr(0,4)-1;		// last year is default
			break;
		}
		
		case 9: { 
			$("#r9-please-wait").hide(); 
			$("#r9-issue-num").mask("99:9"); 
			setIssueNumber("r9-issue-num", S_CURRENT_PRINT);
			
			if (global.isUK)
				$('#local-country').html('UK/Europe only');
			else
				$('#local-country').html(global.settings[S_COUNTRY] + ' only');
			
			break; 
		}
		case 10: { fillPicklist('r10-payment-type', S_PAYMENT_METHOD, function() {}); break; }
		case 11: { execReport(11); break; }	
		case 12: { 
			$("#r12-issue-num").mask("99:9"); 
			$("#r12-issue-num").val(getNextIssue(global.settings[S_CURRENT_PRINT], 'P'));
			setHarvestParams();
		}
		case 13: { 
			var startDate = today().substr(0,4)-1 + today().substr(4);	
			document.getElementById('r13-start-date').value = startDate; 
			document.getElementById('r13-end-date').value = today(); 
			break; 
		}
		case 14: { 
			// if the current date is July - Dec, default the date filters to January 1 - June 30; otherwise, default them to July 1 - Dec 31 of the prior year
			var dateStr = today();
			var year = dateStr.substr(0,4);
			var month = dateStr.substr(5,2);

			if (month >= 7 && month <= 12) {
				var d1 = year + '-01-01';
				var d2 = year + '-06-30';
			}
			else {
				year--;
				var d1 = year + '-07-01';
				var d2 = year + '-12-31';
			}

			document.getElementById('r14-start-date').value = d1; 
			document.getElementById('r14-end-date').value = d2; 

			var provinces = oSettings.provinces.slice(0);
			provinces.unshift('-All-');
			fillPicklistWithData('r14-province', provinces, provinces);
			
			break; 
		}
		case 15: { 
			document.getElementById('r15-start-date').value = today(); 
			fillPicklist('r15-payment-type', S_PAYMENT_METHOD, function() {}); 
			break; 
		}
		case 17: { 
			fillPicklist('r17-payment-type', S_PAYMENT_METHOD, function() {}); 
			break; 
		}
		case 20: { 
			fillPicklist('r20-payment-type', S_PAYMENT_METHOD, function() {
				option = document.createElement('option');
				document.getElementById('r20-payment-type').appendChild(option);
				option.value = '';
				option.textContent = '- All types -';				
			}); 
			break; 
		}		
		case 21: {
			execReport(21);
			break;
		}
		case 24: { 
			$("#r24-date").val(today()); 
			$("#r24-issue-number").mask("99:9"); 
		}
	}
}

function setHarvestParams() {
	var params = getHarvestParams();
	
	if (params.harvestType == 'mini') {
		$('#r12-format-print').prop("checked", true);
		$('#r12-format-digital').prop("checked", false);
		$('#r12-format-digital').prop("disabled", true);

		$('#r12-renewal-options-no').prop("checked", true);
		$('#r12-renewal-options-yes').prop("checked", false);
		$('#r12-renewal-options-yes').prop("disabled", true);
		$('#r12-renewal-options-both').prop("checked", false);
		$('#r12-renewal-options-both').prop("disabled", true);
	}
	else {
		$('#r12-format-digital').prop("disabled", false);
		$('#r12-renewal-options-yes').prop("disabled", false);
		$('#r12-renewal-options-both').prop("disabled", false);
	}
	
	params = getHarvestParams();		// a quick refresh of the object
		
	// #2
	if (params.harvestType == 'mini') {
		if (params.pubType == 'journal')
			$("#r12-issue-num").val(global.settings[S_CURRENT_JOURNAL]);
		if (params.pubType == 'magazine')
			if (params.format == 'print')
				$("#r12-issue-num").val(global.settings[S_CURRENT_PRINT]);	
			else
				$("#r12-issue-num").val(global.settings[S_CURRENT_DIGITAL]);	
	}
	else {
		if (params.pubType == 'journal')
			$("#r12-issue-num").val(getNextIssue(global.settings[S_CURRENT_JOURNAL], 'J'));
		if (params.pubType == 'magazine')
			if (params.format == 'print')
				$("#r12-issue-num").val(getNextIssue(global.settings[S_CURRENT_PRINT], 'P'));
			else
				$("#r12-issue-num").val(getNextIssue(global.settings[S_CURRENT_DIGITAL], 'D'));
	}

	// #2b
	if (params.harvestType == 'main' && params.pubType == 'journal' && params.format == 'digital') {
		$('#r12-issue-num').val(global.settings[S_CURRENT_JOURNAL]);
	}			
}

function getHarvestParams() {
	var harvestParams = {
		harvestType: getRadioValue('r12-harvest-options'), 
		pubType: getRadioValue('r12-pub-options'), 
		renewalType: getRadioValue('r12-renewal-options'), 
		format: getRadioValue('r12-format-options'),  
		qty: { 
			single: document.getElementById('r12-qty-single').checked, 
			bulk: document.getElementById('r12-qty-bulk').checked
		},
		issueNumber: $('#r12-issue-num').val()
	};
	
	return harvestParams;
}

function validateHarvestParams() {
	var params = getHarvestParams();
		
	if (!params.qty.single && !params.qty.bulk) {
		cb_alert('You must select a quantity.')
		return;
	}
	
	var msg = '';
	if (params.harvestType == 'mini') {
		if (params.pubType == 'journal')
			if (params.issueNumber != global.settings[S_CURRENT_JOURNAL])
				msg = 'That is an unexpected issue number.';
		if (params.pubType == 'magazine')
			if (params.issueNumber != global.settings[S_CURRENT_PRINT])
				msg = 'That is an unexpected issue number.';
	}
	else  {
		if (params.pubType == 'journal') {
			if (params.format == 'print') {
				if (params.issueNumber != getNextIssue(global.settings[S_CURRENT_JOURNAL], "J"))
					msg = 'That is an unexpected issue number.';
			}
			else {
				if (params.issueNumber != global.settings[S_CURRENT_JOURNAL])
					msg = 'That is an unexpected issue number.';
			}
		}
			
		if (params.pubType == 'magazine') {
			if (params.format == 'print') {
				if (params.issueNumber != getNextIssue(global.settings[S_CURRENT_PRINT], "P"))
					msg = 'That is an unexpected issue number.';
			}
			else {
				if (params.issueNumber != getNextIssue(global.settings[S_CURRENT_DIGITAL], "D"))
					msg = 'That is an unexpected issue number.';			
			}
		}
	}
	showHarvestWarning(msg);
	
	execReport(12);
}

function showHarvestWarning(msg) {
	$('#r12-harvest-warning').html(msg);
}

// build prompts and sql for completion of harvest
function confirmHarvest(params, conditions) {
	var prompt, msg;
	var updateSQL;
	var cutoffAlert = false;
	
	if (params.harvestType == 'main') {
		
		prompt = 'Do you want to permanently increment the next issue number to ' + params.issueNumber + '?';

		if (params.pubType == 'magazine') {
			if (params.format == 'print') {
				cutoffAlert = (global.settings[S_CUT_OFF_PERIOD] == 0);
				updateSQL = 'update settings set current_print="' + params.issueNumber + '", cut_off_period=0';
			}
			else {
				cutoffAlert = (global.settings[S_CUT_OFF_PERIOD_D] == 0);
				updateSQL = 'update settings set current_digital="' + params.issueNumber + '", cut_off_period_d=0';
			}
		}
		else {			// journal
			cutoffAlert = (global.settings[S_CUT_OFF_PERIOD_J] == 0);
			updateSQL = 'update settings set current_journal="' + params.issueNumber + '", cut_off_period_j=0';
		}
		msg = 'Next issue number has been incremented to ' + params.issueNumber;
	}
	else {		// mini harvest
		prompt = "Do you want to permanently set the Issue Status to 'Active' ?";
		updateSQL = 'update mag_subs ms, customers c, sales_orders so, sales_order_items soi set ms.issue_status="1"' + conditions;
		msg = "Issue Status flags have been set to 'Active'";
		if (params.pubType == 'magazine') {
			if (params.format == 'print') {
				cutoffAlert = (global.settings[S_CUT_OFF_PERIOD] == 1);
			}
			else {
				cutoffAlert = (global.settings[S_CUT_OFF_PERIOD_D] == 1);
			}
		}
		else {			// journal
			cutoffAlert = (global.settings[S_CUT_OFF_PERIOD_J] == 1);
		}
	}

	if (cutoffAlert) {
		if (params.harvestType == 'main')
			cb_alert('Cannot increment the issue number until the cut-off period.');
		else
			cb_alert('Cannot automatically set the Issue Status to "Active" during the cut-off period. Increase the first/last issue by one to start these subscriptions with the next issue in the main harvest, change their status to Active and send welcome or gift welcome letters.');
	}
	else {	
		confirmBox("ATTENTION", prompt, ["No", "Yes"], [ 
			function() {}, 	// no
			function() { 		// yes		
				execSQL(updateSQL, function(data) {
					cb_alert(msg);
					updateHarvestLog('update', params);					
					log('PUBLICATIONS HARVEST', params.harvestType + ', ' + params.pubType + ', ' + params.renewalType + ', ' + params.format + ' (' + params.issueNumber + ')');
				});			
			} 
		]);
	}
}

function updateHarvestLog(mode, params) {
//console.log(params)
	if (params.qty.bulk)
		qty = 'bulk';
	if (params.qty.single)
		qty = 'single';
	if (params.qty.bulk && params.qty.single)
		qty = 'both';
	
	if (mode == 'add') {
		var sql = 'insert into harvest_log set' +
						' type="' + params.harvestType + '",' +
						' publication="' + params.pubType + '",' +
						' renewal="' + params.renewalType + '",' +
						' format="' + params.format + '",' +
						' qty="' + qty + '",' +
						' issue="' + params.issueNumber + '"';
	}
	else {
		var sql = 'update harvest_log set completed=1 where' +
						' type="' + params.harvestType + '"' +
						' and publication="' + params.pubType + '"' +
						' and renewal="' + params.renewalType + '"' +
						' and format="' + params.format + '"' +
						' and qty="' + qty + '"' +
						' and issue="' + params.issueNumber + '"';		
	}
	execSQL(sql, function() {
		checkHarvestLog();		// update the notification bar
	});
}

function setIssueNumber(field, setting) {
	getData('getSettings', '', function(settings) {
		$("#" + field).val(settings[setting]);
	});
}

function execReport(number, p1, p2) {

	switch(number) {	
		case 1: {		// PN mailing list
			var d1 = document.getElementById('r1-start-date').value;
			var d2 = document.getElementById('r1-end-date').value;			
			
			if (global.isUK)
				var firstName = 'concat(salutation," ",left(first_name,1))';
			else
				var firstName = 'concat(salutation," ",first_name)';

			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			b.preQuery = 'create temporary table report (index(fname)) ENGINE=MyISAM' +
									' (select ' + firstName + ' as fname,last_name,organization,address,address_2,city,province,country,postal_code,c.id as c_id' +
									' from sales_orders so, customers c' +
									' where so.customer_id=c.id' +
									' and c.prayer_news=0' +
									' and c.no_mail=0' +											
									' and so.source!="MSACCESS"' +		// CA-exclude data migrated from access as it's too recently date stamped
									' and upper(left(so.notes,5))!="GIVER"' +		// UK-exclude data migrated from access as it's too recently date stamped
									' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '"' +
									' group by so.customer_id)' +
									' union all' +
									' (select concat(salutation," ",first_name) as fname,last_name,organization,address,address_2,city,province,country,postal_code,c.id as c_id' +
									' from customers c where c.friend_of_cmi=1 and c.no_mail=0 and c.prayer_news=0)';

			b.query = 'select * from report';
			b.sortColumn = 'postal_code';
			b.groupBy = 'c_id';
			
			if (global.isUK) {	// include customer ID
				b.columns = ['fname','last_name','organization','address','address_2','city', 'province', 'country', 'postal_code','c_id'];
				b.colClass = ['r1-col-1','r1-col-2','r1-col-3','r1-col-4','r1-col-4','r1-col-5','r1-col-6','r1-col-7','r1-col-8','r1-col-9'];
				b.colHeadings = ['First name','Last name','Organization','Address','Address 2','City','PRV','CTRY','PC','ID'];
			}
			else {
				b.columns = ['fname','last_name','organization','address','address_2','city', 'province', 'country', 'postal_code'];
				b.colClass = ['r1-col-1','r1-col-2','r1-col-3','r1-col-4','r1-col-4','r1-col-5','r1-col-6','r1-col-7','r1-col-8'];
				b.colHeadings = ['First name','Last name','Organization','Address','Address 2','City','PRV','CTRY','PC'];
			}
			b.colHeadClass = b.colClass;
			b.controls[1] = true;		// print btn
			b.printHeader = 'PRAYER NEWS MAILING LIST<hr>';
			b.init();		

			break;
		}
	
		case 2: {		// sub report
			var d1 = document.getElementById('r2-start-date').value;			
			var d2 = document.getElementById('r2-end-date').value;			
			var reportData = document.getElementById('report-results');
			
			var sql = "create temporary table report (index(od)) ENGINE=MyISAM (select concat(c.access_number,', ',c.salutation,' ',c.first_name,' ', c.last_name,', ',c.address,', ', c.city,', ',c.province,', ',c.postal_code, ', ', c.email1) donor, " +
							"concat(c2.access_number,', ',c2.salutation,' ',c2.first_name,' ',c2.last_name,', ', c2.address,', ',c2.city,', ',c2.province,', ',c2.postal_code, ', ', c2.email1) receiver, " +
							"concat(soi.title,' (x',ms.qty,')') title, substring(so.order_date,1,10) od " +
							"from mag_subs ms, sales_order_items soi, sales_orders so, customers c, customers c2" +
							" where soi.sales_order=so.id" +
							" and soi.mag_sub_id=ms.id" +
							" and ms.recipient_id=c2.id" +
							" and ms.recipient_id!=c.id" +
							" and so.customer_id=c.id" +
							" and soi.type='M'" +
							" and left(so.order_date,10)>='" + d1 + "' and left(so.order_date,10)<='" + d2 + "') " +
							"union all " +
							"(select concat(c.access_number,', ',c.salutation,' ',c.first_name,' ', c.last_name,', ',c.address,', ', c.city,', ',c.province,', ',c.postal_code, ', ', c.email1) donor, " +
							"'--self--' receiver, concat(soi.title,' (x',ms.qty,')') title, substring(so.order_date,1,10) od " +
							"from mag_subs ms, sales_order_items soi, sales_orders so, customers c" +
							" where soi.sales_order=so.id" +
							" and soi.mag_sub_id=ms.id" +
							" and ms.recipient_id=c.id" +
							" and so.customer_id=c.id" +
							" and soi.type='M'" +
							" and left(so.order_date,10)>='" + d1 + "' and left(so.order_date,10)<='" + d2 + "')";

			var b = new cb_browse('report-results');
			b.preQuery = sql;					
			b.query = 'select * from report';
			b.rowDepth = 10;
			b.controls[0] = false;	// too sluggish to allow search
			b.controls[1] = true;		// print btn
			b.printHeader = 'SUBSCRIPTION REPORT<hr>';
			b.sortColumn = 'od';
			b.columns = ['donor','od','receiver','title'];
			b.colClass = ['r2-col-1','r2-col-2','r2-col-3','r2-col-4'];
			b.colHeadings = ['Donor','Order date','Receiver','Subscription'];
			b.colHeadClass = ['r2-col-1','r2-col-2','r2-col-3','r2-col-4'];
			b.init();				

			break;
		}
		
		case 3: {		// update mailing list
			var d1 = document.getElementById('r3-start-date').value;
			var d2 = document.getElementById('r3-end-date').value;
			var donationLimit = document.getElementById('r3-donation-value').value;

			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			if (global.isUK) {
				b.preQuery = 'create temporary table report (index(fname)) ENGINE=MyISAM' +
										' (select concat(salutation," ",left(first_name,1)) as fname, last_name, organization, address, address_2, city, province, country,postal_code,sum(soi.price*soi.qty) as don_value, c.id as c_id' +
										' from sales_order_items soi, sales_orders so, customers c' +
										' where soi.type="D"' +
										' and soi.sales_order=so.id' +
										' and so.customer_id=c.id' +
										' and c.update_news=0' +
										' and c.no_mail=0' +											
										' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '"' +									
										' group by so.customer_id' +
										' having don_value>' + donationLimit + ')' +
										' union all' +
										' (select concat(salutation," ",left(first_name,1)) as fname, last_name, organization, address, address_2, city, province, country,postal_code, 0 as don_value, c.id as c_id' +
										' from customers c where c.friend_of_cmi=1 and c.no_mail=0 and c.update_news=0)';
				b.columns = ['fname', 'last_name', 'organization', 'address', 'address_2','city', 'province', 'postal_code','country','c_id'];
				b.colClass = ['r3-col-1','r3-col-2','r3-col-3','r3-col-4','r3-col-4','r3-col-5','r3-col-6','r3-col-7','r3-col-8','r3-col-9'];
				b.colHeadings = ['First name','Last name','Organization','Address','Address 2','City','PRV','PC','CTRY','ID'];
			}
			else {
				b.preQuery = 'create temporary table report (index(fname)) ENGINE=MyISAM' +
										' (select concat(salutation," ",first_name) as fname,last_name,organization,address,address_2,city,province,country,postal_code,sum(soi.price*soi.qty) as don_value, c.id as c_id' +
										' from sales_order_items soi, sales_orders so, customers c' +
										' where soi.type="D"' +
										' and soi.sales_order=so.id' +
										' and so.customer_id=c.id' +
										' and c.update_news=0' +
										' and c.no_mail=0' +											
										' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '"' +									
										' group by so.customer_id' +
										' having don_value>' + donationLimit + ')';			
				b.columns = ['fname', 'last_name', 'organization', 'address', 'address_2','city', 'province', 'country', 'postal_code'];
				b.colClass = ['r3-col-1','r3-col-2','r3-col-3','r3-col-4','r3-col-4','r3-col-5','r3-col-6','r3-col-7','r3-col-8'];
				b.colHeadings = ['First name','Last name','Organization','Address','Address 2','City','PRV','CTRY','PC'];
			}
//console.log(b.preQuery)			
			b.query = 'select * from report';
			b.groupBy = 'c_id';
			b.sortColumn = 'postal_code';
			b.colHeadClass = b.colClass;
			b.controls[1] = true;		// print btn			
			b.printHeader = 'UPDATE NEWSLETTER MAILING LIST<hr>';			
			b.init();		
			
			break;
		}
				
		case 5: {		// sales by source
			var d1 = document.getElementById('r5-start-date').value;
			var d2 = document.getElementById('r5-end-date').value;
			var reportData = document.getElementById('report-results');

			var stmt = 'select source, count(*) as ct' +
							' from sales_orders' +
							' where left(order_date,10)>="' + d1 + '" and left(order_date,10)<="' + d2 + '"' +
							' group by source' +
							' order by ct desc';

				execSQL(stmt, function(data) { 
				reportData.innerHTML = '';
				for (var x in data) {
					reportData.innerHTML += '<div class="r5-col-1">' + data[x][0] + '</div>' + data[x][1] + '<br>';
				}
				reportData.innerHTML += '<br><br><span class="site-btn" onclick="window.print()">PRINT</span>';
			});				

			break;
		}
		
		case 6: {		// system log
			var d1 = document.getElementById('r6-start-date').value;
			var d2 = document.getElementById('r6-end-date').value;

			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			b.query = 'select * from log';
			b.where = 'left(log_date,10)>="' + d1 + '" and left(log_date,10)<="' + d2 + '"';
			b.sortColumn = 'log_date';
			b.sortReverse = true;
			b.controls[1] = true;		// print btn
			b.printHeader = 'SYSTEM LOG<hr>';
			b.columns = ['log_date','action','detail'];
			b.colClass = ['r6-col-1','r6-col-2','r6-col-3'];
			b.colHeadings = ['Date/Time','Action','Detail'];
			b.colHeadClass = ['r6-col-1','r6-col-2','r6-col-3'];	
			b.init();		
			
			break;
		}
		
		case 7: {		// recurring donations tax receipts
			var taxYear = $('#r7-tax-year').val();
			
			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM' +
					'(select concat(c.salutation, " ", c.first_name, " ", c.last_name) as name,' +
					' address, city, province, postal_code, sum(soi.qty * soi.price) as amount' +
					' from sales_order_items soi, sales_orders so, customers c, settings where' +
					' c.id=so.customer_id' +
					' and soi.sales_order=so.id' +
					' and soi.type="D"' +
					' and so.source=settings.donation_default_source' +
					' and left(so.order_date,4)="' + taxYear + '" group by c.id)';		
					
			b.query = 'select * from report';
			b.sortColumn = 'name';
			b.columns = ['name', 'address', 'city', 'province', 'postal_code', 'amount'];
			b.colClass = ['r7-col-1','r7-col-2','r7-col-3','r7-col-4','r7-col-5','r7-col-6'];
			b.colHeadings = ['Name','Address','City','PRV','PC', 'Amt'];
			b.colHeadClass = ['r7-col-1','r7-col-2','r7-col-3','r7-col-4','r7-col-5','r7-col-6'];
			b.controls[1] = true;		// print btn			
			b.printHeader = 'RECURRING DONATIONS - ' + taxYear + '<hr>';			
			b.init();					
			
			break;
		}

		case 8: {		// best sellers (product sales)
			var d1 = document.getElementById('r8-start-date').value;
			var d2 = document.getElementById('r8-end-date').value;
			var filter = '';
			
			switch (getRadioValue('r8-options')) {
				case 'book': {
					filter = 'left(sku,2)="10"';
					break;
				}
				case 'dvd': {
					filter = 'left(sku,2)="30"';
					break;
				}
				case 'magazine': {
					filter = 'soi.type="M"';
					break;
				}
				default: {
					filter = "1";
				}
			}
			
			var months = monthDiff(d1, d2) + 1;			
			var b = new cb_browse('report-results');
			
			b.rowDepth = 10;
			b.preQuery = 'create temporary table report (index(sku)) ENGINE=MyISAM' +
								'(select sku, title, sum(qty) as count, round(sum(qty)/"' + months + '",1) as rate from sales_order_items soi, sales_orders so' +
								' where soi.sales_order=so.id' +
								' and (soi.type="P" or soi.type="M")' +
								' and price > 0' +
								' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '"' +
								' and ' + filter +
								' group by sku)';

			b.query = 'select * from report';
			b.sortColumn = 'count';
			b.sortReverse = true;
			b.controls[1] = true;		// print btn
			b.printHeader = 'BEST SELLERS - between ' + d1 + ' and ' + d2+ '<hr>';
			b.columns = ['sku','title','count','rate'];
			b.colClass = ['r8-col-1','r8-col-2','r8-col-3','r8-col-4'];
			b.colHeadings = ['SKU','Title','Quantity','Monthly rate of sale (over ' + months+ ' months)'];
			b.colHeadClass = b.colClass;
			b.init();					
			
			break;
		}		
		
		case 9: { 		// renewal notices
			var issue = $('#r9-issue-num').val();			
			
			$('#report-results').html('');
			switch (getRadioValue('r9-options')) {
				case 'print': { var subTypeFilter = '(soi.sub_type="P" or soi.sub_type="B")'; var subType = "P"; break; }
				case 'digital': { var subTypeFilter = '(soi.sub_type="D")'; var subType = "D"; break; }
				case 'journal': { var subTypeFilter = '(soi.sub_type="J")'; var subType = "J"; break; }
			}

			if (p1 == 'G') {				
				var mr1000 = 112281;	// hard coding for UK ... this is not right but this is until S2 takes over (this is customer=1000, i.e. intl donor)
				switch (getRadioValue('r9-gift-options')) {
					case 'local-country': {
						if (global.isUK)
							var countryFilter = 'find_in_set(c.country, "' + global.settings[S_COUNTRIES] + '") > 0 and c.id<>' + mr1000;						
						else
							var countryFilter =	'c.country="' + global.settings[S_COUNTRY] + '"';
						break;
					}
					case 'intl': {
						if (global.isUK)
							var countryFilter = 'c.id=' + mr1000;		
						else
							var countryFilter =	'c.country<>"' + global.settings[S_COUNTRY] + '"';
						break;
					}				
					default: {
						var countryFilter = '1';
						break;
					}
				}
											
				var sql = 'select * from (select c.id as d_id, c.access_number as d_access_number, c.salutation as d_title,' +
								' if(concat(c.first_name, " ", c.last_name)=" ", c.organization, concat(c.first_name, " ", c.last_name)) as donor,' +	
								' c.address as d_address, c.address_2 as d_address_2,' +
								' c.city as d_city, c.province as d_province, c.postal_code as d_postal_code, c.country as d_country,' +
								' (select last_issue from mag_subs ms, sales_order_items soi where recipient_id=c.id and soi.mag_sub_id=ms.id and ' + subTypeFilter + 'order by last_issue desc limit 1) as d_expiry,' +
								' concat(c2.salutation, " ", c2.first_name, " ", c2.last_name, " ", c2.organization) as recipient,' +
								' c2.address as r_address, c2.address_2 as r_address_2,' +
								' c2.city as r_city, c2.province as r_province, c2.postal_code as r_postal_code, c2.country as r_country, c2.id as r_id, max(ms.last_issue) r_expiry' +
								' from sales_orders so, sales_order_items soi, mag_subs ms, customers c, customers c2' +
								' where ms.status=1' +
								' and c.no_mail=0' +											
								' and c.id=so.customer_id' +
								' and c2.id=ms.recipient_id' +
								' and so.id=soi.sales_order' +
								' and ms.id=soi.mag_sub_id' +
								' and ' + countryFilter +
								' and ' + subTypeFilter +
								' and ms.recipient_id!=so.customer_id group by c2.id) as temp_table' +		// a gift
								' where r_expiry="' + issue + '" order by d_id';				
								
				$('#r9-please-wait').show();
				$('#r9-go-btn').hide();
						
				execSQL(sql, function(data) { 
					if (data.length == 0) {
						cb_alert('There are no renewal notices due for this subscription issue.');
					}
					else {
						if (getRadioValue('r9-gift-media-options') == 'data')
							giftRenewalNoticesData(subType, issue, data); 
						else
							giftRenewalNoticesPrint(subType, issue, data); 
					}
					$('#r9-please-wait').hide();
					$('#r9-go-btn').show();
				});
			}
			else {		// renewals for self
				var b = new cb_browse('report-results');				
				
				if (subType == 'J') {		// columns to complement the Word mail merge doc
					b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM' +
										' (select c.id id, max(ms.last_issue) issue, concat(c.salutation, " ", c.first_name, " ", c.last_name) as name, c.address address1, c.address_2 address2, c.city town, c.province state, c.postal_code pcode, c.country country' +
										' from mag_subs ms, sales_orders so, sales_order_items soi, customers c' +
										' where ms.status=1' +
										' and c.no_mail=0' +											
										' and c.id=so.customer_id' +
										' and so.id=soi.sales_order' +
										' and ms.id=soi.mag_sub_id' +
										' and ' + subTypeFilter +
										' and ms.recipient_id=so.customer_id' +		// sub for self
										' group by recipient_id)';

					b.columns = ['id','issue','name','address1','address2','town','state','pcode','country'];
					b.colClass = ['r9-col-1','r9-col-2','r9-col-3','r9-col-4','r9-col-4','r9-col-5','r9-col-6','r9-col-7'];
					b.colHeadings = ['ID','Issue #','Name','Address','Address 2','City','Prv','P/Code','Country'];
					b.colHeadClass = b.colClass;					
				}
				else {		// cm magazine
					if (global.isUK) {
						b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM' +
											' (select c.id id, max(ms.last_issue) issue, concat(c.salutation, " ", left(c.first_name,1), " ", c.last_name) as name, c.organization, c.address, c.address_2, c.city, c.postal_code, c.country' +
											' from mag_subs ms, sales_orders so, sales_order_items soi, customers c' +
											' where ms.status=1' +
											' and c.no_mail=0' +											
											' and c.id=so.customer_id' +
											' and so.id=soi.sales_order' +
											' and ms.id=soi.mag_sub_id' +
											' and ' + subTypeFilter +
											' and ms.recipient_id=so.customer_id' +		// sub for self
											' group by recipient_id)';

						b.columns = ['id','issue','name','organization','address','address_2','city','postal_code','country'];
						b.colClass = ['r9-col-1','r9-col-2','r9-col-3','r9-col-4','r9-col-4','r9-col-4','r9-col-4','r9-col-4','r9-col-4'];
						b.colHeadings = ['ID','Issue #','Name','Organization','Address','Address 2','City','P/Code','Country'];
						b.colHeadClass = b.colClass;	
					}
					else {		// canada
						b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM' +
											' (select c.id id, max(ms.last_issue) issue, concat(c.salutation, " ", c.first_name, " ", c.last_name) as name, c.organization, c.address address, concat(c.city, ", ", c.province, ", ", c.postal_code) as address2' +
											' from mag_subs ms, sales_orders so, sales_order_items soi, customers c' +
											' where ms.status=1' +
											' and c.no_mail=0' +											
											' and c.id=so.customer_id' +
											' and so.id=soi.sales_order' +
											' and ms.id=soi.mag_sub_id' +
											' and ' + subTypeFilter +
											' and ms.recipient_id=so.customer_id' +		// sub for self
											' group by recipient_id)';

						b.columns = ['id','issue','name','organization','address','address2'];
						b.colClass = ['r9-col-1','r9-col-2','r9-col-3','r9-col-4','r9-col-4','r9-col-4'];
						b.colHeadings = ['ID','Issue #','Name','Organization','Address','City & Province'];
						b.colHeadClass = ['r9-col-1','r9-col-2','r9-col-3','r9-col-4','r9-col-4','r9-col-4'];					
					}
				}
				b.rowDepth = 10;
				b.sortColumn = 'name';
				b.query = 'select * from report';
				b.where = 'issue="' + issue + '"';
				b.controls[1] = true;		// print btn
				b.init();									
			}

			break;
		}		
		
		case 10: { 		// sales by payment type
			var d1 = document.getElementById('r10-start-date').value;
			var d2 = document.getElementById('r10-end-date').value;		
			var pType = document.getElementById('r10-payment-type').value;
			
			var b = new cb_browse('report-results');
			b.rowDepth = 10;
/*	CB - working canada query
			b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM' +
					' (select c.id, concat(c.first_name, " ", c.last_name, " ", c.organization) as name,' +
					' so.id as soid, left(so.order_date,10) as date, so.value as value' +
					' from sales_orders so, customers c where' +
					' c.id=so.customer_id' +
					' and so.payment_type="' + document.getElementById('r10-payment-type').value + '"' +
					' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '")';
*/
// for UK, multiple payment types
			b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM' +
								' (select c.id, concat(c.first_name, " ", c.last_name, " ", c.organization) as name,' +
								' so.id as soid, left(so.order_date,10) as date,' +
								' so.payment_amount_1 as value,' +
								' so.payment_info_1 as info' +
								' from sales_orders so, customers c' +
								' where c.id=so.customer_id' +
								' and so.payment_type_1="' + pType + '"' +
								' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '") union' + 					
								' (select c.id, concat(c.first_name, " ", c.last_name, " ", c.organization) as name,' +
								' so.id as soid, left(so.order_date,10) as date,' +
								' so.payment_amount_2 as value,' +
								' so.payment_info_2 as info' +
								' from sales_orders so, customers c' +
								' where c.id=so.customer_id' +
								' and so.payment_type_2="' + pType + '"' +
								' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '") union' +			
								' (select c.id, concat(c.first_name, " ", c.last_name, " ", c.organization) as name,' +
								' so.id as soid, left(so.order_date,10) as date,' +
								' so.payment_amount_3 as value,' +
								' so.payment_info_3 as info' +
								' from sales_orders so, customers c' +
								' where c.id=so.customer_id' +
								' and so.payment_type_3="' + pType + '"' +
								' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '") union' +			
								' (select c.id, concat(c.first_name, " ", c.last_name, " ", c.organization) as name,' +
								' so.id as soid, left(so.order_date,10) as date,' +
								' so.payment_amount_4 as value,' +
								' so.payment_info_4 as info' +
								' from sales_orders so, customers c' +
								' where c.id=so.customer_id' +
								' and so.payment_type_4="' + pType + '"' +
								' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '") union' +			
								' (select c.id, concat(c.first_name, " ", c.last_name, " ", c.organization) as name,' +
								' so.id as soid, left(so.order_date,10) as date,' +
								' so.payment_amount_5 as value,' +
								' so.payment_info_5 as info' +
								' from sales_orders so, customers c' +
								' where c.id=so.customer_id' +
								' and so.payment_type_5="' + pType + '"' +
								' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '") union' +			
								' (select c.id, concat(c.first_name, " ", c.last_name, " ", c.organization) as name,' +
								' so.id as soid, left(so.order_date,10) as date,' +
								' so.payment_amount_6 as value,' +
								' so.payment_info_6 as info' +
								' from sales_orders so, customers c' +
								' where c.id=so.customer_id' +
								' and so.payment_type_6="' + pType + '"' +
								' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '")';					
//console.log(b.preQuery)

			b.query = 'select * from report';
			b.sortColumn = 'soid';
			b.controls[1] = true;		// print btn
			b.printHeader = 'SALES BY PAYMENT TYPE=' + document.getElementById('r10-payment-type').value + ' - between ' + d1 + ' and ' + d2+ '<hr>';
			b.columns = ['id','name','soid','date','value','info'];
			b.colClass = ['r10-col-1','r10-col-2','r10-col-3','r10-col-4','r10-col-5'];
			b.colHeadings = ['ID','Name','SO#','Order date','Value','Info'];
			b.colHeadClass = b.colClass;
			b.totalColumn = 'value';
			b.init();									

			break;
		}		
		
		case 11: {		// dashboard
			var reportData = document.getElementById('report-results');
			var YTD = today();
			var year = YTD.substr(0,4);
			var lastYTD = year - 1 + YTD.substr(4);
			var prevYTD = year - 2 + YTD.substr(4);

			// subscriptions			
			var stmt = 'select' +
							' sum(case when ms.term="R" then ms.qty else 0 end) as recurring,' +
							' sum(case when ms.term=1 and soi.sub_type="P" then ms.qty else 0 end) as 1p,' +
							' sum(case when ms.term=2 and soi.sub_type="P" then ms.qty else 0 end) as 2p,' +
							' sum(case when ms.term=3 and soi.sub_type="P" then ms.qty else 0 end) as 3p,' +
							' sum(case when ms.term=1 and soi.sub_type="D" then ms.qty else 0 end) as 1d,' +
							' sum(case when ms.term=2 and soi.sub_type="D" then ms.qty else 0 end) as 2d,' +
							' sum(case when ms.term=3 and soi.sub_type="D" then ms.qty else 0 end) as 3d,' +
							' sum(case when ms.term=1 and soi.sub_type="B" then ms.qty else 0 end) as 1b,' +
							' sum(case when ms.term=2 and soi.sub_type="B" then ms.qty else 0 end) as 2b,' +
							' sum(case when ms.term=3 and soi.sub_type="B" then ms.qty else 0 end) as 3b,' +
							' sum(case when ms.term=1 and soi.sub_type="J" then ms.qty else 0 end) as 1j,' +
							' sum(case when ms.term=2 and soi.sub_type="J" then ms.qty else 0 end) as 2j,' +
							' sum(case when ms.term=3 and soi.sub_type="J" then ms.qty else 0 end) as 3j' +
							' from mag_subs ms, sales_order_items soi' +
							' where status=1' +		// 1=active
							' and soi.mag_sub_id=ms.id';
								
			execSQL(stmt, function(data) { 
				document.getElementById('dash-subs-recurring').innerHTML = data[0][0];
				document.getElementById('dash-subs-1yr-print').innerHTML = data[0][1];
				document.getElementById('dash-subs-2yr-print').innerHTML = data[0][2];
				document.getElementById('dash-subs-3yr-print').innerHTML = data[0][3];
				document.getElementById('dash-subs-1yr-digital').innerHTML = data[0][4];
				document.getElementById('dash-subs-2yr-digital').innerHTML = data[0][5];
				document.getElementById('dash-subs-3yr-digital').innerHTML = data[0][6];
				document.getElementById('dash-subs-1yr-both').innerHTML = data[0][7];
				document.getElementById('dash-subs-2yr-both').innerHTML = data[0][8];
				document.getElementById('dash-subs-3yr-both').innerHTML = data[0][9];
				document.getElementById('dash-subs-1yr-journal').innerHTML = data[0][10];
				document.getElementById('dash-subs-2yr-journal').innerHTML = data[0][11];
				document.getElementById('dash-subs-3yr-journal').innerHTML = data[0][12];
			});				

			// donations
			var stmt = 'select' +
							' sum(case when left(order_date,10)>="' + year + '-01-01" and left(order_date,10)<="' + YTD + '" then soi.qty*soi.price else 0 end) as ty,' +
							' sum(case when left(order_date,10)>="' + (year - 1) + '-01-01" and left(order_date,10)<="' + lastYTD + '" then soi.qty*soi.price else 0 end) as ly,' +
							' sum(case when left(order_date,10)>="' + (year - 2) + '-01-01" and left(order_date,10)<="' + prevYTD + '" then soi.qty*soi.price else 0 end) as py' +
							' from sales_orders so, sales_order_items soi' +
							' where soi.sales_order=so.id' +
							' and soi.type="D"';							

			execSQL(stmt, function(data) { 
				document.getElementById('dash-donations-ty').innerHTML = YTD.substr(0,4);
				document.getElementById('dash-donations-ly').innerHTML = lastYTD.substr(0,4);
				document.getElementById('dash-donations-py').innerHTML = prevYTD.substr(0,4);
				document.getElementById('dash-donations-1').innerHTML = xtFormatCurrency(data[0][0]);
				document.getElementById('dash-donations-2').innerHTML = xtFormatCurrency(data[0][1]);
				document.getElementById('dash-donations-3').innerHTML = xtFormatCurrency(data[0][2]);
			});				

			// sales by source - volume
			var stmt = 'select source' +
							', sum(case when left(order_date,10)>="' + year + '-01-01" and left(order_date,10)<="' + YTD + '" then 1 else 0 end) as ct1' +
							', sum(case when left(order_date,10)>="' + (year - 1) + '-01-01" and left(order_date,10)<="' + lastYTD + '" then 1 else 0 end) as ct2' +
							', sum(case when left(order_date,10)>="' + (year - 2) + '-01-01" and left(order_date,10)<="' + prevYTD + '" then 1 else 0 end) as ct3' +
							' from sales_orders' +
							' group by source' +
							' order by ct1 desc';

			execSQL(stmt, function(data) { 
				document.getElementById('dash-sales-ty').innerHTML = '<b>' + YTD.substr(0,4) + '</b>';
				document.getElementById('dash-sales-ly').innerHTML = '<b>' + lastYTD.substr(0,4) + '</b>';
				document.getElementById('dash-sales-py').innerHTML = '<b>' + prevYTD.substr(0,4) + '</b>';
				for (var x in data) {
					document.getElementById('dash-sales-1').innerHTML += data[x][0] + '<br>';
					document.getElementById('dash-sales-2').innerHTML += data[x][1] + '<br>';
					document.getElementById('dash-sales-3').innerHTML += data[x][2] + '<br>';
					document.getElementById('dash-sales-4').innerHTML += data[x][3] + '<br>';
				}
			});				

/*			CB not working at present!
			// sales by source - value
			var stmt = 'select sum(value) as value from sales_orders so, customers c' +
							' where so.customer_id=c.id' +
							' group by price_band' +
							' order by price_band';
console.log(stmt)
							
			execSQL(stmt, function(data) { 
//console.log('>',typeof(data[0]))
				document.getElementById('dash-sales-value-1').innerHTML = xtFormatCurrency(typeof(data[3] == 'undefined') ? 0 : data[3][0]) + '<br>';	// seminar
				document.getElementById('dash-sales-value-2').innerHTML = xtFormatCurrency(typeof(data[1] == 'undefined') ? 0 : data[1][0]) + '<br>';	// wholesale
				document.getElementById('dash-sales-value-3').innerHTML = xtFormatCurrency(Number(data[0][0]) + Number(typeof(data[2] == 'undefined') ? 0 : data[2][0])) + '<br>';		// standard + staff
			});				
*/
			// best sellers - books
			var stmt = 'select title, sum(qty) as ct' +
							' from sales_order_items soi, sales_orders so' +
							' where soi.sales_order=so.id' +
							' and type="P" and left(sku,2)="10"' +
							' and price>0' +
							' and so.order_date>="' + lastYTD + '" and so.order_date<="' + YTD + '"' +
							' group by sku' +
							' order by ct desc' +
							' limit 15';

			execSQL(stmt, function(data) { 
				for (var x in data) {
					document.getElementById('dash-bs-book-1').innerHTML += data[x][0] + '<br>';
					document.getElementById('dash-bs-book-2').innerHTML += data[x][1] + '<br>';
				}
			});				
			
			// best sellers - dvds
			var stmt = 'select title, sum(qty) as ct' +
							' from sales_order_items soi, sales_orders so' +
							' where soi.sales_order=so.id' +
							' and type="P" and left(sku,2)="30"' +
							' and price>0' +
							' and so.order_date>="' + lastYTD + '" and so.order_date<="' + YTD + '"' +
							' group by sku' +
							' order by ct desc' +
							' limit 15';

			execSQL(stmt, function(data) { 
				for (var x in data) {
					document.getElementById('dash-bs-dvd-1').innerHTML += data[x][0] + '<br>';
					document.getElementById('dash-bs-dvd-2').innerHTML += data[x][1] + '<br>';
				}
			});				

			break;
		}
		
		case 12: {		// mag subs harvest
			var params = getHarvestParams();
			var issueNum = $('#r12-issue-num').val();
			var harvestFilter = (params.harvestType == 'main') ? 'ms.issue_status="1"' : 'ms.issue_status<>"1"';
			var emailFilter = '1';
			
			if (global.isCA)
				var countryFilter = 'c.country="' + global.settings[S_COUNTRY]  + '"';
			else
				var countryFilter = 'find_in_set(c.country, "' + global.settings[S_COUNTRIES] + '") > 0';

			if (params.renewalType == 'both') {		// renewals AND non-renewals
				var lastIssueFilter = "last_issue>='" + issueNum + "'";
				var subDueFilter = 'subdue>="' + issueNum + '"';
			}
			else if (params.renewalType == 'yes') {		// renewals
				var lastIssueFilter = "last_issue='" + issueNum + "'";
				var subDueFilter = 'subdue="' + issueNum + '"';
			}
			else {						// non-renewals
				var lastIssueFilter = "last_issue>='" + issueNum + "'";
				var subDueFilter = 'subdue>"' + issueNum + '"';
			}
			
			if (params.pubType == 'journal') {
				var subTypeFilter = 'soi.sub_type="J"';
				var subTypeFilter2 = 'soi2.sub_type="J"';
			}
			else {
				if (params.format == 'print') {
					var subTypeFilter = '(soi.sub_type="P" || soi.sub_type="B")';
					var subTypeFilter2 = '(soi2.sub_type="P" or soi2.sub_type="B")';
				}
				else {
					var subTypeFilter = '(soi.sub_type="D" || soi.sub_type="B")';
					var subTypeFilter2 = '(soi2.sub_type="D" or soi2.sub_type="B")';
				}
			}
			
			if (params.qty.single && params.qty.bulk) {
				var qtyFilter = 'ms.qty>0';
//				typeQtyFilter += ' and ms.qty>0';
			}
			else if (params.qty.single) {
				var qtyFilter = 'ms.qty=1';
//				typeQtyFilter += ' and ms.qty=1';
			}
			else if (params.qty.bulk) {
				var qtyFilter = 'ms.qty>1';
//				typeQtyFilter += ' and ms.qty>1';
			}
			
			if (params.format == 'digital')
				emailFilter = 'ms.digi_email <> ""';

			var conditions = " where c.id=ms.recipient_id" +
								" and so.id=soi.sales_order" +
								" and ms.id=soi.mag_sub_id" +
								" and ms.status=1" +		// only active records
								" and soi.type='M'" +
								" and c.no_mail=0" +
								" and '" + issueNum + "'>=ms.first_issue" +
								" and " + countryFilter +
								" and " + qtyFilter +
								" and " + subTypeFilter + 
								" and " + emailFilter;
			
			var testConditions = conditions + ' and ms.issue_status<>"1"';
			conditions += " and " + harvestFilter;
			
			if (global.isUK)
				var fname = "concat(left(c.first_name, 1),' ',c.last_name)";		// initial only
			else
				var fname = "concat(c.first_name,' ',c.last_name)";

			var subDueLookup = '(select ms2.last_issue from mag_subs ms2, sales_order_items soi2 where ms2.recipient_id=ms.recipient_id and ms2.id=soi2.mag_sub_id and ' + subTypeFilter2 + ' and ms2.status=1 order by ms2.last_issue desc limit 1) as subdue,'
//typeQtyFilter = '1';
			
			var b = new cb_browse('report-results');
/*
			b.preQuery = 'create temporary table report (index(recipient)) ENGINE=MyISAM' +
								" select * from (select lpad(c.id,6,'0') as id, c.salutation, " + fname + " as recipient," +
								' if(c.organization <> "", c.organization, c.address) as address_line_1, ' + 
								' if(c.organization <> "", concat(c.address, " ", c.address_2), c.address_2) as address_line_2, ' + 
								' c.city, c.province, c.postal_code as post_code, c.country, "' + global.settings[S_SUBS_COUNTRY_CODE] + '" as country_code, ms.qty,' +
								' ms.issue_status as status,' +
								' (select ms2.last_issue from mag_subs ms2, sales_order_items soi2 where ms2.status=1 and ms2.recipient_id=c.id and soi2.mag_sub_id=ms2.id and ' + typeQtyFilter + ' order by ms2.last_issue desc limit 1) as subdue,' +
								' soi.sub_type, ms.digi_email, so.customer_id, ' +
								' (select concat(c2.first_name," ",c2.last_name) from customers c2 where c2.id=so.customer_id) as subdonor, c.access_number' +
								" from mag_subs ms, customers c, sales_orders so, sales_order_items soi" +
								conditions +
								" group by c.id) as temp_table where " + lastIssueFilter;
*/
			b.preQuery = 'create temporary table report (index(recipient)) ENGINE=MyISAM' +
								" select * from (select lpad(c.id,6,'0') as id, c.salutation, " + fname + " as recipient," +
								' if(c.organization <> "", c.organization, c.address) as address_line_1,' + 
								' if(c.organization <> "", concat(c.address, " ", c.address_2), c.address_2) as address_line_2,' + 
								' c.city, c.province, c.postal_code as post_code, c.country, "' + global.settings[S_SUBS_COUNTRY_CODE] + '" as country_code, ms.qty,' +
								' ms.issue_status as status,' +
								' ms.last_issue,' +
								subDueLookup +
								' soi.sub_type, ms.digi_email, so.customer_id, ' +
								' (select concat(c2.first_name," ",c2.last_name) from customers c2 where c2.id=so.customer_id) as subdonor, c.access_number' +
								" from mag_subs ms, customers c, sales_orders so, sales_order_items soi " +
								conditions + ' and ' + lastIssueFilter +
								") as temp_table";
//console.log(b.preQuery)			
			b.colHeadings = ['id','Title','Recipient','Address','Address 2','City','Prv','P.Code','Country','Ctry Code','Qty','Issue Status','Subtype','Email','Donor ID','Donor Name','Subdue'];
			b.columns = ['id','salutation','recipient','address_line_1','address_line_2','city','province','post_code','country','country_code','qty','status','sub_type','digi_email','customer_id','subdonor','last_issue','subdue'];
			b.colClass = ['r12-id','r12-title','r12-name','r12-address','r12-address-2','r12-city','r12-province','r12-postal-code','r12-country','r12-country-code','r12-qty','r12-issue-status','r12-sub-type','r12-email','r12-donor-id','r12-donor-name','r12-last-issue','hide'];
			b.colHeadClass = b.colClass;
			b.query = 'select * from report';
			b.where = subDueFilter;
			b.rowDepth = 10;
			b.controls[0] = true;		// search btn
			b.controls[1] = true;		// print btn
			b.sortColumn = 'recipient';		
	
			b.rowCallback = function(row, data, data2) { 
				// format subdue in old MSAccess way, e.g. 3940 not 39:4
				var subdue = $(".r12-last-issue").index();
				var newSubDue = formatSubDue(data[subdue]);	
				row.children[subdue].innerHTML = newSubDue;	
//console.log(data)
				data[subdue] = newSubDue;	
//				data[subdue] = 1234;	
//console.log(data)
			}
		
			b.init();				

			var sql = 'select recipient_id, concat(c.first_name, " ",c.last_name) as name from mag_subs ms, customers c, sales_orders so, sales_order_items soi' + testConditions;
			execSQL(sql, function(data) {
//console.log(data)
				var records = data.length;
				if (records > 0 && params.harvestType == 'main') {
					var msg = 'There is a mini harvest outstanding.<br><br>Complete a mini harvest to identify the ' + records + ' subscription records and increase the first/last issue by one to start the subscriptions with the next issue in the main harvest and send a welcome or gift welcome letter.'
					
					// show IDs and names of problem records
					msg += '<p>Mini-harvest customers:</p>';
					msg += '<table style="display: block; background-color: white; height: 120px; overflow-y: auto; border: 1px solid black">';
					for (var x in data) {
						msg += '<tr>';
							msg += '<td>';
								msg += data[x].recipient_id;
							msg += '</td>';
							msg += '<td>';
								msg += data[x].name;
							msg += '</td>';
						msg += '</tr>';
					}
					msg += '</table>';
					
					cb_alert(msg);
				}
				else {
					updateHarvestLog('add', params);
					confirmHarvest(params, conditions);
				}
			});

			break;
		}
				
		case 13: {		// inventory re-order
			var d1 = document.getElementById('r13-start-date').value;
			var d2 = document.getElementById('r13-end-date').value;		
			var months = monthDiff(d1, d2) + 1;	
			var startMonth = Number(d1.substr(5,2));
			var startYear = Number(d1.substr(0,4));
			var b = new cb_browse('report-results');
			b.rowDepth = 10;						
			b.columns = ['soi_sku','soi_title','first_sale'];
			b.colClass = ['r13-1','r13-2'];
			b.colHeadings = ['SKU','Title','1st sale'];
			b.colHeadClass = ['r13-1','r13-2'];

			var sql = '';
			var month = startMonth;
			var year = startYear;
			var qtyFilter;
			var dayFilter;
			
			for (var x=0; x<months; x++) {
				if (month>12) {
					month = 1;
					year++;
				}
				var colName = 'm' + strZero(month,2) + year;			
				if (document.getElementById('r13-free').checked)
					qtyFilter = 'soi.qty';
				else
					qtyFilter = 'if(soi.price>0,soi.qty,0)';			

				if (months == 1)
					dayFilter = 'left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '"';
				else if (x == 0)
					dayFilter = 'left(so.order_date,10)>="' + d1 + '" and month(so.order_date)=' + month + ' and year(so.order_date)=' + year;
				else if (x == months-1)
					dayFilter = 'left(so.order_date,10)<="' + d2 + '" and month(so.order_date)=' + month + ' and year(so.order_date)=' + year;
				else
					dayFilter = 'month(so.order_date)=' + month + ' and year(so.order_date)=' + year;

				sql += 'sum(if(' + dayFilter + ',' + qtyFilter + ',0)) as ' + colName + ',';
				b.columns.push(colName);
				b.colClass.push('r13-4');		
				b.colHeadings.push(global.months[month-1]);
				b.colHeadClass.push('r13-4');
				month++;
			}
			
			var xlFilter = '(left(soi.sku,2)!="80")';			
			if (document.getElementById('r13-translations').checked)
				xlFilter = '1';

			var magFilter = '(soi.type="P")';
			if (document.getElementById('r13-mags').checked)
				magFilter = '(soi.type="P" or soi.type="M")';		
			
		/*	b.preQuery = 'create temporary table report (index(soi_sku)) ENGINE=MyISAM' +
									'(select * from (select soi.sku as soi_sku, soi.title as soi_title,' +
									sql +
									' (select left(so2.order_date,10) from sales_orders so2, sales_order_items soi2 where soi2.sales_order=so2.id and soi2.sku=soi.sku order by so2.order_date limit 1) as first_sale' +
									' from sales_order_items soi, sales_orders so' +
									' where soi.sales_order=so.id and ' + xlFilter + ' and ' + magFilter +
									'' +
									' group by soi.sku) as months)';*/
									
			b.preQuery = 'create temporary table report (index(soi_sku)) ENGINE=MyISAM' +
									'(select * from (select soi.sku as soi_sku, (select title from products where sku=soi.sku) as soi_title,' +
									sql +
									' (select left(so2.order_date,10) from sales_orders so2, sales_order_items soi2 where soi2.sales_order=so2.id and soi2.sku=soi.sku order by so2.order_date limit 1) as first_sale' +
									' from sales_order_items soi, sales_orders so' +
									' where soi.sales_order=so.id and ' + xlFilter + ' and ' + magFilter +
									'' +
									' group by soi.sku) as months)';
//console.log(b.preQuery)

			b.query = 'select * from report';
			b.sortColumn = 'soi_sku';
			b.sortColumn = 'first_sale';
			b.sortReverse = true;
			b.controls[1] = true;		// print btn
			b.printHeader = 'INVENTORY RE-ORDER - based on sales between ' + d1 + ' and ' + d2+ '<hr>';			
			b.init();					
			
			break;
		}				
		
		case 14: { 		// donor report
			var d1 = document.getElementById('r14-start-date').value;
			var d2 = document.getElementById('r14-end-date').value;		
			var amountFrom = $('#r14-donation-amount-from').val();		
			var amountTo = $('#r14-donation-amount-to').val();		
			var province = $('#r14-province').val();
			
//			var cccFilter = document.getElementById('r14-courtesy-call-complete').checked ? 1 : 0;
			var cccFilter = '1';
			switch (getRadioValue('r14-ccc')) {
				case 'yes': { cccFilter = 'c.courtesy_call_complete=1'; break; }
				case 'no': { cccFilter = 'c.courtesy_call_complete=0'; break; }
			}
			
			var followUpFilter = '1';
			switch (getRadioValue('r14-follow-up')) {
				case 'yes': { followUpFilter = 'c.follow_up_required=1'; break; }
				case 'no': { followUpFilter = 'c.follow_up_required=0'; break; }
			}
//console.log(bob)
			var provinceFilter = (province == '-All-') ? '1' : 'province="' + province + '"';
			
			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM' +
					' (select c.id as c_id, concat(c.first_name, " ", c.last_name, " ", c.organization) as name,' +
					' city, province, phone1, sum(price*qty) as donation_amt, max(left(so.order_date, 10)) as last_don_date,' +
					' address, address_2, country, postal_code' +
					' from sales_order_items soi, sales_orders so, customers c where' +
					' so.id=soi.sales_order' +
					' and c.id=so.customer_id' +
					' and soi.type="D"' +
					' and ' + cccFilter +
					' and ' + followUpFilter +
					' and ' + provinceFilter +
					' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '"' +
					' group by c.id)';					
//console.log(b.preQuery)					

			b.query = 'select * from report';
			b.where = 'donation_amt >= ' + amountFrom + ' and donation_amt <= ' + amountTo;
//			b.sortColumn = 'last_don_date';
//			b.sortReverse = false;
//console.log(activeBrowse.sortColumn)
			b.sortColumn = (activeBrowse.sortColumn == undefined) ? 'last_don_date' : activeBrowse.sortColumn;
			b.sortReverse = (activeBrowse.sortReverse == undefined) ? false : activeBrowse.sortReverse;
			b.controls[1] = true;		// print btn
			b.printHeader = 'DONORS - between ' + d1 + ' and ' + d2+ '<hr>';
			b.columns = ['c_id','name','city','province','phone1','donation_amt','last_don_date', 'address', 'address_2', 'country', 'postal_code'];
			b.colClass = ['hide','r14-col-1','r14-col-2','r14-col-3','r14-col-4','r14-col-5','r14-col-6','hide','hide','hide','hide'];
			b.colHeadings = ['','Name','City','PRV','Phone','Total Donations','Last Donation Date','','','',''];
			b.colHeadClass = b.colClass;
			
			b.fetch = function(data) {
				var custID = data[0];
				window.open('customer-form.html?customer=' + custID);
			}
			
			b.init();
			activeBrowse = b;			
			$('#r14-label-btn').show();
			$('#r14-label-text').show();
			$('#r14-label-text').select();

			break;
		}		

		case '14L': {
			for (var x in activeBrowse.data) {
				var label = {
					name: activeBrowse.data[x][1],
					address: activeBrowse.data[x][7],
					address_2: activeBrowse.data[x][8],
					cpp: activeBrowse.data[x][2] + ', ' + activeBrowse.data[x][3] + ', ' + activeBrowse.data[x][10]
				}
//console.log(label, activeBrowse.data[x][0])

//console.log(sql)				
				if (printLabel('m', label)) {
					var note = formatDate(today(), 2) + ' ' + oLogin.uid + '\n' + $('#r14-label-text').val() + '\n\n';
					var sql = 'update customers set courtesy_call_complete=1, notes=concat("' + note + '", notes) where id=' + activeBrowse.data[x][0];
					execSQL(sql, function() {					
					});
				}
				else
					break;
			}
			break;
		}

		case 15: { 		// daily sales summary (2016)
			var option = getRadioValue('r15-options');
			var filter = document.getElementById('r15-payment-type').value;
			
			dailySalesExtract2016(option, filter); 
			break; 
		}
				
		case 17: {	// UK income analysis a.k.a. LIAR report
			var d1 = document.getElementById('r17-start-date').value;
			var d2 = document.getElementById('r17-end-date').value;		
			var pType = $('#r17-payment-type').val();
			var donTypes;
			var r17_DONATION_COUNT;

// CB - need to walk thru all 6 payment types
var paymentTypeFilter = ' and so.payment_type="' + pType + '"';

//var d1 = '2017-01-02';
//var d2 = '2017-01-06';
			// get distinct number and name of donation types (so can build appropriate report columns)
			var sql = 'select distinct soi.sku, soi.sub_type' +
						' from sales_orders so, sales_order_items soi' +
						' where so.id=soi.sales_order' +
						' and type="D"' +
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '"' +
						paymentTypeFilter;
				
			execSQL(sql, function(data) {
				donTypes = [];
				r17_DONATION_COUNT = data.length-1;				
				r17_PAYMENT_DATE = 0;
				r17_SO_NUMBER = 1;
				r17_NAME = 2;
				r17_CM = 3;
				r17_CM_DIGITAL = 4;
				r17_CM_DIGITAL_EU = 5;
				r17_JOC = 6;
				r17_DONATION = 7;
				r17_BOOK = r17_DONATION_COUNT + 8;
				r17_NON_BOOK = r17_DONATION_COUNT + 9;
				r17_DVD_EXPORT = r17_DONATION_COUNT + 10;
				r17_SHIPPING_BOOK = r17_DONATION_COUNT + 11;
				r17_SHIPPING_NON_BOOK = r17_DONATION_COUNT + 12;
				r17_E_NON_BOOK = r17_DONATION_COUNT + 13;
				r17_E_NON_BOOK_EU = r17_DONATION_COUNT + 14;
				r17_E_BOOK = r17_DONATION_COUNT + 15;
				r17_E_BOOK_EU = r17_DONATION_COUNT + 16;
				r17_CUSTOM = r17_DONATION_COUNT + 17;
				r17_TOTAL = r17_DONATION_COUNT + 18;
				r17_SO_VALUE = r17_DONATION_COUNT + 19;
				
				for (var x in data) {
					donTypes[x] = [data[x].sku, data[x].sub_type];
				}

				var sql = 'select c.id as c_id, left(so.payment_date, 10) as date, so.id as so_id, so.value as so_value, soi.sku, soi.digital, soi.bom,' +
							' concat(c.last_name, ", ", c.first_name) as name, c.country, soi.id as soi_id, soi.type, soi.sub_type, soi.pack_value, ' +
							' soi.price, soi.qty, soi.shipping_calc, soi.gift_aid, sobi.price as sobi_price, sobi.qty as sobi_qty, sobi.sub_type as sobi_sub_type,' +
							' ifnull((select sum(soi2.price * soi2.qty) from sales_order_items soi2 where soi2.shipping_calc=1 and soi2.sales_order=so.id),0) as scv,' +
							' ifnull((select sum(soi3.price * soi3.qty) from sales_order_items soi3 where soi3.type="S" and soi3.sales_order=so.id),0) as sv' +
							' from customers c, sales_orders so, sales_order_items soi' +
							' left join sales_order_bom_items sobi on sobi.soi_id=soi.id' +						
							' where so.customer_id=c.id' +
							' and so.id=soi.sales_order' +
							' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '"' +
							paymentTypeFilter +
							' order by so.id';

				execSQL(sql, function(data) {
					var counter = 0;
					var colPrice;
					var b = new cb_browse('report-results');		
					
					if (data.length > 0) {
						var prevOrder = data[0].so_id;
						b.arrayData[counter] = new Array(r17_SO_VALUE);
						b.arrayData[counter].fill(0);
					}				
					
					for (var x in data) {
						if (data[x].so_id != prevOrder) {
							counter++;
							b.arrayData[counter] = new Array(r17_SO_VALUE);
							b.arrayData[counter].fill(0);
						}
						
						colPrice = r17setCol(data[x], donTypes);
						b.arrayData[counter][r17_PAYMENT_DATE] = data[x].date;
						b.arrayData[counter][r17_SO_NUMBER] = data[x].so_id;
						b.arrayData[counter][r17_NAME] = data[x].name;
						b.arrayData[counter][r17_SO_VALUE] = data[x].so_value;
						b.arrayData[counter][colPrice[0]] += (colPrice[1] * data[x].qty);

						if (data[x].scv == 0)	// avoid div by zero
							b.arrayData[counter][r17_SHIPPING_BOOK] = 0;
						else {
							var bookShipping = b.arrayData[counter][r17_BOOK] + b.arrayData[counter][r17_DVD_EXPORT];
							b.arrayData[counter][r17_SHIPPING_BOOK] = roundIt(bookShipping / data[x].scv * data[x].sv, 2);
						}
						b.arrayData[counter][r17_SHIPPING_NON_BOOK] = roundIt(data[x].sv - b.arrayData[counter][r17_SHIPPING_BOOK], 2);

						prevOrder = data[x].so_id;
					}

					// formatting and totals
					if (data.length > 0) {		
					
						b.arrayData[counter+1] = new Array(r17_SO_VALUE + 1);
						b.arrayData[counter+1].fill(0);		// init col totals		
						b.arrayData[counter+1][0] = '';				
						b.arrayData[counter+1][1] = '';				
						b.arrayData[counter+1][2] = 'Total';				
					
						// accumulate totals
						for (var x=0; x<=counter; x++) {
							fixRounding(b.arrayData[x]);
							b.arrayData[x][r17_TOTAL] = 0;	// init row total
							for (var y=r17_CM; y<r17_TOTAL; y++) {
								b.arrayData[x][r17_TOTAL] += b.arrayData[x][y];		// row total
								b.arrayData[counter+1][y] += b.arrayData[x][y];		// column total
							}
							b.arrayData[counter+1][r17_TOTAL] += b.arrayData[x][r17_TOTAL];			// grand total		
						}

						// formatting
						for (var x=0; x<=counter; x++) {
							for (var y=r17_CM; y<r17_TOTAL; y++) {
								b.arrayData[x][y] = formatCurrency(b.arrayData[x][y]);		// data cell
								b.arrayData[counter+1][y] = formatCurrency(b.arrayData[counter+1][y]);
							}
							b.arrayData[x][r17_TOTAL] = formatCurrency(b.arrayData[x][r17_TOTAL]);
						}
						b.arrayData[counter+1][r17_TOTAL] = formatCurrency(b.arrayData[counter+1][r17_TOTAL]);
					}

					b.columns = [];
					b.colClass = ['r17-col-1','r17-col-2','r17-col-3','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2','r17-col-2'];
					b.colHeadings = ['Pmt date','SO#','Name','CM','CM D','CM D Eu','JoC'];
					for (var x in donTypes) {		// dynamic number of donation types
						b.colHeadings.push(donTypes[x][0]);
						b.colClass.push('r17-col-2');
					}
					b.colClass.push('hide');	// s/order value
					var otherHeadings = ['Book','DVD','DVD Export','Post B','Post DVD','e-DVD','e-DVD EU','e-book','e-book EU','Custom','Total',''];
					for (var x in otherHeadings)
						b.colHeadings.push(otherHeadings[x]);
					b.colHeadClass = b.colClass;
					b.rowDepth = 0;
					b.height = 400;
					b.isArray = true;
					b.printHeader = '<p>INCOME ANALYSIS REPORT<br>Payment Type: ' + pType + ', from ' + d1 + ' to ' + d2 + '</p>';
					b.controls[1] = true;		// print btn
					b.init();				
//console.log(r17_SO_VALUE, b.data[0], b.colClass[18], b.colClass[19])					
				});
			
			});			
			
			break;
		}
		
		case 18: { 		// UK gift aid schedule
			var d1 = document.getElementById('r18-start-date').value;
			var d2 = document.getElementById('r18-end-date').value;		
//var d1 = '2016-08-30';
//var d2 = '2016-08-30';
			
			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			b.preQuery = 'create temporary table report (index(last_name)) ENGINE=MyISAM' +
					' (select substring_index(c.salutation, " ", 1) as salutation, substring_index(c.first_name, " ", 1) as first_name, c.last_name, c.address, c.postal_code, "" as blank1, "" as blank2, date_format(so.order_date,"%d/%m/%y") as donation_date, (soi.price*soi.qty) as donation' +
					' from sales_order_items soi, sales_orders so, customers c where' +
					' so.id=soi.sales_order' +
					' and c.id=so.customer_id' +
					' and soi.type="D"' +
					' and soi.gift_aid=1' +
					' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '")';
//console.log(b.preQuery)
//substring_index('name sub _blah',' ',1);
					
			b.query = 'select * from report';
			b.sortColumn = 'donation_date';
			b.totalColumn = 'donation';
			b.controls[1] = true;		// print btn
			b.printHeader = 'GIFT AID SCHEDULE - from ' + d1 + ' to ' + d2+ '<hr>';
			b.columns = ['salutation','first_name','last_name','address','postal_code','blank1','blank2','donation_date','donation'];
			b.colClass = ['r18-col-1','r18-col-2','r18-col-3','r18-col-3','r18-col-5','r18-col-1','r18-col-1','r18-col-3','r18-col-3'];
			b.colHeadings = ['Title','First name','Last name','Address','Postcode','Blank 1','Blank 2','Donation date','Amount'];
			b.colHeadClass = b.colClass;
			b.init();									

			break;
		}				

		case 19: { 		// UK VATMOSS return
			var d1 = document.getElementById('r19-start-date').value;
			var d2 = document.getElementById('r19-end-date').value;
		
//var d1 = '2016-05-23';
//var d2 = '2016-05-23';
			
			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			
			if (p1 == 'D') {	// detail
				b.preQuery = 'create temporary table report (index(country)) ENGINE=MyISAM' +
						' (select so.id as order_number, date_format(so.order_date,"%d/%m/%y") as order_date, concat(c.last_name, ", ", c.first_name) as name, c.country,' +
						' if(soi.digital=1,soi.price*soi.qty,sobi.price*soi.qty) as amount, ' +
						' (select category from products where sku=soi.sku) as category' +
						' from settings s, customers c, sales_orders so, sales_order_items soi' +
						' left join sales_order_bom_items sobi on sobi.soi_id=soi.id' +							
						' where so.id=soi.sales_order' +
						' and c.id=so.customer_id' +
						' and (soi.digital=1 or sobi.digital=1)' +
						' and find_in_set(c.country, s.eu_countries) > 0' +
						' and so.payment_type <> "' + oSettings.reports_exclude_payment_type + '"' +
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '")';
//console.log(b.preQuery)
						
				b.query = 'select * from report';
				b.sortColumn = 'order_number';
				b.controls[1] = true;		// print btn
				b.printHeader = 'VATMOSS RETURN - from ' + d1 + ' to ' + d2+ '<hr>';
				b.columns = ['order_number','order_date','name','country','amount','category'];
				b.colClass = ['r19-col-1','r19-col-1','r19-col-3','r19-col-3','r19-col-1',''];
				b.colHeadings = ['Order number','Order date','Name','Country','Amount','Category'];
				b.colHeadClass = b.colClass;
			}
			else {		// summary
				b.preQuery = 'create temporary table report (index(country)) ENGINE=MyISAM' +
						' (select c.country, sum(if(soi.digital=1,soi.price*soi.qty,sobi.price*soi.qty)) as amount' +
						' from settings s, customers c, sales_orders so, sales_order_items soi' +
						' left join sales_order_bom_items sobi on sobi.soi_id=soi.id' +							
						' where so.id=soi.sales_order' +
						' and c.id=so.customer_id' +
						' and (soi.digital=1 or sobi.digital=1)' +
						' and find_in_set(c.country, s.eu_countries) > 0' +
						' and so.payment_type <> "' + oSettings.reports_exclude_payment_type + '"' +						
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '"' +
						' group by c.country)';
//console.log(b.preQuery)
						
				b.query = 'select * from report';
				b.sortColumn = 'country';
				b.controls[1] = true;		// print btn
				b.printHeader = 'VATMOSS RETURN - from ' + d1 + ' to ' + d2+ '<hr>';
				b.columns = ['country','amount'];
				b.colClass = ['r19-col-3','r19-col-1'];
				b.colHeadings = ['Country','Amount'];
				b.colHeadClass = b.colClass;
			}
			b.init();									

			break;
		}				
		
		case 20: {	// payment receipts
			$('#report-20-print').show();
			var d1 = document.getElementById('r20-start-date').value;
			var d2 = document.getElementById('r20-end-date').value;		
			var pTypeFilter1 = ($('#r20-payment-type').val() == '') ? ' and 1' : ' and payment_type_1="' + $('#r20-payment-type').val() + '"';
			var pTypeFilter2 = ($('#r20-payment-type').val() == '') ? ' and 1' : ' and payment_type_2="' + $('#r20-payment-type').val() + '"';
			var pTypeFilter3 = ($('#r20-payment-type').val() == '') ? ' and 1' : ' and payment_type_3="' + $('#r20-payment-type').val() + '"';
			var pTypeFilter4 = ($('#r20-payment-type').val() == '') ? ' and 1' : ' and payment_type_4="' + $('#r20-payment-type').val() + '"';
			var pTypeFilter5 = ($('#r20-payment-type').val() == '') ? ' and 1' : ' and payment_type_5="' + $('#r20-payment-type').val() + '"';
			var pTypeFilter6 = ($('#r20-payment-type').val() == '') ? ' and 1' : ' and payment_type_6="' + $('#r20-payment-type').val() + '"';
//console.log(pTypeFilter)

//var d1 = '2016-05-26';
//var d2 = '2016-06-26';
//console.log(global.settings[S_REPORTS_EXCLUDE_PAYMENT_TYPE])

			var sql = '(select so.id, concat(c.first_name, " ", c.last_name) as name, so.payment_amount_1 as value, left(so.order_date,10) as order_date, so.payment_type_1 as payment_type, so.payment_info_1 as payment_info' +
						' from customers c, sales_orders so' +
						' where so.customer_id=c.id' +
						pTypeFilter1 +
						' and payment_type_1 <> ""' +
						' and payment_type_1 <> "' + global.settings[S_REPORTS_EXCLUDE_PAYMENT_TYPE] + '"' +
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '")' +
						' union ' +
						'(select so.id, concat(c.first_name, " ", c.last_name) as name, so.payment_amount_2 as value, left(so.order_date,10) as order_date, so.payment_type_2 as payment_type, so.payment_info_2 as payment_info' +
						' from customers c, sales_orders so' +
						' where so.customer_id=c.id' +
						pTypeFilter2 +
						' and payment_type_2 <> ""' +
						' and payment_type_2 <> "' + global.settings[S_REPORTS_EXCLUDE_PAYMENT_TYPE] + '"' +
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '")' +
						' union ' +
						'(select so.id, concat(c.first_name, " ", c.last_name) as name, so.payment_amount_3 as value, left(so.order_date,10) as order_date, so.payment_type_3 as payment_type, so.payment_info_3 as payment_info' +
						' from customers c, sales_orders so' +
						' where so.customer_id=c.id' +
						pTypeFilter3 +
						' and payment_type_3 <> ""' +
						' and payment_type_3 <> "' + global.settings[S_REPORTS_EXCLUDE_PAYMENT_TYPE] + '"' +
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '")' +
						' union ' +
						'(select so.id, concat(c.first_name, " ", c.last_name) as name, so.payment_amount_4 as value, left(so.order_date,10) as order_date, so.payment_type_4 as payment_type, so.payment_info_4 as payment_info' +
						' from customers c, sales_orders so' +
						' where so.customer_id=c.id' +
						pTypeFilter4 +
						' and payment_type_4 <> ""' +
						' and payment_type_4 <> "' + global.settings[S_REPORTS_EXCLUDE_PAYMENT_TYPE] + '"' +
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '")' +
						' union ' +
						'(select so.id, concat(c.first_name, " ", c.last_name) as name, so.payment_amount_5 as value, left(so.order_date,10) as order_date, so.payment_type_5 as payment_type, so.payment_info_5 as payment_info' +
						' from customers c, sales_orders so' +
						' where so.customer_id=c.id' +
						pTypeFilter5 +
						' and payment_type_5 <> ""' +
						' and payment_type_5 <> "' + global.settings[S_REPORTS_EXCLUDE_PAYMENT_TYPE] + '"' +
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '")' +
						' union ' +
						'(select so.id, concat(c.first_name, " ", c.last_name) as name, so.payment_amount_6 as value, left(so.order_date,10) as order_date, so.payment_type_6 as payment_type, so.payment_info_6 as payment_info' +
						' from customers c, sales_orders so' +
						' where so.customer_id=c.id' +
						pTypeFilter6 +
						' and payment_type_6 <> ""' +
						' and payment_type_6 <> "' + global.settings[S_REPORTS_EXCLUDE_PAYMENT_TYPE] + '"' +
						' and left(so.payment_date,10)>="' + d1 + '" and left(so.payment_date,10)<="' + d2 + '")' +
						' order by payment_type, id';
//console.log(sql)						

			execSQL(sql, function(data) {
				
				$('#report-20-count').html('There are ' + data.length + ' records matching your criteria');
				
				var reportData = document.getElementById('report-results');
				reportData.innerHTML = '<b>PAYMENT RECEIPTS</b>';
				var row = document.createElement('div');
				reportData.appendChild(row);
				row.innerHTML = '<b><div class="e-0">Sales Order</div>' +
											'<div class="e-1">Name</div>' +
											'<div class="e-2"></div>' +
											'<div class="e-3">Value</div>' +
											'<div class="e-4">Order Date</div>' +
											'Payment type</b>';
				var total = 0;
				var subTotal = 0;
				var prevType = '';
				for (var x in data) {
					if (prevType == '' || data[x].payment_type == prevType)
						subTotal += Number(data[x].value);
					else {	
						// show sub total for each (payment type + order date) combo
						var row = document.createElement('div');
						reportData.appendChild(row);
						row.innerHTML = '<div class="e-sub-total">' + formatCurrency(subTotal) + '</div>';	
						subTotal = Number(data[x].value);
					}

					var row = document.createElement('div');
					reportData.appendChild(row);
					row.innerHTML = '<div class="e-0">' + data[x].id+ '</div>' +
												'<div class="e-1">' + data[x].name+ '</div>' +
												'<div class="e-2"></div>' +
												'<div class="e-3">' + data[x].value+ '</div>' +
												'<div class="e-4">' + data[x].order_date + '</div>' +
												data[x].payment_type + ' ' + data[x].payment_info;
					
					total += Number(data[x].value);
					prevType = data[x].payment_type;
				}
				// final sub total
				var row = document.createElement('div');
				reportData.appendChild(row);
				row.innerHTML = '</div><div class="e-sub-total">' + formatCurrency(subTotal) + '</div>';	
				// grand total
				var row = document.createElement('div');
				reportData.appendChild(row);
				row.innerHTML = '<div class="e-total">TOTAL: ' + formatCurrency(total) + '</div>';	
			});
			break;
		}
		
		case 21: { 		// inventory levels and value
			$('#report-results').html('DNR=do not restock');
			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			b.preQuery = 'create temporary table report (index(sku)) ENGINE=MyISAM' +
					' (select sku, title, if(do_not_restock=1,"&#10004","") as dnr, qty, price, cost, (qty*cost) as value, round(if(cost=0,0,((price-cost)/cost*100)),1) as markup from products' +
					' where type="P"' +
					' and digital<>1' +
					' and status=1' +	// active only
					')';
//console.log(b.preQuery)
					
			b.query = 'select * from report';
			b.sortColumn = 'sku';
			b.controls[1] = true;		// print btn
			b.printHeader = 'INVENTORY LEVELS & VALUE<hr>';
			b.columns = ['sku','title','dnr','qty','price','cost','value','markup'];
			b.colClass = ['r21-col-1','r21-col-2','r21-col-2a','r21-col-3','r21-col-3','r21-col-3','r21-col-3'];
			b.colHeadings = ['SKU','Title','DNR','Qty','RRP','Cost','Value','Markup %'];
			b.colHeadClass = b.colClass;
			b.totalColumn = 'value';
			b.init();									

			break;
		}				

		case 22: {	// skus to customer
			var d1 = document.getElementById('r22-start-date').value;
			var d2 = document.getElementById('r22-end-date').value;		
			var sku = document.getElementById('r22-sku').value;		
			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			b.preQuery = 'create temporary table report (index(c_id)) ' +
					' (select c.id as c_id,  concat(c.first_name, " ", c.last_name) as name, so.id as so, left(so.order_date, 10) as so_date from sales_order_items soi, sales_orders so, customers c' +
					' where soi.sales_order=so.id' +
					' and so.customer_id=c.id' +
					' and soi.sku="' + sku + '"' +
					' and left(so.order_date,10)>="' + d1 + '" and left(so.order_date,10)<="' + d2 + '")';
//console.log(b.preQuery)
					
			b.query = 'select * from report';
			b.sortColumn = 'c_id';
			b.controls[1] = true;		// print btn
			b.printHeader = 'SKUs TO CUSTOMER<hr>';
			b.columns = ['c_id', 'name', 'so', 'so_date'];
			b.colClass = ['r22-col-1','r22-col-2','r22-col-3'];
			b.colHeadings = ['Customer ID', 'Name', 'Sales Order ID', 'S/O Date'];
			b.colHeadClass = b.colClass;
			b.init();									

			break;			
		}
		
		case 23: {	// standing order donors | friends of cmi (uk)
			var option = getRadioValue('r23-options');
			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			var optionSO ='(select c.id as c_id, first_name, c.last_name, c.address, c.address_2, c.city, c.postal_code, c.country, d.amount from donations d, customers c where c.id=d.customer_id)';
			var optionFriend =	'(select c.id as c_id, first_name, c.last_name, c.address, c.address_2, c.city, c.postal_code, c.country, 0 as amount from customers c where c.friend_of_cmi=1)'
					
			switch (option) {
				case 'both': {
					b.preQuery = 'create temporary table report (index(c_id)) ' + optionSO + ' union all ' + optionFriend;
					break;
				}
				case 'so': {
					b.preQuery = 'create temporary table report (index(c_id)) ' + optionSO;
					break;
				}
				case 'friends': {
					b.preQuery = 'create temporary table report (index(c_id)) ' + optionFriend;
					break;
				}
			}
//console.log(b.preQuery)
					
			b.query = 'select * from report';
			b.sortColumn = 'c_id';
			b.groupBy = 'c_id';
			b.controls[1] = true;		// print btn
			b.printHeader = 'STANDING ORDER DONORS | FRIENDS OF CMI<hr>';
			b.columns = ['c_id','first_name','last_name','address','address_2','city','postal_code','country','amount'];
			b.colClass = ['r23-col-1','r23-col-2','r23-col-3','r23-col-4','r23-col-5','r23-col-6','r23-col-7','r23-col-8'];
			b.colHeadings = ['Customer ID','First name','Last name','Address 1','Address 2','City','P/Code','Country','Amount'];
			b.colHeadClass = b.colClass;
			
			b.fetch = function(data) {
				var sql = 'select * from customers where id=' + data[0];
				execSQL(sql, function(customerData) {
					customerData[0].name = customerData[0].first_name + ' ' + customerData[0].last_name;
//console.log(customerData[0]);
//					doBob(customerData[0]);
					printLabel('m', customerData[0]);					
				});
			}
			
			b.init();
			r23labels = b;

			break;			
		}

		case '23L': {
			for (var x in r23labels.data) {
				var label = {
					name: r23labels.data[x][1] + ' ' + r23labels.data[x][2],
					address: r23labels.data[x][3],
					address_2: r23labels.data[x][4],
					city: r23labels.data[x][5],
					postal_code: r23labels.data[x][6],
					country: r23labels.data[x][7]
				}
				printLabel('m', label);				
			}
			break;
		}
		
		case 24: {	// deferred revenue (ca only)
			var issueNumber = $('#r24-issue-number').val();
			var subType = $('#r24-sub-type').val();
			if (subType == 'all')
				subTypeFilter = '1'
			else
				subTypeFilter = 'soi.sub_type="' + subType + '"';

			var b = new cb_browse('report-results');
			b.rowDepth = 10;
			var sql ='select so.customer_id, left(so.order_date, 10) as purchase_date, ms.first_issue, ms.last_issue, "" as num_issues, "" as issues_owing, soi.sub_type, ms.term, ms.qty, ms.id as ms_id from mag_subs ms, sales_order_items soi, sales_orders so' +
						' where soi.mag_sub_id=ms.id and soi.sales_order=so.id' +
						' and ms.status=1' +
						' and ' + subTypeFilter +
						' and "' + issueNumber + '">=ms.first_issue' +
						' and ms.last_issue>="' + issueNumber + '"';

			b.preQuery = 'create temporary table report (index(ms_id)) ' + sql;
			b.query = 'select * from report';
			b.sortColumn = 'ms_id';
			b.rowDepth = 0;			
			b.height = 400;			
			b.controls[1] = true;		// print btn
			b.printHeader = 'DEFERRED REVENUE - Issue #: ' + issueNumber + '<hr>';
			b.columns = ['ms_id','customer_id','purchase_date','first_issue','last_issue','num_issues','issues_owing','qty','sub_type','term'];
			b.colClass = ['r24-col-1','r24-col-2','r24-col-3','r24-col-4','r24-col-5','r24-col-6','r24-col-7','r24-col-8','r24-col-9'];
			b.colHeadings = ['Sub ID','Customer ID','Purchase Date','First issue','Last issue','Total issues','Number of issues owing','Qty','Type','Term'];
			b.colHeadClass = b.colClass;		
					
			b.rowCallback = function(row, data) { 
				var start = row.children[3].innerHTML;
				var end = row.children[4].innerHTML;
				var numIssues = getNumIssues(start, end, subType);
				row.children[5].innerHTML = numIssues;
				data[5] = numIssues;
				
				var term = row.children[9].innerHTML;

				if (term == 'R')
					var issuesOwing = 1;
				else
					var issuesOwing = getNumIssues(issueNumber, end, subType);
				
				row.children[6].innerHTML = issuesOwing;
				data[6] = issuesOwing;
			}
			
			b.init();
			break;			
		}
	}
	
	$('#report-results').show();	
}

var r17_PAYMENT_DATE;
var r17_SO_NUMBER;
var r17_NAME;
var r17_CM;
var r17_CM_DIGITAL;
var r17_CM_DIGITAL_EU;
var r17_JOC;
var r17_DONATION;
var r17_BOOK;
var r17_NON_BOOK;
var r17_DVD_EXPORT;
var r17_SHIPPING_BOOK;
var r17_SHIPPING_NON_BOOK;
var r17_E_NON_BOOK;
var r17_E_NON_BOOK_EU;
var r17_E_BOOK;
var r17_E_BOOK_EU;
var r17_CUSTOM;
var r17_TOTAL;
var r17_SO_VALUE;
						
function r17setCol(data, donTypes) {
	var col;
	var price = data.price;
//console.log(price)
	var isEU = (global.settings[S_EU_COUNTRIES].indexOf(data.country) >= 0);

	switch(data.type) {
		case 'M': { 	// magazine
			if (data.sub_type == 'J')	// journal
				col = r17_JOC; 
			else if (data.bom == 1) {	// a BOM item
//				price = data.sobi_price / data.pack_value * data.price;
				price = (data.sobi_price * data.sobi_qty) / data.pack_value * data.price;
				if (isEU)		
					col = (data.sobi_sub_type == 'P') ? r17_CM : r17_CM_DIGITAL_EU;
				else
					col = (data.sobi_sub_type == 'P') ? r17_CM : r17_CM_DIGITAL;
			}				
			else if (data.sub_type == 'D') {	// digital
				if (isEU)		
					col = r17_CM_DIGITAL_EU;		// an EU country
				else
					col = r17_CM_DIGITAL; 		// not an EU country
			}
			else
				col = r17_CM; 		// print magazine

			break;
		}
		case 'D': {	// donation
			var pos = findInArray(donTypes, 1, data.sub_type);
			col = r17_DONATION + pos; 
			break;
		}	
		case 'P': {	// product
			if (data.bom == 1) {	// a BOM item
				//price = data.sobi_price / data.pack_value * data.price;
				price = (data.sobi_price * data.sobi_qty) / data.pack_value * data.price;
//console.log(price, data.sobi_price, data.pack_value, data.price)
				if (isEU || data.country.toUpperCase() == global.settings[S_COUNTRY].toUpperCase())
					col = (data.sobi_sub_type == 'B') ? r17_BOOK : r17_NON_BOOK;
				else
					col = (data.sobi_sub_type == 'B') ? r17_BOOK : r17_DVD_EXPORT;
			}
			else {	
				if (data.digital == 1) {
					if (isEU)
						col = (data.sub_type == 'B') ? r17_E_BOOK_EU : r17_E_NON_BOOK_EU;
					else
						col = (data.sub_type == 'B') ? r17_E_BOOK : r17_E_NON_BOOK;
				}
				else {
					if (isEU || data.country.toUpperCase() == global.settings[S_COUNTRY].toUpperCase())
						col = (data.sub_type == 'B') ? r17_BOOK : r17_NON_BOOK;
					else
						col = (data.sub_type == 'B') ? r17_BOOK : r17_DVD_EXPORT;
				}
			}
			break;
		}
		case 'S': { col = r17_CUSTOM; price = 0; break; }
		default: {
			col = r17_CUSTOM;
		}
	}
	
	return [col, price, 2];
}

/* 	have to 'fix' the calculated data due to rounding errors. 
	need to make the row for each s/order (report #17) add up to the s/order value by knocking on/off pennies to the first cell with data
*/
function fixRounding(data) {
	// first get row total complete with rounding errors 
	var total = 0;
	var target = Number(data[r17_SO_VALUE]);	// this is the value to regard as 'real'
	for (var x=3; x<r17_TOTAL; x++)
		total += Number(data[x]);
	total = roundIt(total, 2);

	// now go willy-nilly adjust the book column
	var diff = total-target;
	if (diff != 0) {
		data[r17_BOOK] -= diff;
	}
}

function printReport20() {
	window.print();
}

// gift renewal notices - data extract
function giftRenewalNoticesData(subType, issueNumber, data) {
//console.log(data)

	var b = new cb_browse('report-results');
	b.rowDepth = 0;
	b.height = 400;
	b.columns = [];
	b.colClass = ['r9-gift-1','r9-gift-1','r9-gift-1','r9-gift-2','r9-gift-3','r9-gift-4','r9-gift-5','r9-gift-6','r9-gift-7','r9-gift-8','r9-gift-9'];
	b.colHeadings = ['Giver country','Giver ID (SOS)','Giver ID (Other)','Recip ID','Name','Address','Address 2','City','Province','PC','Country'];
	b.colHeadClass = b.colClass;
	b.isArray = true;
	b.controls[1] = true;		// print btn
	b.arrayData = [];
	
	for (var x in data) {
		b.arrayData[x] = [
			data[x].d_country, 
			data[x].d_id, 
			data[x].d_access_number, 
			data[x].r_id, 
			data[x].recipient, 
			data[x].r_address,
			data[x].r_address_2,
			data[x].r_city,
			data[x].r_province,
			data[x].r_postal_code,
			data[x].r_country
		];
	}
	b.init();
}

// gift renewal notices - print on plain paper
function giftRenewalNoticesPrint(subType, issueNumber, data) {
//console.log(data)
	getData('getSettings', '', function(settings) {
		
		var donorData = new Object();
		donorData.recipient = new Array();		
		var prevCust = 0;
		var y = 0;
		var notice = document.getElementById('renewal-notice-results');
		notice.innerHTML = '';
		if (global.isUK)		// the brits have smaller eyes
			notice.style.fontSize = '18px';
		$('#renewal-notice-results').show();
		
		for (var x in data) {
			if (prevCust != data[x].d_id && prevCust != 0) {
				printNotice(subType, notice, issueNumber, settings, donorData);
				donorData.recipient = new Array();
				y = 0;
			}

			donorData.name = data[x].donor; 
			donorData.title = data[x].d_title; 
			donorData.address_1 = data[x].d_address;
			donorData.address_2 = data[x].d_address_2;
			donorData.city = data[x].d_city; 
			donorData.province = data[x].d_province;
			donorData.postal_code = data[x].d_postal_code;
			donorData.country = data[x].d_country;
			donorData.id = data[x].d_id;

			donorData.recipient[y] = { 
				'name': data[x].recipient, 
				'address_1': data[x].r_address, 
				'address_2': data[x].r_address_2, 
				'city': data[x].r_city, 
				'province': data[x].r_province, 
				'postal_code': data[x].r_postal_code, 
				'expiry': data[x].r_expiry, 
				'id': data[x].r_id 
			};
//console.log(donorData)

			y++;
			prevCust = data[x].d_id;
		}

		printNotice(subType, notice, issueNumber, settings, donorData);
	
		$('.page-container').hide();
		window.print();
		$('.page-container').show();
		$('#renewal-notice-results').hide();
	});
}

function printNotice(subType, notice, issueNumber, settings, donorData) {
//console.log(donorData)
	var el = document.createElement('div');
	notice.appendChild(el);
	el.className = 'page-break';
	
	// date + customer #
	var el = document.createElement('div');
	notice.appendChild(el);
	el.className = 'r9-date';
	el.innerHTML = '<b>GIFT RENEWAL NOTICE</b><br>';
	el.innerHTML += 'Customer #' + donorData.id + '<br>';
	el.innerHTML += formatDate(today());

	el = document.createElement('img');
	notice.appendChild(el);
	el.className = 'r9-logo';
	el.src = 'images/logo-3.png';

	// office address
	el = document.createElement('div');
	notice.appendChild(el);
	el.className = 'r9-cmi-address';
	el.innerHTML = settings[S_CMI_ADDRESS_1] + '<br>';
	el.innerHTML += settings[S_CMI_ADDRESS_2] + '<br>';
	el.innerHTML += settings[S_CMI_ADDRESS_3] + '<br>';
	el.innerHTML += settings[S_CMI_ADDRESS_4] + '<br>';
	el.innerHTML += settings[S_CMI_ADDRESS_5] + '<br>';
	el.innerHTML += settings[S_CMI_ADDRESS_6];
	
	// price panel
	el = document.createElement('div');
	notice.appendChild(el);
	el.className = 'r9-price-panel';
	if (global.isUK)
		el.innerHTML = '<span style="font-size:larger;font-weight:bold">Gift Journal Price</span><br>';
	else
		el.innerHTML = '<span style="font-size:larger;font-weight:bold">Gift Subscription Prices</span><br>';
	
	if (subType == 'J') {
		el.innerHTML += '1 year (three issues)<br>';
		if (global.isUK)
			el.innerHTML += '<span style="font-size:larger">&pound;25</span>';
		else
			el.innerHTML += '<span style="font-size:larger">$39</span>';
	}
	else {
		el.innerHTML += '1 year (four issues)<br>';
		if (global.isUK)
			el.innerHTML += '<span style="font-size:larger">&pound;14</span><br>';
		else
			el.innerHTML += '<span style="font-size:larger">$29</span><br>';
		el.innerHTML += '<span style="font-size:smaller">If you are renewing five or more at a time, the fifth subscription is free!</span>';
	}
	
	// donor name + address
	el = document.createElement('div');
	notice.appendChild(el);
	el.className = 'r9-donor-name';

	var address = donorData.address_1 + '<br>';
	if (donorData.address_2 != '')
		address += donorData.address_2 + '<br>';
	if (global.isCA) {
		address += donorData.city + ', ' + donorData.province + ', ' + donorData.postal_code + '<br>';
	}
	else {
		address += donorData.city + ', ' + donorData.postal_code + '<br>';		
		address += donorData.country + '<br>';		
	}

	// name & address block
	el.innerHTML = '';
	if (global.isUK) {	// pre-pend salutation
		el.innerHTML += donorData.title + ' ';
	}
	el.innerHTML += donorData.name + '<br>';
	el.innerHTML += address + '<br>';

	// set margin for address block
	var marginTopLeft = global.settings[S_SUBS_GIFT_RENEWAL_MARGIN].split(',');
	el.style.marginTop = marginTopLeft[0] + 'px';				
	el.style.marginLeft = marginTopLeft[1] + 'px';	

	// letter content
	el = document.createElement('pre');
	notice.appendChild(el);
	if (subType == 'J')
		el.innerHTML = settings[S_GIFT_RENEWAL_LETTER_J] + '<br><br><hr>';
	else
		el.innerHTML = settings[S_GIFT_RENEWAL_LETTER] + '<br><br><hr>';

	// donor renew options
	if (donorData.expiry != '99:4' && donorData.expiry > '') {	// not applicable if current sub is recurring type
		el = document.createElement('div');
		notice.appendChild(el);
		el.innerHTML = 'Your own subscription expires: ' + donorData.expiry + ' - <b>' + getSubDate(donorData.expiry, subType) + '</b><br>';
		el.innerHTML += '[  ] Please renew my subscription as well.<br><br>';
	}
	
	// payment details
	el = document.createElement('div');
	notice.appendChild(el);		
	if (subType == 'J')	
		el.innerHTML = 'You can safely renew your subscription(s) on our secure website at CREATION.com/journal<br>';
	else
		el.innerHTML = 'You can safely renew your subscription(s) on our secure website at CREATION.com/renew<br>';
	if (global.isUK)
		el.innerHTML += '<b>OR</b> please find enclosed my cheque/money order payable to <i>Creation Ministries International</i> for &pound;.............<br>';
	else
		el.innerHTML += '<b>OR</b> please find enclosed my cheque/money order payable to <i>Creation Ministries International</i> for $.............<br>';
	el.innerHTML += '<b>OR</b> please charge my: ';
	el.innerHTML += '[  ] Mastercard &nbsp;&nbsp;[  ] Visa &nbsp;&nbsp;';
	if (global.isUK)
		el.innerHTML += '[  ] Amex';
	el.innerHTML += '<br><br>';
	for (var y=0; y<17; y++) {
		el = document.createElement('span');
		notice.appendChild(el);		
		el.innerHTML += '';
		if (y == 4 || y == 8 || y == 12)
			el.className = 'r9-square separator';
		else
			el.className = 'r9-square';
	}
	el.innerHTML += 'Expiry date:';
	for (var y=0; y<5; y++) {
		el = document.createElement('span');
		notice.appendChild(el);		
		el.innerHTML += '';
		if (y == 2)
			el.className = 'r9-square separator';
		else
			el.className = 'r9-square';
	}
	el.innerHTML += 'Verification digits:';
	for (var y=0; y<3; y++) {
		el = document.createElement('span');
		notice.appendChild(el);		
		el.innerHTML += '';
		el.className = 'r9-square';
	}
	
	if (global.isUK) {	// add amex check digit box
		el = document.createElement('span');
		notice.appendChild(el);		
		el.innerHTML = '';
		el.className = 'r9-square amex';
		el = document.createElement('div');
		notice.appendChild(el);		
		el.innerHTML = 'AMEX';
		el.className = 'r9-amex-label';
	}
	
	el = document.createElement('span');
	notice.appendChild(el);		
	el.innerHTML = '<br><br><br><br>Name on card:.............................................................. Signature:...........................................';
	el = document.createElement('div');
	notice.appendChild(el);
	el.innerHTML = '<br><hr><br><b>PLEASE RETURN WHOLE FORM</b>'
	el.innerHTML += '<br><br>These recipients have subscriptions expiring with issue number ' + issueNumber + ' - ' + getSubDate(issueNumber, subType) + '<br><br>';
							
	// recipient details
	el = document.createElement('table');
	notice.appendChild(el);
	for (var y in donorData.recipient) {
		el = document.createElement('tr');
		notice.appendChild(el);
		el = document.createElement('td');
		notice.appendChild(el);
		el.innerHTML = donorData.recipient[y].name + ' - ' // name
		el.innerHTML += donorData.recipient[y].address_1;
		if (donorData.recipient[y].address_2 != '')
			el.innerHTML += ', ' + donorData.recipient[y].address_2;
		el.innerHTML += ', ' + donorData.recipient[y].city;
		if (global.isCA)
			el.innerHTML += ', ' + donorData.recipient[y].province;
		el.innerHTML += ', ' + donorData.recipient[y].postal_code;
		el.innerHTML += ' (#' + donorData.recipient[y].id + ')';		// customer id
	}
}
// end of gift renewal notices

// daily sales summary 2016
function dailySalesExtract2016(option, theFilter) {
	switch (option) {
		case 'include': { filter = 'so.payment_type="' + theFilter + '"'; break; }
		case 'exclude': { filter = 'so.payment_type!="' + theFilter + '"'; break; }
		default: { filter = "1" }
	}
	
	$.ajax({
		type: 'get',
		url: "scripts/get-data.php",		// first get the data...
		cache: false,
		data: { 
			query: 'salesOrderSummary2016',
			key: 0,		// not required
			txn_date: document.getElementById('r15-start-date').value,
			filter: filter
		},
		success: function(result) { 		// ...then browse it
			displaySOS2016(result);		
		},
		error: function (xhr, ajaxOptions, thrownError) {
			alert(xhr.responseText);
		},
		dataType: 'json'
	});			
		
}		

function displaySOS2016(data) {	
	var abcdTotal = 0;
	var reportData = document.getElementById('report-results');
	reportData.innerHTML = '';

	// products (non books), shipping
	if (typeof data[0] != 'undefined') {		
		reportData.innerHTML = '<b>A. PRODUCTS (non-books), SHIPPING, DIGITAL-ONLY MAGAZINES</b><br>';
		reportData.innerHTML += '<div class="a-0"><b>Tax Band</b></div>' +
													'<div class="a-1"><b>SKU</b></div>' +
													'<div class="a-2"><b>Title</b></div>' +
													'<div class="a-3"><b>Qty</b></div>' +
													'<div class="a-4"><b>Total Value</b></div><br>';	
		var prevBand = '';
		var total = 0;
		var sep = '<div class="a-sep"></div>';
		
		for (var x in data[0]) {		
			reportData.innerHTML += sep;
			
			var row = '<div class="a-0">';
			
			if (data[0][x][0] != prevBand)
				row += data[0][x][0];
			else
				row += '';
			
			row += '</div>';
			
			row += '<div class="a-1">' + data[0][x][1] + '</div>';
			row += '<div class="a-2">' + data[0][x][2] + '</div>';
			row += '<div class="a-3">' + data[0][x][3] + '</div>';
			row += '<div class="a-4">' + data[0][x][4] + '</div>';
			reportData.innerHTML += row + '<br>';
			
			total += Number(data[0][x][4]);
			prevBand = data[0][x][0];
		}
		reportData.innerHTML += '<div class="a-total">Total (A): ' + formatCurrency(total) + '</div><br>';
		abcdTotal += total;
	}

	// products (books & magazines)
	if (typeof data[1] != 'undefined') {		
		reportData.innerHTML += '<br><b>B. PRODUCTS (books) & MAGAZINES (non digital-only)</b><br>';
		reportData.innerHTML += '<div class="b-0"><b>SKU</b></div>' +
													'<div class="b-1"><b>Title</b></div>' +
													'<div class="b-2"><b>Qty</b></div>' +
													'<div class="b-3"><b>Total Value</b></div><br>';	
		var total = 0;
		var sep = '<div class="b-sep"></div>';		
		
		for (var x in data[1]) {
			reportData.innerHTML += sep;
			
			var row = '<div class="b-0">' + data[1][x][0] + '</div>';
			row += '<div class="b-1">' + data[1][x][1] + '</div>';
			row += '<div class="b-2">' + data[1][x][2] + '</div>';
			row += '<div class="b-3">' + data[1][x][3] + '</div>';
			reportData.innerHTML += row + '<br>';
			
			total += Number(data[1][x][3]);
		}
		reportData.innerHTML += '<div class="b-total">Total (B): ' + formatCurrency(total) + '</div><br>';
		abcdTotal += total;
	}
	
	// every donation (recurring)
	if (typeof data[5] != 'undefined') {		
		reportData.innerHTML += '<br><b>C1. RECURRING DONATIONS</b>';
		var row = document.createElement('div');
		reportData.appendChild(row);
		row.innerHTML = '<b><div class="b-0">SKU</div>' +
									'<div class="b-1">Title</div>' +
									'<div class="b-2">Qty</div>' +
									'<div class="b-3">Total</div></b>';
		var total = 0;
		var sep = '<div class="c-sep"></div>';		
									
		for (var x in data[5]) {			
			var row = document.createElement('div');
			reportData.appendChild(row);

			row.innerHTML = sep;
			
			row.innerHTML += '<div class="b-0">' + data[5][x][0] + '</div>' +
										'<div class="b-1">' + data[5][x][1] + '</div>' +
										'<div class="b-2">' + data[5][x][2] + '</div>' +
										'<div class="b-3">' + data[5][x][3] + '</div>' 										
			total += Number(data[5][x][3]);
		}
		// grand total
		var row = document.createElement('div');
		reportData.appendChild(row);
		row.innerHTML = '<div class="b-total">Total (C1): ' + formatCurrency(total) + '</div>';		
		abcdTotal += total;		
	}
	
	// every donation (non-recurring)
	if (typeof data[6] != 'undefined') {		
		reportData.innerHTML += '<br><b>C2. DONATIONS</b>';
		var row = document.createElement('div');
		reportData.appendChild(row);
		row.innerHTML = '<b><div class="b-0">SKU</div>' +
									'<div class="b-1">Title</div>' +
									'<div class="b-2">Qty</div>' +
									'<div class="b-3">Total</div></b>';
		var total = 0;
		var sep = '<div class="c-sep"></div>';		
									
		for (var x in data[6]) {			
			var row = document.createElement('div');
			reportData.appendChild(row);
			
			row.innerHTML = sep;
			
			row.innerHTML += '<div class="b-0">' + data[6][x][0] + '</div>' +
										'<div class="b-1">' + data[6][x][1] + '</div>' +
										'<div class="b-2">' + data[6][x][2] + '</div>' +
										'<div class="b-3">' + data[6][x][3] + '</div>' 										
										
			total += Number(data[6][x][3]);
		}
		// grand total
		var row = document.createElement('div');
		reportData.appendChild(row);
		row.innerHTML = '<div class="b-total">Total (C2): ' + formatCurrency(total) + '</div>';		
		abcdTotal += total;		
	}

	// custom items
	if (typeof data[3] != 'undefined') {
		reportData.innerHTML += '<br><b>D. CUSTOM ITEMS</b><br>';
		reportData.innerHTML += '<div class="d-0"><b>Province</b></div>' +
													'<div class="d-1"><b>Customer</b></div>' +
													'<div class="d-2"><b>Description</b></div>' +
													'<div class="d-3"><b>Qty</b></div>' +
													'<div class="d-4"><b>Value</b></div>' +
													'<div class="d-5"><b>Sales Order #</b></div><br>';	
		var total = 0;
		var sep = '<div class="d-sep"></div>';
		
		for (var x in data[3]) {
			reportData.innerHTML += sep;

			var row = '<div class="d-0">' + data[3][x][0] + '</div>';
			row += '<div class="d-1">' + data[3][x][1] + '</div>';
			row += '<div class="d-2">' + data[3][x][2] + '</div>';
			row += '<div class="d-3">' + data[3][x][3] + '</div>';
			row += '<div class="d-4">' + data[3][x][4] + '</div>';
			row += '<div class="d-5">' + data[3][x][5] + '</div>';
			reportData.innerHTML += row + '<br>';
			
			total += Number(data[3][x][4]);
		}
		reportData.innerHTML += '<div class="d-total">Total (D): ' + formatCurrency(total) + '</div><br>';
		abcdTotal += total;
	}
	
	reportData.innerHTML += '<div class="abcd-total">Total (A+B+C+D): ' + formatCurrency(abcdTotal) + '</div><br>';	
	
	// payment receipts
	if (typeof data[4] != 'undefined') {		
		reportData.innerHTML += '<br><b>PAYMENT RECEIPTS</b>';
		var row = document.createElement('div');
		reportData.appendChild(row);
		row.innerHTML = '<b><div class="e-0">Sales Order</div>' +
									'<div class="e-1">Name</div>' +
									'<div class="e-2"></div>' +
									'<div class="e-3">Value</div>' +
									'<div class="e-4">Order Date</div>' +
									'Payment type</b>';
		var total = 0;
		var subTotal = 0;
		var prevType = '';
		for (var x in data[4]) {
			if (prevType == '' || data[4][x][5] + data[4][x][4] == prevType)
				subTotal += Number(data[4][x][3]);
			else {	
				// show sub total for each (payment type + order date) combo
				var row = document.createElement('div');
				reportData.appendChild(row);
				row.innerHTML = '<div class="e-sub-total">' + formatCurrency(subTotal) + '</div>';	
				subTotal = Number(data[4][x][3]);
			}

			var row = document.createElement('div');
			reportData.appendChild(row);
			row.innerHTML = '<div class="e-0">' + data[4][x][0]+ '</div>' +
										'<div class="e-1">' + data[4][x][1]+ '</div>' +
										'<div class="e-2"></div>' +
										'<div class="e-3">' + data[4][x][3]+ '</div>' +
										'<div class="e-4">' + data[4][x][4].substr(0,10)+ '</div>' +
										data[4][x][5] + ' (' + data[4][x][6] + ')';
			
			total += Number(data[4][x][3]);
			prevType = data[4][x][5] + data[4][x][4];
		}
		// final sub total
		var row = document.createElement('div');
		reportData.appendChild(row);
		row.innerHTML = '</div><div class="e-sub-total">' + formatCurrency(subTotal) + '</div>';	
		// grand total
		var row = document.createElement('div');
		reportData.appendChild(row);
		row.innerHTML = '<div class="e-total">TOTAL: ' + formatCurrency(total) + '</div>';
	}
}

// for cmi usa harvest formating they want:
// '39:4' to look like '3940'
function formatSubDue(subdue) {
	return subdue.substr(0,2) + subdue.substr(3,1) + '0';
}