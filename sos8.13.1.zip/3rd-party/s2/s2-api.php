<?php
/**
* @package    CMI Subscription System External API
* @author     Jonny Eggins <web@creation.info>
* @author     Josh Barrie <web@creation.info>
* @version    1.0
* 
*	keys.json file required with json 
*	Example
*	{
*		"host":"http://xxxx",
*		"username":"xxxxx",
*		"password":"xxxxxxx",
*		"token":"xxxxxxxxxxxxxxxx"
*	}
* 
*/

/*
$data = array(
	'subId' => 2149448,
	'reason' => 'just because',
	'newExpiry' => '4020'
);
$s2 = new subsApi('uk-test-keys.json');			
$result = $s2->adjustExpiry(json_encode($data));
echo json_encode($result);
*/


/*
$data = array(
	'subid' => 2308185,
	'issuecount' => 4,
	'printletter' => true
);	
$data = array(
	'subid' => 46921,
	'expireWithIssue' => 4010
);	
$s2 = new subsApi('uk-test-keys.json');			
$result = $s2->renewSubscription(json_encode($data));
echo json_encode($result);
*/
	
/*
{"federationid":"1772079","issuecount":"8","qty":"1","analytics":{"sourceid":"","event_id":""},"pubid":"0","giverid":"","email":"t@may.com"}

$data = array(
	'federationid' => '1772079',
	'issuecount' => 8,
	'qty' => '1',
	'analytics' => array( 
		'sourceid' => '',
		'event_id' => '',
	),
	'pubid' => '2',
	'giverid' => 0,
	'email' => 't@may.com'
);		

$s2 = new subsApi('uk-test-keys.json');			
echo json_encode($s2->createSubscription(json_encode($data)));
*/
/*
$data = array(
	'federationid' => '1616740',
	'customStartIssue' => '3940',
	'customExpiryIssue' => '4120',
	'qty' => '1',
	'analytics' => array( 
		'sourceid' => '',
		'event_id' => '',
	),
	'pubid' => '1',
	'giverid' => 0
);		
$s2 = new subsApi('uk-test-keys.json');			
echo json_encode($s2->createSubscription(json_encode($data)));
*/
/*
$s2 = new subsApi();			
echo $s2->getSubscription(598180);
*/
/*
$s2 = new subsApi('uk-test-keys.json');			
echo json_encode($s2->getCustomerSubscriptions(1050409));
*/
/*
$s2 = new subsApi();			
echo $s2->getAnalytics();
*/
/*
$data = array('subid' => 598145, 'newqty' => 2);	
$s2 = new subsApi();			
echo $s2->adjustBulks(json_encode($data));
*/


/*
$s2 = new subsApi('uk-test-keys.json');			
$result = ($s2->searchCustomersByAccountingId(104708));
echo json_encode($result);
*/

//echo $result->country;
//echo '-->' . is_null($result['sstatus']);

//echo $result;
//if (is_object($result))
//	echo ' is obj';
//else {
//	echo $result;
//	echo ' is something else';
//}

/*
$data = array(
	'webstoreid' => '',
	'accountingid' => '100001',
	'title' => 'Mr',
	'firstname' => 'Bob & Jean',
	'lastname' => 'Acheson',
	'addr1' => '70 Mill Road',
	'addr2' => 'Whittlesey',
	'city' => 'PETERBOROUGH',
	'state' => '',
	'postcode' => 'PE7 1SN',
	'country' => 'UNITED KINGDOM',
	'email' => ''
);
$s2 = new subsApi('uk-test-keys.json');			
//echo json_encode($s2->createCustomer(json_encode($data)));
$result = $s2->createCustomer(json_encode($data));
print_r($result);
*/

/*
$data = array(
	'webstoreid' => '',
	'federationid' => '168413',
	'title' => 'Revf',
	'firstname' => 'newton',
	'lastname' => 'isaac',
	'addr1' => '15 address st',
	'addr2' => 'address_2',
	'city' => 'citytown',
	'state' => 'province',
	'postcode' => '123 ABC',
	'country' => 'Azania',
	'email' => 'email1@bob.com'
);
$s2 = new subsApi('uk-test-keys.json');		
echo json_encode($s2->updateCustomer(json_encode($data)));
*/

/*
$data = array(
	'webstoreid' => '',
	'federationid' => '1236944',
	'title' => 'Revf',
	'firstname' => 'newton',
	'lastname' => 'isaac',
	'addr1' => '15 address st',
	'addr2' => 'address_2',
	'city' => 'citytown',
	'state' => 'province',
	'postcode' => '123 ABC',
	'country' => 'Azania',
	'email' => 'email1@bob.com'
);
echo '<br>updateCustomer=' . $s2->updateCustomer(json_encode($data));
*/
/*
$s2 = new subsApi('uk-test-keys.json');		
echo '<br>getCustomerSubscriptions=' . json_encode($s2->getCustomerSubscriptions(1138988));
*/

class subsApi {
	private $auth; // store the credentials to be used
	private $debug; // store the class setttings

	/**
	 * This is loaded when the class is included;
	 */
	function __construct($s2keys) {
		try {
//			$jsonkeys = file_get_contents("c://wamp//www//sos//3rd-party//s2//keys.json");
			$jsonkeys = file_get_contents("c://wamp//www//sos//3rd-party//s2//" .  $s2keys);
		} catch (Exception $e){

			echo 'Having trouble reading keys.json file<br>'.$e->getMessage();
			die();
		}
		if ($jsonkeys == ''){
			echo 'Having trouble reading keys.json file<br>'.$e->getMessage();
		}
		$keys =  json_decode($jsonkeys);
		$this->auth = $keys;
		$this->debug = 0;
	}
	
	/**
	 * Turn debugging on
	 */
	public function turnDebuggingOn(){
		$this->debug = 1;
	}

	/**
	 * Search customers by accounting id
	 * @param  [int] $id [accounting id]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersByAccountingId($id){
		$url = '/api/customer/search?accountingid='.$id;
		$method = 'GET';
		$response = $this->request($url,$method);
		return $response;
	}
	
	 /**
	 * Create new customer
	 * @param  [json] $subJson  [Json of the subscription details]
	 * @return [json]  [return json success/failed message]
	 */
	public function createCustomer($json){
		$url = '/api/customer/create';
		$response = $this->request($url,'POST',$json);
		return $response;
	}	
	
	/**
	 * Update customer
	 * NOTE: You need to lookup customer first to get federation id and then override the details and submit json
	 * @param  [json] $subJson  [Json of the updated customer details]
	 * @return [json]  [return json success/failed message]
	 */
	public function updateCustomer($details){
		$url = '/api/customer/update';
		$response = $this->request($url,'POST',$details);
		return $response;
	}	
	
	/**
	 */
	public function getCustomerSubscriptions($federationid){
		$url = '/api/customer/'.$federationid.'/subscriptions';
		$method = 'GET';
		$response = $this->request($url,$method);			
		return $response;
	}

	/**
	 * Get subscription details from sub id
	 * @param  [int] $subid [the id of the subscription]
	 * @return [json]        [return json with subs details and history]
	 */
	public function getSubscription($subid){
		$url = '/api/subscription/'.$subid;
		$method = 'GET';
		$response = $this->request($url,$method);		
		return $response;
	}	
	
    /**
	 * Add a new subscription to a customer *Federation ID required
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [json] $subJson  [Json of the subscription details]
	 * @return [json]        [return json success/failed message]
	 */
	public function createSubscription($subJson){
		$url = '/api/subscription/create';
		$method = 'POST';
		$response = $this->request($url,$method,$subJson);
		return $response;
	}
	
	/**
	 * cancel subscription immediately
	 * @param  [json] $json  [json with subid  and reason]
	 * @return [json]  [return json success/failed message]
	 */
	public function cancelNow($json){
		$url = '/api/subscription/cancelnow';
		$return = $this->request($url,'POST',$json);
		return $return;
	}
	
   	/**
	 * Add Comment to subscription
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [string] $comment  [The comment you want to attach to the subscription]
	 * @return [json]        [return json success/failed message]
	 */
	public function  commentSubscription($subid,$comment) {
		$url = '/api/subscription/comment/'.$subid;
		$json = new stdClass();
		$json->comment = $comment;
		$json = json_encode($json);
		$method = 'POST';
		$response = $this->request($url,$method,$json);
		return $response;
    }	

	/**
	 * Update the subscription details (email only)
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [string] $email  [The customers new email for that subscription]
	 * @return [json]        [return json success/failed message]
	 */
	public function updateSubscription($subid,$email){
		$url = '/api/subscription/update/'.$subid;
		$json = new stdClass();
		$json->email = $email;
		$json = json_encode($json);
		$method = 'POST';
		$response = $this->request($url,$method,$json);
		return $response;
    }
   
	/**
	 * Adjust the qty of a sub
	 * @param  [json] $json  [json with subid and newqty]
	 * @return [json]  [return json success/failed message]
	 */
	public function adjustBulks($json){
		$url = '/api/subscription/adjustbulks';
		$response = $this->request($url,'POST',$json);
		return $response;
	}
	
	/**
	 * adjust Expiry date on a sub
	 * @param  [json] $json  [json with subid and newExpiry and reason]
	 * @return [json]  [return json success/failed message]
	 */
	public function adjustExpiry($json){
		$url = '/api/subscription/adjustexpiry';
		$response = $this->request($url,'POST',$json);
		return $response;
	}
	
	/**
	 * Renew as subscription
	 * @param  [json] $json  [description]
	 * @return [json]        [return json success/failed message]
	 */
	public function renewSubscription($json){
		$obj = json_decode($json);
		$subid = $obj->subid;
		$url = '/api/subscription/renew/'.$subid;
		$method = 'POST';
		$response = $this->request($url,$method,$json);
		return $response;
	}

	/**
	 * remove relationship on sub
	 * @param  [string] $subid  [subid of subscription to remove giver id]
	 * @return [json]  [return json success/failed message]
	 */
	public function removeRelationshipFromSub($subid){
		$url = '/api/subscription/removeRelationshipFromSub/'.$subid;
		$method = 'GET';
		return $this->request($url,$method);
	}
	
	/**
	 * Suspend now
	 * @param  [json] $json  [json with subid  and reason]
	 * @return [json]  [return json success/failed message]
	 */
	public function suspendSub($json){
		$url = '/api/subscription/suspendsub';
		$return = $this->request($url,'POST',$json);
		return $return;
	}

	/**
	 * Reactivate now
	 * @param  [json] $json  [json with subid]
	 * @return [json]  [return json success/failed message]
	 */
	public function reActivateSub($json){
		$url = '/api/subscription/reactivatesub';
		$return = $this->request($url,'POST',$json);
		return $return;
	}	
	
	/**
	 * Method to control the request to the api, and do checks to make sure calls make sense
	 * @param  [string] $url    [url the is being requested]
	 * @param  [string] $method [POST,PUT,GET]
	 * @param  [json] $json   [json infomation (not required) ]
	 * @return [json]         [Returns what ever the server returns]
	 */
	public function request($url,$method,$json = '') {
		if ($url == ''){
			die('no url given');
		}
		//do checks to make sure requests are correct;
		if ($method != 'GET') {
			if ($json == '') {
				$this->displayMessage('failed','Json required on PUT/POST','');
			}
		}
		return $this->curlRequest($this->auth,$url,$method,$json);
	}

	/**
	 * Method for connecting by curling and making requests to the API
	 * @param  [obj] $auth       [contains the credentials to connect to API]
	 * @param  [string] $requestUrl [The URL that the request is going to]
	 * @param  [string] $method     [POST,GET,PUT]
	 * @param  [json] $json       [Json information to pass to API]
	 * @return [json]             [returns a json request]
	 */
	private function curlRequest($auth,$requestUrl,$method,$json) {		
		$requestUrl = $this->auth->host.$requestUrl;
		$ch = curl_init();
		
		if($method == 'PUT') {
			$putString = $json;
		}

		// Headers
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Authorization: Basic '.base64_encode("$auth->username:$auth->password"),
			'x-subsys-token:'.$auth->token,
			'Content-Type: application/json',
			'Accept: application/json'
		));	

		curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $requestUrl);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

		if($method == 'PUT') {
			curl_setopt($ch, CURLOPT_PUT, true);
			curl_setopt($ch, CURLOPT_INFILE, $json);
			curl_setopt($ch, CURLOPT_INFILESIZE, strlen($json));
		}

		if($method == 'POST') {

			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		}

		// Time Out
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30); //timeout in seconds

		// Allow any SSL
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$info = curl_getinfo($ch);
		if ($this->debug == 1) {
			echo '<pre>';
			print_r($info);
			echo '<pre>';
		}

		$response = json_decode(curl_exec($ch));
//$response = (curl_exec($ch));

		// write a log of the api inputs and outputs; probably won't need this once the system settles in
		$logText = 'INPUT: url=' . $requestUrl . '; json=' . $json;
		$this->writeS2log($logText . "\r\n" . 'RESPONSE: ' . json_encode($response));

		if ($this->debug == 1) {
			echo '<pre>';
			print_r($response);
			echo '<pre>';
		}
		
		if($errno = curl_errno($ch)) {
			$error_message = curl_strerror($errno);
			$msg = "cURL error ({$errno}):\n {$error_message}";

			$response = new stdClass();
			$response->status = 'failed';
			$response->message = $msg;
		}
		
//echo 'set?=' . $response->status;
		// CB wants all responses to have a status
		if (!isset($response->status)) {
		//	echo 'not set';
//			$response->status = 'success';
//			$response->status = 'success';
		}
//echo json_encode($response->office);
		
		curl_close($ch);
		
		return $response;
	}	
	
	/**
	 * [display the errors in json format nicely]
	 * @param  [string] $status      ['success','failed','notice','error']
	 * @param  [string] $messageText [Text you want to pass back]
	 * @param  [string] $message2    [Extras Text you want to pass back]
	 * @param  obj $extra       	[Object of extra info to pass back]
	 * @return [json]              [Dies and returns json]
	 */
	public function displayMessage($status,$messageText,$message2,$extra = ''){
            $message = new stdClass();
            $message->status = $status;
            $message->message = $messageText;
            $message->message2 = $message2;
            if (extra != ''){
                $message = (object) array_merge((array) $message, (array) $extra);
            }
            echo json_encode($message);
            die();
    }
	
	/* 	New log file created every month
	*/
	public function writeS2log($logText) {
		//$path = $_SERVER["DOCUMENT_ROOT"] . $_POST['path'];
//		$path = 'logs/';
		$path = $_SERVER["DOCUMENT_ROOT"] . 'sos/3rd-party/s2/logs/';
		$filename = $path . 'S2LOG-' . date('Ym') . '.txt';

		$text = date("Y-m-d H:i:s") . "\r\n";				// date/time
		$text .= $logText;   										// the text to be logged
		$text .= "\r\n";   											// new line

		file_put_contents($filename, $text, FILE_APPEND | LOCK_EX);
	}
	
	public function xxxxxxxxxxxxxxreadS2log() {
		$path = $_SERVER["DOCUMENT_ROOT"] . 'sos/3rd-party/s2/logs/';
//		$path = 'C:/wamp/www/sos/3rd-party/s2/logs/';
//		$path = 'logs/';
		$filename = $path . 'S2LOG-' . date('Ym') . '.txt';

		return file_get_contents($filename);
	}	
	
	
	//---------- CB -- not using these hereunder:
	
	/**
	 * Get subscription details from sub id
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [string] $cancelledReason [Reason why they wish to cancel their subscription]
	 * @return [json]        [return json success/failed message]
	 */
	public function cancelSubscription($subid,$cancelledReason){
		$json = new stdClass();
		$json->reason = $cancelledReason;
		$url = '/api/subscription/cancel/'.$subid;
		$method = 'POST';
		$json = json_encode($json);
		$response = $this->request($url,$method,$json);
		return $response;
	}	

	public function autoCreateSubscription($subJson){
	    $url = '/api/subscription/autocreate';
		$method = 'POST';
		return $this->request($url,$method,$subJson);
	}

	/**
	 * get a list of all the publications and there current issues
	 * @return [json]        [return json success/failed message]
	 */
	public function getPublications(){
	    $url = '/api/publications';
	    $method = 'GET';
	    return $this->request($url,$method);
	}

	/**
	 * get a list of all the publications and there current issues
	 * @param  [int] $subid [the id of the subscription]
	 * @param  [json] $json  [description]
	 * @return [json]        [return json success/failed message]
	 */
	public function getAnalytics(){
	    $url = '/api/analytics';
	    $method = 'GET';
	    return $this->request($url,$method);
	}


	/**
	 * Search customers by federation id
	 * @param  [int] $id [federation id]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersByFederationId($id){
		$url = '/api/customer/search?federationid='.$id;
		$method = 'GET';
		return $this->request($url,$method);
	}

	/**
	 * Search customers by webstoreid id
	 * @param  [int] $id [webstoreid id]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersByWebstoreId($id){
		$url = '/api/customer/search?webstoreid='.$id;
		$method = 'GET';
		return $this->request($url,$method);
	}

	/**
	 * Search customers by email
	 * @param  [int] $id [email]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersByEmail($email){
		$url = '/api/customer/search?email='.urlencode($email);
		$method = 'GET';
		return $this->request($url,$method);
	}

	/**
	 * Search customers by fistname or lastname
	 * @param  [string] $firstname [firstname search term]
	 * @param  [string] $lastname [lastname search term]
	 * @return [json]     [return a single customer with their details]
	 */
	public function searchCustomersViaName($firstname,$lastname){
		$url = '';
		if ($firstname == '' && $lastname == ''){

			echo 'Please enter at least firstname or lastname';
			die();
		} else if ($firstname == '' && $lastname != ''){
			$firstname = urlencode($firstname);
			$lastname = urlencode($lastname);
			$url = '/api/customer/search?lastname='.$lastname;
		} else if ($firstname != '' && $lastname == ''){
			$firstname = urlencode($firstname);
			$url = '/api/customer/search?firstname='.$firstname;
		} else if ($firstname != '' && $lastname != ''){
			$firstname = urlencode($firstname);
			$lastname = urlencode($lastname);
			$url = '/api/customer/search?firstname='.$firstname.'&lastname='.$lastname;
		} 
	
		$method = 'GET';
		return $this->request($url,$method);
	}

	/**
	 * Do a check to make sure it is a valid json
	 * @param  [json] $json [json to test]
	 * @return [json]       [Dies if failes else retunr json]
	 */
	public function checkJson($json){
		if (!is_object($json)){
			$json = json_decode($json); // check to see if it is a true json
			if (json_last_error() != JSON_ERROR_NONE){
				$this->displayMessage('failed','Bad json','Error encoding json');
			}
			try {
				$json = json_encode($json); // make sure it can encode to json
			} catch(Exception $e){
				$this->displayMessage('failed','Bad json',$e->getMessage());
			}
		} else {
			try {
				$json = json_encode($json); // make sure it can encode to json
			} catch(Exception $e){
				$this->displayMessage('failed','Bad json',$e->getMessage());
			}
		}

	}
}
?>