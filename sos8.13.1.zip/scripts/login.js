//-- start login bits
oLogin = new login();

function login() {
	var thisObject = this;
	
	this.checkForNewRelease = function() {
		$.ajax({
			type: 'get',
			url: "scripts/software-update.php",
			cache: false,
			data: { 
				func: 'getReleaseInfo',
				version: global.releaseNumber
			},
			success: function(result) { 
				if (result.isNewRelease) {
					$('#login-new-release-alert').show();
				}
//console.log(result)
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}

	this.setupTimer = function(set) {
		if (set) {
			this.logoffWarningGiven = false;	
			this.timer = setInterval(function() {
				logoutTimerCheck();
			}, 1000);		// every second
			
			this.extendLife();
			
			$("body").bind("keypress click", function () {
				thisObject.extendLife();
			}); 	
		}
		else
			clearInterval(this.timer);
	}		

	this.extendLife = function() {
		var d = new Date();
		var currentTime = d.getTime();
		
		var loginTimeout = Number(currentTime + (oSettings.login_timeout * 60000));
	
		localStorage.setItem("loginTimeout", loginTimeout);	
//console.log(loginTimeout)
	}
		
	// determine if user has access to a specific menu option
	this.hasMenuRights = function(option) {
		for (var x in this.menuRights) {
			if (this.sys_admin == 1 || this.menuRights[x] == option) {
				return true;
			}
		}
		return false;
	}	
	
	this.getFirstVisibleTabByClass = function(classname) {
		var s0 = $('.' + classname + ':visible:first');
		var s1 = s0[0].id;
		var s2 = s1.substr(s1.lastIndexOf('-') + 1);		
		
		return s2;
	}
	
	this.acknowledgeUpgrade = function () {
		var sql = 'update users set read_release_notes="' + global.releaseNumber + '" where login_uid="' + oLogin.uid+ '"';
		execSQL(sql, function() {
			$('#login-new-release-msg').hide();			
		});
	}

	this.initAlerts = function() {
//console.log(oLogin)
		oSettings.s2active = (oSettings.s2active == 1);
//console.log(settings, oSettings.s2active)		
		// check and alert for outstanding s2 updates
		if (oSettings.s2active && oLogin.alert_s2 == 1) {
			var seconds = 5;
			setInterval(function() {
				checkS2PendingUpdates();
			}, seconds * 1000);
		}				
		
		// check and alert for incomplete harvests
		if (oLogin.alert_harvest == 1)
			checkHarvestLog();
		
		// check for any outstanding event todo items
		if (oLogin.alert_todo == 1)
			setInterval(function() {
				checkTodos();
			}, 5 * 1000);		

//console.log(2,oLogin.uid)
		if (oLogin.alert_bom == 1)
			setInterval(function() {
				checkEmptyPacks();
			}, 5 * 1000);		
			
		if (oLogin.alert_stock == 1)
			setInterval(function() {
				checkLowStock();
			}, 5 * 1000);		
	}
}

function testLogin() {
	var sql = 'select * from users where login_uid="' + $('#login-uid').val() + '"';
	execSQL(sql, function(userData) {
		if (userData.length == 0)		// no user record found
			$('#login-msg').html('login id not found.');
		else if ($('#login-s2-database').val() == 'none')
			$('#login-msg').html('choose an s2 database.');	
		else if (userData[0].login_pwd == '')
			setupNewPassword();
		else if ($('#login-pwd').val() == userData[0].login_pwd) {	// passwords match			
			localStorage.setItem("currentUser", $('#login-uid').val());
			localStorage.setItem("loggedIn", true);
			$("#no-menu").fadeOut();
			$("#menu").fadeIn();
			showLogin(1);
			
			oLogin.checkForNewRelease();
		}
		else {
			$('#login-msg').html('password is incorrect.');
			$('#login-pwd').val('');
		}
	});
}

function setupNewPassword() {
	$('#password-panel').slideDown();
	document.getElementById('password-1').focus();
}

// mode 1=index page, 2=other pages
function showLogin(mode) {	
	if (mode == 1) {
		$('#login-msg').html('you are logged in.');

		$("#no-menu").hide();
		$("#menu").show();

		$('#login-pwd').hide();
		$('#login-btn').hide();
		$('#login-logoff-btn').show();			
	}
	else
		$('#sos-user').html(localStorage.getItem("currentUser"));

	if (oSettings.login_timeout != 0)		// 0=never time out
		oLogin.setupTimer(true);	
	global.user = localStorage.getItem("currentUser");
	oLogin.uid = localStorage.getItem("currentUser");
	
	var sql = 'select * from users where login_uid="' + oLogin.uid + '"';
	execSQL(sql, function(data) {		
		for (var x in data[0])
			oLogin[x] = data[0][x];
		oLogin.menuRights = data[0].menu_rights.split(',');		
		setMenuRights();
		
		if (global.releaseNumber != oLogin.read_release_notes)
			$('#login-new-release-msg').slideDown();
		
	}, false);
}		

// enables menu options
function setMenuRights() {
	if (oLogin.hasMenuRights('1'))	{	// customers
		$('#index-menu-1').show();
		$('#header-menu-customers').css('display', 'block').show();
	}	
	
	if (oLogin.hasMenuRights('2')) {		// reports
		$('#index-menu-2').show();
		$('#header-menu-reports').css('display', 'block').show();
	}
	
		// reports sub-menu options
		for (var x = 1; x<5; x++) {
			var id = '2-' + x;
			if (oLogin.hasMenuRights(id))
				$('#reports-label-' + x).css('display', 'block').show();			
		}
		
	if (oLogin.hasMenuRights('3')) {		// settings
		$('#index-menu-3').show();
		$('#header-menu-settings').css('display', 'block').show();
	}
	
		// settings sub-menu options
		for (var x = 1; x<9; x++) {
			var id = '3-' + x;
			if (oLogin.hasMenuRights(id))
				$('#settings-label-' + x).css('display', 'block').show();			
		}
		if (global.isUK)
			$('#settings-label-7').css('display', 'block').hide();
		
	if (oLogin.hasMenuRights('4')) {		// utilities
		$('#index-menu-4').show();
		$('#header-menu-utilities').css('display', 'block').show();
	}
	
		// utilities sub-menu options
		for (var x = 1; x<10; x++) {
			var id = '4-' + x;
			if (oLogin.hasMenuRights(id)) {
				$('#utilities-label-' + x).css('display', 'block').show();			

//				if (x == 8 && !oSettings.s2active)		// s2 test harness
//					$('#utilities-label-' + x).css('display', 'block').hide();			

				if (x == 9 && global.isUK)	// courtesy call reset only for CA
					$('#utilities-label-' + x).css('display', 'block').hide();			
			}
		}

	if (oLogin.hasMenuRights('5'))	{	// inventory
		$('#index-menu-5').show();
		$('#header-menu-inventory').css('display', 'block').show();		
	}
		
		// inventory sub-menu options
		for (var x = 1; x<8; x++) {
			var id = '5-' + x;
			if (oLogin.hasMenuRights(id))
				$('#inventory-label-' + x).css('display', 'block').show();			
		}
		
	if (oLogin.hasMenuRights('6'))	{	// user maintenance
		$('#index-menu-6').show();
	}

	if (oLogin.hasMenuRights('7'))	{	// speakers picklists
//		$('#index-menu-7').show();
//		$('#header-menu-speakers').css('display', 'block').show();		
	}
	
		// speakers sub-menu options
		for (var x = 1; x<4; x++) {
			var id = '7-' + x;
//			if (oLogin.hasMenuRights(id))
//				$('#speakers-label-' + x).css('display', 'block').show();			
		}
	
	if (oLogin.hasMenuRights('8'))	{	// minimax
		$('#index-menu-8').show();
		$('#header-menu-mini').css('display', 'block').show();		
	}
	
		// minimax sub-menu options
		for (var x = 1; x<8; x++) {
			var id = '8-' + x;
			if (oLogin.hasMenuRights(id))
				$('#mini-label-' + x).css('display', 'block').show();			
		}
}

function logOffCheck() {
	confirmBox("CONFIRM", 
		"Log out of SOS?", 
		["Yes", "No"],
		[ function() { 
			logOff();
		}, 
		  function() {}
		]
	);
}

function logOff() {
	oLogin.setupTimer(false);	
	
	localStorage.setItem("currentUser", '');
	localStorage.setItem("loggedIn", false);	
	window.location.href = 'index.html';
}

function logoutTimerCheck() {
	var d = new Date();
	var currentTime = d.getTime();

	switch (true) {
		// if user has logged out, all open pages must close
		case localStorage.getItem("loggedIn") == 'false': {
			logOff();
			break;
		}	
		case oLogin.logoffWarningGiven: {		
			if (currentTime < localStorage.getItem("loginTimeout")) {	
				document.body.removeChild(oLogin.cb);
				oLogin.logoffWarningGiven = false;
			}
			else if (oLogin.graceCountdown <= 0)
				logOff();
			else {
				$('#login-grace-period').html(oLogin.graceCountdown);
				oLogin.graceCountdown--;
			}
			break;
		}
		case currentTime > localStorage.getItem("loginTimeout"): {
			logoffWarning();
			break;
		}
		default: {
//console.log(currentTime, localStorage.getItem("loginTimeout"))		
		}
	}
}

function logoffWarning() {
	oLogin.logoffWarningGiven = true;
	oLogin.graceCountdown = 15;	// seconds
	
	oLogin.cb = confirmBox("CONFIRM", 
		"You're about to be logged out of SOS.<br>Do you want to stay logged in?<p> Seconds left: <span id='login-grace-period'>...</span></p>", 
		["Yes", "No"],
		[ function() { 
			oLogin.logoffWarningGiven = false;		
		}, 
		  function() { 
			logOff(); 
		}],
		false		// no close button
	);
}
//-- end login bits