<?php
include "db-conx.php";

$picklistID = $_POST['picklistID'];
$completed = $_POST['completed'];
$speakerID = $_POST['speakerID'];
$attendance = $_POST['attendance'];
$eventDate = $_POST['eventDate'];
$eventName = $_POST['eventName'];
$picklistData = $_POST['picklistData'];

try {
	$db_handle->beginTransaction();

	// header stuff
	$sql = 'insert into picklists (id, speaker_id, event_date, event_name, completed, attendance_actual)
				values (?,?,?,?,?,?)
				on duplicate key
				update speaker_id=?, event_date=?, event_name=?, completed=?, attendance_actual=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$picklistID, 
		$speakerID, 
		$eventDate,
		$eventName,
		$completed,
		$attendance,
		$speakerID, 
		$eventDate,
		$eventName,
		$completed,
		$attendance
	));
	
	if ($picklistID == '*new*')
		$picklistID = $db_handle->lastInsertId();		
	
	$sql = 'delete from picklist_items where picklist_id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array($picklistID));
	
	for ($x=0; $x<sizeof($picklistData); $x++) {
		
		$sku = $picklistData[$x][0];
		$price = $picklistData[$x][4];
		$qty1 = $picklistData[$x][6];
		$qty2 = $picklistData[$x][7];
		$qtyIn = $picklistData[$x][10];
//			$templateID = $picklistData[$x][5];
		
		$sql = "insert into picklist_items set picklist_id=?, sku=?, price=?, qty_1=?, qty_2=?, qty_in=?";					
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array(
			$picklistID,
			$sku,
			$price,
			$qty1,
			$qty2,
			$qtyIn
		));		
	}

	// if picklist completed, update inventory
	if ($completed == 1) {
		createSalesOrder($speakerID, $picklistID, $picklistData);
	}
	
	$db_handle->commit();
//		$result = 'success';
}
catch (Exception $e) {
	$db_handle->rollback();
}
	
echo json_encode($picklistID);

function createSalesOrder($speakerID, $picklistID, $picklistData) {
	global $db_handle;

	$sql = 'insert into sales_orders set customer_id=?, payment_type=?, picklist_id=?, updated_by=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$speakerID,
		$_POST['paymentType'],
		$picklistID,
		$_POST['userID']
	));
	$soID = $db_handle->lastInsertId();

	// add sales order items
	for ($x=0; $x<sizeof($picklistData); $x++) {		
		$sku = $picklistData[$x][0];
		$title = $picklistData[$x][1];
		$price = $picklistData[$x][4];
		$qty = $picklistData[$x][8] - $picklistData[$x][10];

		$sql = "insert into sales_order_items
					(sales_order, sku, title, price, qty, type, sub_type)
					values (?,?,?,?,?,(select type from products where sku=? limit 1),(select sub_type from products where sku=? limit 1))";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($soID, $sku, $title, $price, $qty, $sku, $sku));

		// update stock qty
		$sql = 'update products set qty=qty-? where sku=?';
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($qty, $sku));
	}

	// update s/o value based on items sold
	$sql = "call update_so_value(?)";
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array($soID));

	// update picklist with sale order number
	$sql = 'update picklists set sales_order=? where id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array($soID, $picklistID));
}
?>