<?php
	/*
	
	One off script to rebuild the sales_order_bom_items table from scratch (for Canada)
	
	*/

include "db-conx.php";

die('used once.');

try {
	
	$db_handle->beginTransaction();
	
	/* loop through soi
	
			look up in products to see if its a pack
			
				if yes...
					insert sobi record
	
	*/
	
	$sql = 'delete from sales_order_bom_items';
//	$sql = 'update sales_order_bom_items set digital=3';
	$result = $db_handle->prepare($sql);			
	$result->execute();
	
//	$sql = 'select soi.id, soi.sku, soi.title from sales_order_items soi left join products p on p.sku=soi.sku where soi.type="P" and p.pack=1';
	$sql = 'select * from products p where p.pack=1';
	$result = $db_handle->prepare($sql);			
	$result->execute();
//echo 'result=' . $result;	
	while ($row = $result->fetch()) {
echo $row['sku'] . '<br>';
		insertSOBI($row);
	}

	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
}	

function insertSOBI($pack) {
	global $db_handle;
	
//	$sql = 'select * from product_boms where parent_sku=?';
	$sql = 'select * from sales_order_items where sku=?';
//echo $sql;	
	$result = $db_handle->prepare($sql);			
	$result->execute(array($pack['sku']));
	while ($soi = $result->fetch()) {
echo '> ' . $soi['sku'] . '<br>';
		
		$sql = 'select * from product_boms where parent_sku=?';
		$result2 = $db_handle->prepare($sql);			
		$result2->execute(array($pack['sku']));
		while ($bom = $result2->fetch()) {
echo ' > > ' . $bom['sku'] . '<br>';

			$sql = 'select * from products where sku=?';
			$result3 = $db_handle->prepare($sql);			
			$result3->execute(array($bom['sku']));
			$product = $result3->fetch();

			$sql = 'insert into sales_order_bom_items set soi_id=?, sku=?, title=?, sub_type=?, price=?, digital=?, qty=?';
//echo $sql . '<br>';					
			$result4 = $db_handle->prepare($sql);			
			$result4->execute(array($soi['id'], $product['sku'], $product['title'], $product['sub_type'], $product['price'], $product['digital'], $bom['qty']));


		}


		
//		$sql = 'insert into sales_order_bom_items (soi_id, sku, title, sub_type, price, digital, qty)
//					select ?, sku, ?, ?, ?, ?, qty from product_boms 
//					where parent_sku=?';
//echo $sql . '<br>';					
//		$result2 = $db_handle->prepare($sql);			
//		$result2->execute(array($soi['id'], 'title', 9, 9, 9, $product['sku']));
		
//		insertSOBI($row);
	}
}	
?>