function printCheck() {
	if ($('#so-print').hasClass('disabled'))
		return;

	var year = document.getElementById('so-date-created').dateValue.substr(0,4);
	var sql = 'call get_donation_value(' + global.customerID + ',' + year + ')';
	execSQL(sql, function(data) { 
		getPrintOptions();
	});
}

function getPrintOptions() {
	if (global.isUK)
		var dearPerson = $('#salutation').val() + ' ' + $('#last-name').val();
	else
		var dearPerson = document.getElementById('first-name').value;
	
	getData('salesOrderLinesPrint', document.getElementById('so-id').innerHTML, function(data) { 
		var donationData = new getSODonations(data);
		var isDonation = (donationData.amount > oSettings.donation_min_amount) ? 'checked' : 'disabled';
		var isGift = isPotentialGift() ? '' : ' disabled ';
		var boxContent = '<label><input id="print-option-a" type="checkbox" checked>Sales Order</label>';
		
		if (global.isUK) {
			boxContent +=
				'<br><label><input id="print-option-c" type="checkbox"' + isDonation + '>Thank You Letter</label>' +
				'<br><span style="margin-left:34px">-- Dear <input id="dear-person" type="text" value="' + dearPerson + '"></span>';
		}
		else {
			boxContent +=
				'<br><label><input id="print-option-c" type="checkbox"' + isDonation + '>Official Donation Tax Receipt</label>' +
				'<br><span style="margin-left:34px">-- Dear <input id="dear-person" type="text" value="' + dearPerson + '"></span>' +
				'<br><label style="margin-left:25px"><input value="" type="radio" name="odtr-type" checked>First Issue</label>' +
				'<br><label style="margin-left:25px"><input value="* DUPLICATE *" type="radio" name="odtr-type">Duplicate</label>' +
				'<br><label style="margin-left:25px"><input value="* AMENDED *" type="radio" name="odtr-type">Amended</label>';
		}
		boxContent +=
			'<br><label><input id="print-option-d" type="checkbox">Label-Billing Address</label>' +
			'<br><label><input id="print-option-e" type="checkbox">Label-Shipping Address</label>' +
			'<br><label><input id="print-option-f" type="checkbox"' + isGift + '>Gift Recipient Slip</label>';

		// establish if this is a new customer, i.e. this is the first sales order
		var sql = 'select * from sales_orders where customer_id="' + global.customerID + '"';
		execSQL(sql, function(soData) {	
			var newCustomer = (soData.length == 1);
			confirmBox(
				'PRINT OPTIONS',
				boxContent,
				["PRINT"],
				[ function() { printDocs(data, donationData, newCustomer); } ]
			);																			
		});

	});
}

function getSODonations(data) {
	var total = 0;
	this.giftAid = false;
	
	for (var x in data) {
		if (data[x][SOP_TYPE] == 'D' && data[x][SOP_SUBTYPE] != 'X')	{	// 'X' = non-receiptable
			total += data[x][SOP_QTY] * data[x][SOP_PRICE];
			this.giftAid = (data[x][SOP_GIFT_AID] == 1);		// the last value read applies to the whole UK thank-you letter (strange but true)
		}
	}	
	
	this.amount = total;
}

function printDocs(orderLines, donationData, newCustomer) {	
	var options = [
		document.getElementById('print-option-a').checked, 
		document.getElementById('print-option-c').checked, 
		document.getElementById('print-option-d').checked,			
		document.getElementById('print-option-e').checked,
		document.getElementById('print-option-f').checked
	];				
	var odtrType = getRadioValue('odtr-type');					// donation receipt = first issue | duplicate | amended
	var dearPerson = document.getElementById('dear-person').value;
					
	var noDocs = true;
	
	if (options[0]) {		// sales order
		$('#customer-form').hide();
		$('#sop-container').show();
		printSO(1, orderLines); 
		if (global.isUK) {
			$('#sop-oc').show();
			$('#sop-oc-admin-area').show();
			printSO(2, orderLines, newCustomer); 
		}
		noDocs = false;

		createBOSlips();
	}
	
	if (options[1]) {		// thank you letter/donation receipt
		$('#customer-form').hide();
		if (global.isUK) {
			$('#uk-thank-you-letter').show();
			printUKDonationReceipt(dearPerson, donationData.amount, donationData.giftAid);
		}
		else {
			$('#donation-receipt').show();
//			var year = document.getElementById('so-date-created').dateValue.substr(0,4);
			var year = $('#so-payment-date').val().substr(0,4);
			printDonationReceipt(odtrType, donationData.amount, dearPerson, year); 
		}
		noDocs = false;
	}
	
	if (options[2]) {
		printLabel('b');		// billing address
//			noDocs = false;
	}
	
	if (options[3]) {
		printLabel('s');		// shipping address
//			noDocs = false;
	}
		
	if (options[4]) {			// gift recipient packing slip
		$('#customer-form').hide();
		noDocs = false;
		createGiftSlip();
	}
		
	if (!noDocs)
		setTimeout(function() {	// to give time to let embedded images load, e.g. CCCC in CA thankyou letter
			window.print();		
			$('#customer-form').show();
			$('#sop-container').hide();
			$('#donation-receipt').hide();			
			$('#uk-thank-you-letter').hide();		
			$('#sop-gift').hide();
		}, 100);
}

// if there is a different shipping address to main customer address, it may be a gift
function isPotentialGift() {
	for (var x=1; x<8; x++) {
		if ($('#so-ship-address-' + x).val() != '')
			return true;
	}
	
	return false;
}

function createGiftSlip() {
	$('#sop-gift-header').html('');
	insertDocHeader('sop-gift-header', null, 'GIFT SLIP', '#' + $('#so-id').html(), $('#so-date-created').html());

	$('#sop-gift-addressee').html('To: ' + $('#so-ship-address-1').val() + ' ' + $('#so-ship-address-2').val());
	
	var products = '';
	for (var x in oSalesOrder.basket) {
		products += 
			'<div class="sop-row">' +
				'<div class="sop-sku">' + oSalesOrder.basket[x].sku + '</div>' +
				'<span>' + oSalesOrder.basket[x].qty + 'x </span>' +
				'<div class="sop-title">' + oSalesOrder.basket[x].title + '</div>' +
			'</div>';
	}
	$('#sop-gift-order-lines').html(products);

	var note = $('#so-notes').val() == '' ? 'This is a gift from ' + ($('#first-name').val() + ' ' + $('#last-name').val() + ' ' + $('#organization').val()) : $('#so-notes').val();
	$('#sop-gift-note').html(note);
	
	$('#sop-gift').show();
}

function createBOSlips() {
	var content = '';
	$('#sop-back-order').html(content);

	for (var x in oSalesOrder.basket) {
		if (oSalesOrder.basket[x].backOrder == 1) {
			content = $('#sop-back-order').html();
			$('#sop-back-order').html(content + '<div class="page-break"></div>');

			insertDocHeader('sop-back-order', null, 'BACK ORDER SLIP', '#' + $('#so-id').html(), $('#so-date-created').html());

			var address = 
				'<div id="back-order-address" style="margin-top: 70px">' +
					'<div class="sop-label">CUSTOMER ADDRESS:</div>' +
						$('#first-name').val() + ' '  + $('#last-name').val() + '<span style="float: right">ID:' + strZero(global.customerID, 6) + '</span><br>' +
						$('#address').val() + '<br>' + 
						$('#address-2').val() + '<br>' +
						$('#city').val() + '<br>' + 
						$('#postal-code').val() + '<br>' +
						$('#country').val() +
					'</div>' +
				'</div>';

			content = $('#sop-back-order').html();
			$('#sop-back-order').html(content + address);
			
			var product = 
				'<br><br><br><br><br><br>' +
				'<div style="font-size: 25px;">' +
					'<img src="images/back-order.png" style="width:25px; margin-right: 20px; vertical-align; bottom">' +
					oSalesOrder.basket[x].sku + '   ' +
					oSalesOrder.basket[x].qty + 'x ' +
					oSalesOrder.basket[x].title +
				'</div>' +
				'<br><br><br><br>';
			content = $('#sop-back-order').html();
			$('#sop-back-order').html(content + product);

			var text = '<div style="margin-top: 20px; border: 1px solid gray; padding: 10px;">' + oSettings.back_order_slip_text + '</div>';
			content = $('#sop-back-order').html();
			$('#sop-back-order').html(content + text);
		}
	}
	
	$('#sop-back-order').show();
}

// mode 1=customer copy, 2=office copy (UK)
function printSO(mode, data, newCustomer) {
//console.log('x=',data)
	var bookValue = 0, dvdValue = 0;
	var prefix = (mode == 1) ? 'sop-' : 'sop-oc-';
	var isBO = false;		// no back orders
	
	$('#' + prefix + 'header').html('');
	if (global.isUK && mode == 2)		// uk wants large print s/order number for those with poor eyes (for filing)
		insertDocHeader(prefix + 'header', null, 'SALES ORDER #' + $('#so-id').html(), '', $('#so-date-created').html());
	else
		insertDocHeader(prefix + 'header', null, 'SALES ORDER', '#' + $('#so-id').html(), $('#so-date-created').html());
		
	document.getElementById(prefix + 'billing-address-1').innerHTML = document.getElementById('salutation').value + ' ' + document.getElementById('first-name').value + ' ' + document.getElementById('last-name').value;
	document.getElementById(prefix + 'billing-address-2').innerHTML = document.getElementById('organization').value;
	document.getElementById(prefix + 'billing-address-3').innerHTML = document.getElementById('address').value;
	document.getElementById(prefix + 'billing-address-4').innerHTML = document.getElementById('address-2').value;

	$('#sop-customer-id').html('ID:' + strZero(global.customerID, 6));
	
	if (global.isUK) {
		$('#sop-oc-customer-id').html('ID:' + strZero(global.customerID, 6));
		document.getElementById(prefix + 'billing-address-5').innerHTML = document.getElementById('city').value + '<br>'  + document.getElementById('postal-code').value;
		
		// for warehouse shipping system
		$('#sop-uk-phone-details-office-copy').show();		
		$('#sop-oc-phone').html($('#phone1').val());
		$('#sop-oc-email').html($('#email1').val());		

		// new customer must get welcome pack
		if (newCustomer)
			$('#sop-oc-welcome-pack').show();
		
		$('#sop-updated-by').html(oSalesOrder.updated_by);

		document.getElementById(prefix + 'billing-address-6').innerHTML = document.getElementById('country').value;
	}
	else {
		document.getElementById(prefix + 'billing-address-5').innerHTML = document.getElementById('city').value + ', ' + document.getElementById('province').value + ', ' + document.getElementById('postal-code').value;
		var country = $('#country').val();
		if (country.toUpperCase() == oSettings.country.toUpperCase())	// don't state the obvious
			country = '';
		document.getElementById(prefix + 'billing-address-6').innerHTML = country;
	}
		
	document.getElementById(prefix + 'ship-address-1').innerHTML = document.getElementById('so-ship-address-1').value;
	document.getElementById(prefix + 'ship-address-2').innerHTML = document.getElementById('so-ship-address-2').value;
	document.getElementById(prefix + 'ship-address-3').innerHTML = document.getElementById('so-ship-address-3').value;
	document.getElementById(prefix + 'ship-address-4').innerHTML = document.getElementById('so-ship-address-4').value + ', ' + document.getElementById('so-ship-address-5').value + ', ' + document.getElementById('so-ship-address-6').value;
	document.getElementById(prefix + 'ship-address-5').innerHTML = document.getElementById('so-ship-address-7').value;

	// test if there is a shipping address; don't show the box if there is no address
	var isBlank = true;
	$('#' + prefix + 'ship-address').show();
	for (var x=1; x<8; x++) {
		var val = document.getElementById('so-ship-address-' + x).value;
		if (val != '') {
			isBlank = false;
			break;
		}
	}
	if (isBlank)
		$('#' + prefix + 'ship-address').hide();
	
	document.getElementById(prefix + 'total').innerHTML = xtFormatCurrency(document.getElementById('so-total').innerHTML);
	var paymentMethod = document.getElementById('so-payment-type').value;
	
	// show breakdown of payment types and amounts, if feature enabled
	if (oSettings.use_multiple_payment_types == 1) {
		var paymentMethod = '';
		for (var x=1; x<7; x++) {
			if ($('#so-popts-amt-' + x).val() != 0)
				paymentMethod += $('#so-popts-type-' + x).val() + ' (' + $('#so-popts-amt-' + x).val() + ') ';
		}
	}

	document.getElementById(prefix + 'payment-method').innerHTML = paymentMethod;
	document.getElementById(prefix + 'add-info').innerHTML = document.getElementById('so-add-info').value;	
	document.getElementById(prefix + 'payment-date').innerHTML = formatDate($('#so-payment-date').val(), 2);
	document.getElementById(prefix + 'notes').innerHTML = document.getElementById('so-notes').value;	
	document.getElementById(prefix + 'footer').innerHTML = oSettings.sales_order_footer;

	// order lines
	var line, text, title, magSubName;
	
	document.getElementById(prefix + 'order-lines').innerHTML = '';
	line = document.createElement('div');
	document.getElementById(prefix + 'order-lines').appendChild(line);
	line.className = 'sop-row';
	
	text = "<div class='sop-sku sop-label'>SKU</div>";
	text += "<div class='sop-title sop-label'>TITLE</div>";
	text += "<div class='sop-price sop-label'>PRICE</div>";
	text += "<div class='sop-qty sop-label'>QTY</div>";
	text += "<div class='sop-line-total sop-label'>TOTAL</div>";
	line.innerHTML = text;

	for (var x in data) {
		line = document.createElement('div');
		document.getElementById(prefix + 'order-lines').appendChild(line);
		line.className = 'sop-row';
		if (global.isUK && (data[x][SOP_DIGITAL] == 1 || data[x][SOP_TYPE] == 'M' || data[x][SOP_TYPE] == 'D'))
			$(line).addClass('sop-gray-out-no-pick');
		
//		$(line).addClass('bob');

		// are there any back orders?
		var boFlag = ''
		if (data[x][SOP_BACK_ORDER] == '1') {		// yes
			boFlag = '**' ;
			isBO = true;
		}

		text = "<div class='sop-sku'>" + data[x][0] + boFlag + "</div>";
		
		// product title, and if its a mag also show the recipient name (but only show name if it's a gift)
		magSubName = '';
		title = data[x][SOP_TITLE];
		if (data[x][SOP_TYPE] == 'M' && data[x][5] != 0 && data[x][SOP_RECIPIENT_ID] != global.customerID) {
			magSubName = ' - ' + data[x][6];
		}
		
		text += "<div class='sop-title'>" + title + magSubName + "</div>";
		text += "<div class='sop-price'>" + xtFormatCurrency(data[x][SOP_PRICE]) + "</div>";
		text += "<div id=" + ('sop-qty-'+ x) + " class='sop-qty'>" + data[x][SOP_QTY] + "</div>";
		text += "<div class='sop-line-total'>" + xtFormatCurrency(data[x][SOP_QTY] * data[x][SOP_PRICE]) + "</div>";

//text += '<div style="border-bottom: 1px dotted black"></div>';		
		
		line.innerHTML = text;
		
		// emphasize qty >1
		if (data[x][SOP_QTY] > 1) {
			if (global.isUK) {
				if (mode == 2) 
					$(line).addClass('sop-highlight');
			}
			else 
				$('#sop-qty-' + x).addClass('sop-qty-highlight');
		}
		
		if (x > 0 && oSettings.sales_order_gridlines == 1)
			$(line).addClass('sop-gridlines');
			
		// explode any packs to show the bom items
		var bomItems = data[x][SOP_BOM_ITEMS];
		var bomPrices = data[x][SOP_BOM_PRICES];
		var bomSubTypes = data[x][SOP_BOM_SUB_TYPES];
		var bomQtys = data[x][SOP_BOM_QTYS];
		var bomBook = 0;
		var bomNonBook = 0;
		var isBOM = false;
		
		for (var i in bomItems) {
			isBOM = true;
			line = document.createElement('div');
			document.getElementById(prefix + 'order-lines').appendChild(line);
			line.className = 'sop-bom-item';
			line.innerHTML = '&bull; '  + bomQtys[i] + 'x ' + bomItems[i];
			if (global.isUK && (data[x][SOP_DIGITAL] == 1 || data[x][SOP_TYPE] == 'M' || data[x][SOP_TYPE] == 'D'))
				$(line).addClass('sop-gray-out-no-pick');

			// highlight qty > 1 for packing document
			if (mode == 2 && bomQtys[i] > 1) 
				$(line).addClass('sop-highlight');

			// accumulate prices for bom items to go in uk 'office use' box
			if (bomSubTypes[i] == 'B')
				bomBook += data[x][SOP_QTY] * bomPrices[i];
			if (bomSubTypes[i] == 'N')
				bomNonBook += data[x][SOP_QTY] * bomPrices[i];
		}
		
		// inventory values for uk 'office use' box
		if (data[x][SOP_TYPE] == 'P' && data[x][SOP_DIGITAL] == 0 && !isBOM) {
			if (data[x][SOP_SUBTYPE] == 'B')
				bookValue += data[x][SOP_QTY] * data[x][SOP_PRICE];
			if (data[x][SOP_SUBTYPE] == 'N')
				dvdValue += data[x][SOP_QTY] * data[x][SOP_PRICE];
		}
		bookValue += bomBook;
		dvdValue += bomNonBook;
	}
	
	// if there are back orders, add a note to that effect
	var footer = $('#' + prefix + 'footer').html();
	if (isBO) {
		footer += '<p>** These items are out of stock and will be sent to you as soon as they become available.</p>';
		$('#' + prefix + 'footer').html(footer);

		// add items to back order notes box
		var items = '';
		for (var x in oSalesOrder.basket) {
			if (oSalesOrder.basket[x].backOrder == 1)
				items += oSalesOrder.basket[x].sku + ' ' + oSalesOrder.basket[x].title + '  (x' + oSalesOrder.basket[x].qty + ')<br>';
		}
		$('#sop-bo-notes').html(items);
	}
	
	// uk only
	$('#sop-admin-area-book').html(xtFormatCurrency(bookValue));
	$('#sop-admin-area-dvd').html(xtFormatCurrency(dvdValue));
}

//------ DONATION RECEIPT ------------------------------------------
// CA receipt
function printDonationReceipt(odtrType, amount, dearPerson, year) {
	$('#don-header').html('');
	insertDocHeader('don-header', null, 'DONATION RECEIPT', 'Receipt #' + $('#so-id').html(), 'Date issued: ' + $('#so-date-created').html());

	document.getElementById('don-receipt-type').innerHTML = odtrType;
	
	document.getElementById('don-ship-address-1').innerHTML = document.getElementById('salutation').value + ' ' + document.getElementById('first-name').value + ' ' + document.getElementById('last-name').value;
	document.getElementById('don-ship-address-2').innerHTML = document.getElementById('organization').value;
	var address = $('#address').val() + ($('#address-2').val() != '' ? '<br>' + $('#address-2').val() : '');	
	document.getElementById('don-ship-address-3').innerHTML = address;
	document.getElementById('don-ship-address-4').innerHTML = document.getElementById('city').value + ', ' + document.getElementById('province').value + ', ' + document.getElementById('postal-code').value;

	var country = $('#country').val();
	if (country.toUpperCase() == oSettings.country.toUpperCase())	// don't state the obvious
		country = '';
	document.getElementById('don-ship-address-5').innerHTML = country;
	
	document.getElementById('don-total').innerHTML = '$' + formatCurrency(amount);
	document.getElementById('don-tax-year-value').innerHTML = year;
	
	$('#don-footer').html(oSettings.donation_receipt_footer);
	
	document.getElementById('don-rf-note').innerHTML = 'Dear ' + dearPerson + ',<br><br>' + oSettings.donation_letter;
}

// UK receipt
function printUKDonationReceipt(dearPerson, amount, giftAid) {
	var initial = $('#first-name').val() == '' ? '' : $('#first-name').val()[0];
	var address = $('#address').val() + ($('#address-2').val() != '' ? '<br>' + $('#address-2').val() : '');
	
	$('#uk-don-address-1').html($('#salutation').val() + ' ' +  initial + ' ' + $('#last-name').val());	// initial only for first name
	$('#uk-don-address-2').html($('#organization').val());
	$('#uk-don-address-3').html(address);
	$('#uk-don-address-4').html($('#city').val() + '<br>' + $('#postal-code').val());

	var isUKCustomer = (oSettings.country.toUpperCase() == $('#country').val().toUpperCase());
	if (isUKCustomer)
		$('#uk-don-address-5').html('');
	else
		$('#uk-don-address-5').html($('#country').val());
	
	$('#uk-don-date').html(formatDate(today(), 3));
	$('#uk-don-id').html(global.customerID);
	$('#uk-don-gift-aid-text').hide();
	$('#uk-don-amount').html(xtFormatCurrency(amount));
	if (giftAid)
		$('#uk-don-gift-aid-text').show();

	$('#uk-don-note').html('Dear ' + dearPerson + ',<br><br>' + oSettings.donation_letter);
}