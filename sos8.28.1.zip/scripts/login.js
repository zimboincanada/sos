//-- start login bits
oLogin = new login();

function login() {
	var thisObject = this;
	
	this.navItems = [
		{	// root
		},
		{ 	id: '1',
			title: "Customers",
			icon: 'customers-icon.png',
			target: 'customer-grid.html?menu=customers'
		}, 
		{
			id: '2',
			title: "Reports",
			icon: 'reports-icon.png',
			target: 'reports.html?menu=reports',
			children: [{
				id: '2-1',
				title: "General"
			}, {
				id: '2-2',
				title: "Mailing lists"
			}, {
				id: '2-3',
				title: "CA reports"
			}, {
				id: '2-4',
				title: "UK reports"
			}]
		}, 
		{
			id: '3',
			title: "Settings",
			icon: 'preferences-icon.png',
			target: 'settings.html?menu=settings',
			children: [{
				id: '3-1',
				title: "General"
			}, {
				id: '3-2',
				title: "Shipping"
			}, {
				id: '3-3',
				title: "Drop down lists"
			}, {
				id: '3-4',
				title: "Sales orders"
			}, {
				id: '3-5',
				title: "Donations"
			}, {
				id: '3-6',
				title: "Subscriptions"
			}, {
				id: '3-7',
				title: "Daily sales summary"
			}, {
				id: '3-8',
				title: "EPIC"
			}, {
				id: '3-9',
				title: "Inventory"
			}]
		}, 
		{
			id: '4',
			title: "Utilities",
			icon: 'utilities-icon.png',
			target: 'utilities.html?menu=utilities',
			children: [{
				id: '4-1',
				title: "Recurring donations"
			}, {
				id: '4-2',
				title: "System recovery"
			}, {
				id: '4-3',
				title: "Backup database"
			}, {
				id: '4-4',
				title: "Find a customer"
			}, {
				id: '4-5',
				title: "Subscriptions count"
			}, {
				id: '4-6',
				title: "Export Orders (for shipping)"
			}, {
				id: '4-7',
				title: "Lock Sales Orders"
			}, {
				id: '4-8',
				title: "Software update"
			}, {
				id: '4-9',
				title: "Reset 'Courtesy Call' flags"
			}]
		}, 
		{
			id: '5',
			title: "Inventory",
			icon: 'inventory-icon.png',
			target: 'inventory.html?menu=inventory',
			children: [{
				id: '5-1',
				title: "Purchase Orders"
			}, {
				id: '5-2',
				title: "Adjust"
			}, {
				id: '5-3',
				title: "Stock take"
			}, {
				id: '5-4',
				title: "Upload products"
			}, {
				id: '5-5',
				title: "Suppliers"
			}, {
				id: '5-6',
				title: "Product maintenance"
			}, {
				id: '5-7',
				title: "S2 product map"
			}]
		}, 
		{
			id: '6',
			title: "Users",
			icon: 'users-icon.png',
			target: 'user-maintenance.html?menu=users'
		}, 
		{
			id: '7',
			title: "Picklists",
			icon: 'reports-icon.png',
			target: 'reports.html?menu=reports',
			children: [{
				id: '7-1',
				title: "Create picklist"
			}, {
				id: '7-2',
				title: "Event returns"
			}, {
				id: '7-3',
				title: "Picklist maintenance"
			}]
		}, 
		{
			id: '8',
			title: "EPIC",
			icon: 'mini-icon.png',
			target: 'mini.html?menu=epic',
			children: [{
				id: '8-1',
				title: "Churches"
			}, {
				id: '8-2',
				title: "Events"
			}, {
				id: '8-3',
				title: "Tours"
			}, {
				id: '8-4',
				title: "Web export"
			}, {
				id: '8-5',
				title: "Talks"
			}, {
				id: '8-6',
				title: "Document templates"
			}, {
				id: '8-7',
				title: "Speakers"
			}]
		}];
		
//console.log(this.navItems)
	
	// CB - classic style is under development
	this.setMenuStyle = function(type) {
		var obj = this;
		
		$('#header-menu-sticky').hide();
		$('#header-menu-classic').hide();
		
		if (type == 'sticky')
			$('#header-menu-sticky').show();
		
		if (type == 'classic') {
			$('#system-icon').on('mouseover', function() { $("#header-menu-classic").show(); });
			
			for (var x in this.navItems) {
				if (x == 0) continue;

				var item = document.createElement('div');
				document.getElementById('bob').appendChild(item);
//console.log(item, this.navItems[x].children, this.navItems[x].children == undefined)
				
				var icon = '<img style="width: 25px" src=images/' + this.navItems[x].icon + '>';		// icon
				var text = '<span style="vertical-align: top;  padding-left: 5px">' + this.navItems[x].title + '</span>';		// menu text
				
				if (this.navItems[x].children == undefined)
					var moreMenu = '';
				else		// nested menu
					var moreMenu = '<span style="float: right; padding-left: 10px">&#9654;</span>';
				
				item.innerHTML =  icon + text + moreMenu;
				item.pageToLoad = this.navItems[x].target;
				item.nestedItem = this.navItems[x].children;
				item.className = 'header-menu-item';
				$(item).on('mouseover', function() { obj.menuLevel2(this.nestedItem) });
				$(item).on('click', function() { window.location.href = this.pageToLoad });
//console.log(this.navItems[x][1]);
//	<div onmouseover='menuLevel2(2)' class='header-menu-item' href='reports.html?menu=reports'><img src='images/reports-icon.png' style='width: 25px'><span style='vertical-align: top;  padding-left: 5px'>Reports<span style='float: right; padding-left: 10px'>&#9654;</span></span></div>
			}
		}
	}
	
this.menuLevel2 = function(item) {
	var menu = '';
//console.log(item)

	for (var x in item) {
console.log(item[x])
//menu += item[x][0];
//			menu += "<div class='header-menu-item' href='customer-grid.html?menu=customers'><span style='vertical-align: top; padding-left: 5px'>General</span></div>"
			menu += "<div class='header-menu-item' onclick='" + item[x].target + "'><span style='vertical-align: top; padding-left: 5px'>" + item[x].title + "</span></div>"
//console.log(menu)
	}
	
	$('#header-menu-classic-level-2').html(menu);
}

	// enables menu options
	// mode: 1=index page, 2=other pages
	this.setMenuRights = function(mode) {
		
		oLogin.setMenuStyle('sticky');
//buildBob();		
//		oLogin.setMenuStyle('classic');
		
		if (oLogin.hasMenuRights('1'))	{	// customers
//			$('#index-menu-1').show();
			if (mode == 1)
				this.addIndexMenuItem(1);
			else
				this.addMenuItem(1);
//			$('#header-menu-customers').css('display', 'block').show();
		}	
		
		if (oLogin.hasMenuRights('2')) {		// reports
//			$('#index-menu-2').show();
			if (mode == 1)
				this.addIndexMenuItem(2);
			else
				this.addMenuItem(2);
//			$('#header-menu-reports').css('display', 'block').show();
		}
		
			// reports sub-menu options
			for (var x = 1; x<5; x++) {
				var id = '2-' + x;
				if (oLogin.hasMenuRights(id))
					$('#reports-label-' + x).css('display', 'block').show();			
			}
			
		if (oLogin.hasMenuRights('3')) {		// settings
//			$('#index-menu-3').show();
			if (mode == 1)
				this.addIndexMenuItem(3);
			else
				this.addMenuItem(3);
//			$('#header-menu-settings').css('display', 'block').show();
		}
		
			// settings sub-menu options
			for (var x = 1; x<10; x++) {
				var id = '3-' + x;
				if (oLogin.hasMenuRights(id))
					$('#settings-label-' + x).css('display', 'block').show();			
			}
			if (global.isUK)
				$('#settings-label-7').css('display', 'block').hide();
			
		if (oLogin.hasMenuRights('4')) {		// utilities
//			$('#index-menu-4').show();
			if (mode == 1)
				this.addIndexMenuItem(4);
			else
				this.addMenuItem(4);
//			$('#header-menu-utilities').css('display', 'block').show();
		}
		
			// utilities sub-menu options
			for (var x = 1; x<10; x++) {
				var id = '4-' + x;
				if (oLogin.hasMenuRights(id)) {
					$('#utilities-label-' + x).css('display', 'block').show();			

	//				if (x == 8 && !oSettings.s2active)		// s2 test harness
	//					$('#utilities-label-' + x).css('display', 'block').hide();			

					if (x == 9 && global.isUK)	// courtesy call reset only for CA
						$('#utilities-label-' + x).css('display', 'block').hide();			
				}
			}

		if (oLogin.hasMenuRights('5'))	{	// inventory
//			$('#index-menu-5').show();
			if (mode == 1)
				this.addIndexMenuItem(5);
			else
				this.addMenuItem(5);
//			$('#header-menu-inventory').css('display', 'block').show();		
		}
			
			// inventory sub-menu options
			for (var x = 1; x<8; x++) {
				var id = '5-' + x;
				if (oLogin.hasMenuRights(id))
					$('#inventory-label-' + x).css('display', 'block').show();			
			}
			
		if (oLogin.hasMenuRights('6'))	{	// user maintenance
//			$('#index-menu-6').show();
			if (mode == 1)
				this.addIndexMenuItem(6);
			else
				this.addMenuItem(6);
		}

		if (oLogin.hasMenuRights('7'))	{	// speakers picklists
	//		$('#index-menu-7').show();
//			this.addIndexMenuItem(7);
	//		$('#header-menu-speakers').css('display', 'block').show();		
		}
		
			// speakers sub-menu options
			for (var x = 1; x<4; x++) {
				var id = '7-' + x;
	//			if (oLogin.hasMenuRights(id))
	//				$('#speakers-label-' + x).css('display', 'block').show();			
			}
		
		if (oLogin.hasMenuRights('8'))	{	// minimax
//			$('#index-menu-8').show();
			if (mode == 1)
				this.addIndexMenuItem(8);
			else
				this.addMenuItem(8);
//			$('#header-menu-mini').css('display', 'block').show();		
		}
		
			// minimax sub-menu options
			for (var x = 1; x<8; x++) {
				var id = '8-' + x;
				if (oLogin.hasMenuRights(id))
					$('#mini-label-' + x).css('display', 'block').show();			
			}
	}
	
	this.addIndexMenuItem = function(number) {	
		var item = document.createElement('div');
		document.getElementById('index-menu').appendChild(item);
		$(item).css('display', 'inline-block');
		
		var target = document.createElement('a');
		item.appendChild(target);
		target.href = this.navItems[number].target;
		
		var img = document.createElement('img');
		target.appendChild(img);
		img.src = 'images/' + this.navItems[number].icon;
		img.className = 'menu-icon shadow';
		
		var title = document.createElement('div');
		target.appendChild(title);
		$(title).html(this.navItems[number].title);
		
		$(item).show();
	}
	
	this.addMenuItem = function(number) {	
//	<a id='header-menu-customers' class='header-sub-menu-item' href='customer-grid.html?menu=customers'><img src='images/customers-icon.png' style='width: 25px'><span style='vertical-align: top; padding-left: 5px'>Customers</span></a>
	
//		var item = document.createElement('div');
//		document.getElementById('header-sticky-menu').appendChild(item);
//		$(item).css('display', 'inline-block');
		
		var target = document.createElement('a');
		document.getElementById('header-sticky-menu').appendChild(target);
		target.href = this.navItems[number].target;
		target.className = 'header-sub-menu-item';
		target.id = 'header-menu-' + this.navItems[number].title.toLowerCase();
//		target.id = 'header-menu-customers';
//console.log(target)
		$(target).css('display', 'block');
		
		var img = document.createElement('img');
		target.appendChild(img);
		img.src = 'images/' + this.navItems[number].icon;
//		img.className = 'menu-icon shadow';
		
		var title = document.createElement('span');
		target.appendChild(title);
		$(title).html(this.navItems[number].title);
		
		$(target).show();
	}
	
	this.checkForNewRelease = function() {
//console.log('checking for release...')
		$.ajax({
			type: 'get',
			url: "scripts/software-update.php",
			cache: false,
			data: { 
				func: 'getReleaseInfo',
				version: global.releaseNumber
			},
			success: function(result) { 
				if (result.isNewRelease) {
//					$('#footer-new-release-alert').css('display', 'inline-block').show();
					$('#header-release-alert').show();
				}
			},
			error: function(xhr) {
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});		
	}

	this.setupTimer = function(set) {
		if (set) {
			this.logoffWarningGiven = false;	
			this.timer = setInterval(function() {
				logoutTimerCheck();
			}, 1000);		// every second
			
			this.extendLife();
			
			$("body").bind("keypress click", function () {
				thisObject.extendLife();
			}); 	
		}
		else
			clearInterval(this.timer);
	}		

	this.extendLife = function() {
		var d = new Date();
		var currentTime = d.getTime();
		
		var loginTimeout = Number(currentTime + (oSettings.login_timeout * 60000));
	
		localStorage.setItem("loginTimeout", loginTimeout);	
//console.log(loginTimeout)
	}
		
	// determine if user has access to a specific menu option
	this.hasMenuRights = function(option) {
		for (var x in this.menuRights) {
			if (this.sys_admin == 1 || this.menuRights[x] == option) {
				return true;
			}
		}
		return false;
	}	
	
	this.getFirstVisibleTabByClass = function(classname) {
		var s0 = $('.' + classname + ':visible:first');
		var s1 = s0[0].id;
		var s2 = s1.substr(s1.lastIndexOf('-') + 1);		
		
		return s2;
	}
	
	this.acknowledgeUpgrade = function () {
		var sql = 'update users set read_release_notes="' + global.releaseNumber + '" where login_uid="' + oLogin.uid+ '"';
		execSQL(sql, function() {
			$('#login-new-release-msg').hide();			
		});
	}

	this.initAlerts = function() {
		oSettings.s2active = (oSettings.s2active == 1);

		// check and alert for outstanding s2 updates
		if (oSettings.s2active && oLogin.alert_s2 == 1) {
			var seconds = 5;
			setInterval(function() {
				checkS2PendingUpdates();
			}, seconds * 1000);
		}				
		
		// check and alert for incomplete harvests
		if (oLogin.alert_harvest == 1)
			checkHarvestLog();
		
		// check for any outstanding event todo items
		if (oLogin.alert_todo == 1)
			setInterval(function() {
				checkTodos();
			}, 5 * 1000);		

		if (oLogin.alert_bom == 1)
			setInterval(function() {
				checkEmptyPacks();
			}, 5 * 1000);		
			
		if (oLogin.alert_stock == 1)
			setInterval(function() {
				checkLowStock();
			}, 5 * 1000);		
			
//		oLogin.checkForNewRelease();
	}
}

function xxxxxxxxxxxxxxxxbuildBob() {
//console.log(oLogin.navItems)
	var nav = document.createElement('table');
	$('body').append(nav);
	$(nav).attr('id', 'nav');
//	$(nav).html('bob');
	
	for (var x in oLogin.navItems) {
console.log(oLogin.navItems[x])	
		if (Number.isInteger(x/4)) {
			var navRow = document.createElement('tr');
			$(nav).append(navRow);
		}
		
		var navCell = document.createElement('td');
		$(navRow).append(navCell);
		$(navCell).html(oLogin.navItems[x].title);
		
		for (var y in oLogin.navItems[x].children) {
			var navChild = document.createElement('div');
			$(navCell).append(navChild);
			$(navChild).html(oLogin.navItems[x].children[y].title);
console.log(oLogin.navItems[x].children[y])	
		}
	}
}

function testLogin() {
	var sql = 'select * from users where login_uid="' + $('#login-uid').val() + '"';
	execSQL(sql, function(userData) {
		if (userData.length == 0)		// no user record found
			$('#login-msg').html('login id not found.');
		else if (userData[0].login_pwd == '')
			setupNewPassword();
		else if ($('#login-pwd').val() == userData[0].login_pwd) {	// passwords match			
			localStorage.setItem("currentUser", $('#login-uid').val());
			localStorage.setItem("loggedIn", true);
			$("#no-menu").fadeOut();
			$("#index-menu").fadeIn();
			showLogin(1);
			
			// they should be aware they are not on live, in case the server name has changed
			if (oSettings.s2active && getS2DataSet() == 'test')		
				cb_alert('Be aware that you are using the TEST instance of the S2 database.');			
		}
		else {
			$('#login-msg').html('password is incorrect.');
			$('#login-pwd').val('');
		}
	});
}

function setupNewPassword() {
	$('#password-panel').slideDown();
	document.getElementById('password-1').focus();
}

// mode 1=index page, 2=other pages
function showLogin(mode) {	
	if (mode == 1) {
		$('#login-msg').html('you are logged in.');

		$("#no-menu").hide();
		$("#index-menu").show();

		$('#login-pwd').hide();
		$('#login-btn').hide();
		$('#login-logoff-btn').show();			
	}
	else
		$('#sos-user').html(localStorage.getItem("currentUser"));

	if (oSettings.login_timeout != 0)		// 0=never time out
		oLogin.setupTimer(true);	
	global.user = localStorage.getItem("currentUser");
	oLogin.uid = localStorage.getItem("currentUser");
	
	var sql = 'select * from users where login_uid="' + oLogin.uid + '"';
	execSQL(sql, function(data) {		
		for (var x in data[0])
			oLogin[x] = data[0][x];
		oLogin.menuRights = data[0].menu_rights.split(',');		
		oLogin.setMenuRights(mode);
		oLogin.full_name = data[0].login_full_name;
//console.log(oLogin.full_name, data)
		$('#sos-user').html(oLogin.full_name);
		
		if (global.releaseNumber != oLogin.read_release_notes)
			$('#login-new-release-msg').slideDown();
		
	}, false);
	
	// add list of all users to oLogin; MiniMax needs it to assign ToDos
	var sql = 'select login_uid from users';
	execSQL(sql, function(data) {
		var users = [];
		for (var x in data)
			users.push(data[x].login_uid);
		oLogin.users = users;
//console.log(oLogin)		
	});
}		

function logOffCheck() {
	confirmBox("CONFIRM", 
		"Log out of SOS?", 
		["Yes", "No"],
		[ function() { 
			logOff();
		}, 
		  function() {}
		]
	);
}

function logOff() {
	oLogin.setupTimer(false);	
	
	localStorage.setItem("currentUser", '');
	localStorage.setItem("loggedIn", false);	
	window.location.href = 'index.html';
}

function logoutTimerCheck() {
	var d = new Date();
	var currentTime = d.getTime();

	switch (true) {
		// if user has logged out, all open pages must close
		case localStorage.getItem("loggedIn") == 'false': {
			logOff();
			break;
		}	
		case oLogin.logoffWarningGiven: {		
			if (currentTime < localStorage.getItem("loginTimeout")) {	
				document.body.removeChild(oLogin.cb);
				oLogin.logoffWarningGiven = false;
			}
			else if (oLogin.graceCountdown <= 0)
				logOff();
			else {
				$('#login-grace-period').html(oLogin.graceCountdown);
				oLogin.graceCountdown--;
			}
			break;
		}
		case currentTime > localStorage.getItem("loginTimeout"): {
			logoffWarning();
			break;
		}
		default: {
//console.log(currentTime, localStorage.getItem("loginTimeout"))		
		}
	}
}

function logoffWarning() {
	oLogin.logoffWarningGiven = true;
	oLogin.graceCountdown = 15;	// seconds
	
	oLogin.cb = confirmBox("CONFIRM", 
		"You're about to be logged out of SOS.<br>Do you want to stay logged in?<p> Seconds left: <span id='login-grace-period'>...</span></p>", 
		["Yes", "No"],
		[ function() { 
			oLogin.logoffWarningGiven = false;		
		}, 
		  function() { 
			logOff(); 
		}],
		false		// no close button
	);
}
//-- end login bits