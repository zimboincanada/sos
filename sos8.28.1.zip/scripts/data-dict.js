/*	PRICE BANDS
		1 = standard
		2 = wholesale
		3 = staff
		4 = seminar

	+++
		
	PRODUCT TYPES
		SUB TYPES
			TERM (mags only)
	
	P = product, e.g. book, DVD
		B = book rate
			Booklets
			Comics
			Pamphlets, leaflets
			Mag sub
			Packs (books only)
			Book + DVD same topic
		N = non book rate
			Back issue
			DVD, CD, Bluray
			Calendars, posters, misc
			Downloads (unless book+download are same subject)
			Packs (DVDs only)
			Packs with DVDs incl book
	
	C = custom item, e.g. credit, discount
	
	S = shipping
	
	D = donation
		1 = general fund
		2 = video
		3 = radio
		4 = russian translation
		Y = youth camp
		X = non-receiptable
		
	(mags have 'term')
	M = magazine/journal sub
		P = print
		D = digital
		B = both (print+digital)
		J = journal
			1 = 1 yr
			2 = 2yr
			3 = 3yr
			R = recurring
			
	Magazine status codes
		1=active
		2=suspended (no longer in use)
		3=cancelled
			
+++

	INVENTORY

	PO status values
	0 = open (created and able to add products)
	1 = on order (no more adding products; now ready to receive)
	2 = received (complete)

+++

PRODUCTS
status:	0 = inactive
			1 = active

*/

/* S2 pending updates
C = customer
S = create subscription
R = renew subscription
L = last issue
Q = qty
N = note
X = cancel
D = remove giver (gift recipient now receiving direct)
*/

/* 'CONSTANTS' for use after a getData() | cb_browse() call
*/
// purchase orders
/*
var PO_ID = 0;
var PO_SUPPLIER_NAME = 1;
var PO_ORDER_DATE = 2;
var PO_RECEIVE_DATE = 3;
var PO_PRINT = 4;
*/

// products
/*
var P_SKU = 0;
var P_MORE_INFO = 1;
var P_TITLE = 2;
var P_QTY = 3;
//var P_BOM = 4;
var P_PRICE = 4;
var P_TYPE = 5;
var P_SUBTYPE = 6;
var P_TERM = 7;					// applies to mags only
var P_SHIPPING_CALC = 8;
var P_DIGITAL = 9;
var P_S2_ID = 10;
var P_ALT_PRICE = 11;		// special | wholesale | staff
var P_FROM = 12;					// alternate price valid date range (from/to)
var P_TO = 13;
*/

// settings
var S_PAYMENT_METHOD = 3;
var S_SO_SOURCE = 4;
var S_CMI_ADDRESS_1 = 6;
var S_CMI_ADDRESS_2 = 7;
var S_CMI_ADDRESS_3 = 8;
var S_CMI_ADDRESS_4 = 9;
var S_CMI_ADDRESS_5 = 10;
var S_CMI_ADDRESS_6 = 11;
var S_SO_FOOTER = 12;
var S_COUNTRY = 13;
var S_BACKUP_FOLDER = 14;
var S_SHIPPING_FOLDER = 15;
var S_DONATION_LETTER = 16;
var S_RECURRING_DONATIONS = 17;
var S_CURRENT_PRINT = 18;
var S_CURRENT_DIGITAL = 19;
var S_CURRENT_JOURNAL = 20;
var S_WELCOME_LETTER = 21;
var S_GIFT_LETTER = 22;
var S_GIFT_RENEWAL_LETTER = 23;
var S_WELCOME_LETTER_J = 24;
var S_GIFT_LETTER_J = 25;
var S_GIFT_RENEWAL_LETTER_J = 26;
var S_TAX_BAND_1 = 27;
var S_TAX_BAND_2 = 28;
var S_TAX_BAND_3 = 29;
var S_TAX_BAND_4 = 30;
var S_TAX_BAND_LABEL_1 = 31;
var S_TAX_BAND_LABEL_2 = 32;
var S_TAX_BAND_LABEL_3 = 33;
var S_TAX_BAND_LABEL_4 = 34;
var S_DONATION_DEFAULT_SOURCE = 35;
var S_CUT_OFF_PERIOD = 36;
var S_SUBS_COUNTRY_CODE = 37;
var S_SUBS_LETTERS_MARGIN = 38;
var S_SUBS_GIFT_RENEWAL_MARGIN = 39;
//var S_CURRENT_ISSUE_SKU = 40;
//var S_CURRENT_J_ISSUE_SKU = 41;
var S_COUNTRIES = 42;
var S_EU_COUNTRIES = 43;
var S_UK_SHIPPING_BAND_1 = 44;
var S_UK_SHIPPING_BAND_2 = 45;
var S_UK_SHIPPING_BAND_3 = 46;
var S_UK_SHIPPING_BAND_4 = 47;
var S_BACKGROUND_IMAGE = 48;
var S_REPORTS_EXCLUDE_PAYMENT_TYPE = 49;
var S_SUBS_MISSED_ISSUES = 50;
var S_CUT_OFF_PERIOD_J = 51;
var S_CUT_OFF_PERIOD_D = 52;
var S_SOURCE_TO_EXCLUDE_SUB = 53;

/*
// customers
var C_FIRST_NAME = 2;
var C_LAST_NAME = 3;
var C_ORGANIZATION = 4;
var C_COUNTRY = 9;
var C_ACCESS_NUMBER = 19;
var C_ACCOUNT_BALANCE = 20;
var C_DATE_ADDED = 21;
var C_DATE_UPDATED = 22;
var C_LOCK = 23;				// record lock
var C_DONATION_VALUE = 24;
var C_GIFT_AID = 25;
var C_ADDRESS_2 = 26;
*/

// sales order items
var SO_PAYMENT_DATE = 11;
var SO_PAYMENT_TYPE_1 = 12;
var SO_PAYMENT_AMOUNT_1 = 13;
var SO_PAYMENT_INFO_1 = 14;
var SO_PAYMENT_TYPE_2 = 15;
var SO_PAYMENT_AMOUNT_2 = 16;
var SO_PAYMENT_INFO_2 = 17;
var SO_PAYMENT_TYPE_3 = 18;
var SO_PAYMENT_AMOUNT_3 = 19;
var SO_PAYMENT_INFO_3 = 20;
var SO_PAYMENT_TYPE_4 = 21;
var SO_PAYMENT_AMOUNT_4 = 22;
var SO_PAYMENT_INFO_4 = 23;
var SO_PAYMENT_TYPE_5 = 24;
var SO_PAYMENT_AMOUNT_5 = 25;
var SO_PAYMENT_INFO_5 = 26;
var SO_PAYMENT_TYPE_6 = 27;
var SO_PAYMENT_AMOUNT_6 = 28;
var SO_PAYMENT_INFO_6 = 29;
var SO_LOCKDOWN = 30;

// sales order items
var SOI_SKU = 0;
var SOI_TITLE = 1;
var SOI_PRICE = 2;
var SOI_TYPE = 3;
var SOI_SUBTYPE = 4;
var SOI_SHIPPING_CALC = 5;
var SOI_QTY = 6;
var SOI_MAG_SUB_ID = 7;
var SOI_RECIPIENT_ID = 8;
var SOI_GIFT_AID = 9;
var SOI_DIGITAL = 10;
var SOI_ID = 11;
var SOI_BACK_ORDER = 12;

// sales order lines print
var SOP_SKU = 0;
var SOP_TITLE = 1;
var SOP_PRICE = 2;
var SOP_QTY = 3;
var SOP_TYPE = 4;
var SOP_SUBTYPE = 7;
var SOP_RECIPIENT_ID = 8;
var SOP_DIGITAL = 9;
var SOP_GIFT_AID = 10;
var SOP_BACK_ORDER = 11;
var SOP_BOM_ITEMS = 12;
var SOP_BOM_PRICES = 13;
var SOP_BOM_SUB_TYPES = 14;
var SOP_BOM_QTYS = 15;

// mag subs (customer tab 3)
var MS_STATUS = 0;		// 0=unassigned, 1=active, 2=suspended, 3=cancelled
var MS_ORDER_DATE = 1;
var MS_QTY_DISPLAY = 2;
var MS_PRODUCT_TITLE = 3;
var MS_RECIPIENT_NAME = 4;
var MS_PRINT = 5;
var MS_FIRST_ISSUE = 6;
var MS_LAST_ISSUE = 7;
var MS_ID = 8;		
var MS_NOTES = 9;
var MS_RECIPIENT_ID = 10;
var MS_SUB_TYPE = 11;
var MS_DIGI_EMAIL = 12;
var MS_QTY = 13;
var MS_TERM = 14;
var MS_ISSUE_STATUS = 15;

/*
// magazine subs
var M_TITLE = 0;
var M_ORDER_DATE = 1;
var M_RECIPIENT = 2;		// customer id
var M_NAME = 3;				// first + last name
var M_ACCESS_NUMBER = 4;
var M_LAST_ISSUE = 5;		// e.g. 37:1
var M_SUBTYPE = 6

// magazine subs received
var SR_RECIPIENT = 0;		// customer id
var SR_ORDER_DATE = 1;
var SR_TITLE = 2;
var SR_NAME = 3;				// first + last name
var SR_DONOR_ID = 4;
var SR_ACCESS_NUMBER = 5;
*/

// recurring donations import
var D_CUST_ID = 0;
var D_CUST_NAME = 1;
var D_AMOUNT = 2;
var D_TXN_DATE = 3;
var D_SOURCE = 4;
var D_PAYMENT_METHOD = 5;
var D_STATE = 6;

// batch recurring donations (utilities)
var RD_CUST_ID = 0;
var RD_FIRST_NAME = 1;
var RD_LAST_NAME = 2;
var RD_AMOUNT = 3;
var RD_SKU = 4;
var RD_GIFT_AID = 5;
var RD_CHECKBOX = 6;
