<?php
	$server = "localhost";
//	$database = "sos_s2";
	$database = "sos";
	$username = "root";
	$password = "";
	
	$db_handle = new PDO("mysql:host=$server;dbname=$database", $username, $password);
	$db_handle -> exec("SET CHARACTER SET utf8");
//	$db_handle->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* list all databases	
$user = 'root';
$pass = '';
$server = 'localhost';

$dbh = new PDO( "mysql:host=$server", $user, $pass );
$dbs = $dbh->query( 'SHOW DATABASES like "%sos%"' );

while( ( $db = $dbs->fetchColumn( 0 ) ) !== false )
{
    echo $db.'<br>';
}
die(0);	
*/
?>