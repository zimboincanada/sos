function cb_browse(parent) {
	this.parent = parent;
	this.fetch = function() {};						// execute this on row click
	this.where = '1';									// select 'where' clause
	this.groupBy = '';									// select 'group by' clause
	this.checkBox = ['', function() {}];			// p1=name of checkbox field, p2=function to execute when clicked
	this.sortReverse = false;						// default order
	this.rowDepth = 10;								// number of rows to show per page (0=show all rows)
	this.height = 0;										// height in pixels (0=size according to number of rows)
	this.recCount = 0;								// total # records retrieved
	this.displayRecount = true;					// show | hide record count
	this.rowCallback = function () {};			// custom function for each row displayed
	this.deleteFn = [false, function() {}];		// whether to show a delete icon on every row and if so, execute user function on icon click
	this.onComplete = function() {};			// custom function call after data has been loaded
	this.printHeader = '';								// page heading (1st page)
	this.controls = [true, false, true, false];	// show: p1=search box, p2=print/csv, p3=paging, p4=list of fields to search
	this.init = function() { 
		cbb_addControls(this); 
		cbb_getData(this); 
	};
	this.refreshData = function() { cbb_getData(this); };
	this.preQuery = '';									// sql statement to run prior to the main 'b.query'
	this.searchFocus = function() { document.getElementById('cbb-search-input').focus() };	// set focus on search input box
	this.editColumn = ['', function() {}];			// p1=name of input field (can be an array), p2=function to execute when clicked
	this.totalColumn = '';							// name of column to be totalled (only shows on print)
	this.isArray = false;							// use array data instead of database source
	this.arrayData = [];								// table of data to display in grid
	this.csvPreFunction = function() {};			// execute this before generating the csv
	
	this.refreshRow = function(rowNum) { 	// repaint the display using data array as source
		var row = this.dataArea.children[Number(rowNum)+1];	// +1 to skip the header row
		for (var x in this.columns) {
			row.children[x].innerHTML = this.data[rowNum][x];
		}
	};

	this.colFilters = [];
	this.buildFilters = function() {
		
		if (this.colFilters.length == 0)
			return;
		
		for (var x in this.columns) {
			var field = document.createElement('span');
			this.headingsArea.appendChild(field);
			this.headingsArea.className = 'cbb-headings';
			if (this.colFilters[x] != undefined) {
				field = this.buildFilterOptions(field, this.colFilters[x][0]);
				field.onchange = (function(udf) { return function(e) { udf(this.value) }})(this.colFilters[x][1]);
			}
			$(field).addClass('cbb-column ' + this.colHeadClass[x]);	
		}
	}
	
	this.buildFilterOptions = function(field, list) {
		var option;
		var select = document.createElement('select');
		field.appendChild(select);
			
		for (var x in list) {
			option = document.createElement('option');
			select.appendChild(option);
			option.value = list[x];
			option.textContent = list[x];
		}	
		return select;
	}
															
	// internal
	this.startRow = 0;
	this.show = function() { cbb_displayData(this); };
	this.filter = '';
//	this.noFilter = !this.controls[0];			// true=suppress search box 
//																// (this is temporary and because alias columns won't work in concat in browse.php)
	this.printMode = false;
	this.csvMode = false;
	
//	this.searchFocus();
	
	document.getElementById(parent).innerHTML = '';
	
	return this;
}

function cbb_addControls(b) {
	var controlsPanel = document.createElement('div');
	document.getElementById(b.parent).appendChild(controlsPanel);
	controlsPanel.className = 'cbb-controls-panel';

	// search box (but disable it in 'array' mode)
	if (b.controls[0] && !b.isArray) {
		b.searchBox = document.createElement('div');
		controlsPanel.appendChild(b.searchBox);
		b.searchBox.className = 'cbb-search-box';
		$(b.searchBox).hide();

		var search = document.createElement('input');
		b.searchBox.appendChild(search);
		search.setAttribute('placeholder', 'Search');
		search.id = 'cbb-search-input';
		search.focus();
		search.onkeyup = function(key) { 
			if (key.keyCode == 13) {	// same as clicking on row...
				if (b.data.length > 0) {	// ...as long as there is data
					b.fetch(b.data[0]);
					searchClear.click();
				}
			}
			else {		// filter and display records as characters are typed into search box
				b.filter = cbb_addSlashes(this.value); 
				b.startRow = 0; 
				cbb_getData(b); 	
			}
		};
		
		// reset/clear search field
		var searchClear = document.createElement('div');
		b.searchBox.appendChild(searchClear);
		searchClear.className = 'cbb-search-clear';
		searchClear.innerHTML = 'x';
		searchClear.onclick = function() { 
			search.value = ''; 
			b.filter = ''; 
			b.startRow = 0; 
			cbb_getData(b); 
			search.focus();
		};
										  
		// dropdown list of searchable columns - default is "all"
		if (b.controls[3]) {
			b.searchFields = document.createElement('select');
			b.searchBox.appendChild(b.searchFields);
			b.searchFields.className = 'cbb-search-columns';
			var option = document.createElement('option');
			b.searchFields.appendChild(option);
			option.value = 'all';
			option.textContent = 'All columns';
			for (var x in b.columns) {
				option = document.createElement('option');
				b.searchFields.appendChild(option);
				option.value = b.columns[x];
				option.textContent = b.colHeadings[x];
			};
			
			b.searchBox.onchange = function() {
				if (b.searchFields.value == 'all')
					$(b.searchExactLabel).slideUp();
				else
					$(b.searchExactLabel).slideDown();
				b.startRow = 0; 
				cbb_getData(b); 	
			}

			// present 'search for exact match' checkbox
			b.searchExactLabel = document.createElement('label');
			b.searchBox.appendChild(b.searchExactLabel);

			b.searchExact = document.createElement('input');
			b.searchExactLabel.appendChild(b.searchExact);
			b.searchExact.type = 'checkbox';

			var searchExactText = document.createElement('span');
			b.searchExactLabel.appendChild(searchExactText);
			searchExactText.innerHTML = 'exact match';
			searchExactText.className = 'cbb-search-exact';

			$(b.searchExactLabel).hide();
		}	
	}
	
	// please wait icon + text
	b.loader = document.createElement('div');
	controlsPanel.appendChild(b.loader);

	var loader = document.createElement('img');
	b.loader.appendChild(loader);
	loader.src = 'images/please-wait.gif';
	
	loader = document.createElement('span');
	b.loader.appendChild(loader);
	loader.innerHTML = '&nbsp;<sup>PROCESSING...</sup>';
		
	// record count
	b.showRecCount = document.createElement('span');
	controlsPanel.appendChild(b.showRecCount);
	b.showRecCount.className = 'cbb-record-count';
	if (b.displayRecount)
		$(b.showRecCount).show();
	else
		$(b.showRecCount).hide();
		
	// buttons panel
	var btnPanel = document.createElement('div');
	controlsPanel.appendChild(btnPanel);
	btnPanel.className = 'cbb-btn-panel';
				
	if (b.controls[1]) {
		b.printBtn = document.createElement('button');
		btnPanel.appendChild(b.printBtn);
		b.printBtn.innerHTML = 'PRINT';
		b.printBtn.className = 'cbb-controls-btn';
		b.printBtn.onclick = function() { cbb_print(b); }
			
		b.csvBtn = document.createElement('button');
		btnPanel.appendChild(b.csvBtn);
		b.csvBtn.innerHTML = 'CSV';
		b.csvBtn.className = 'cbb-controls-btn';
		b.csvBtn.onclick = function() { b.csvPreFunction(); cbb_csv(b); }
	}
	
	// page back/forward buttons
	if (b.controls[2] && b.rowDepth > 0) {
		var btn = document.createElement('button');
		btnPanel.appendChild(btn);
		btn.innerHTML = 'PREV';
		btn.className = 'cbb-controls-btn';
		btn.onclick = function() { cbb_pageFlip(b, 'B') };

		btn = document.createElement('button');
		btnPanel.appendChild(btn);
		btn.innerHTML = 'NEXT';
		btn.className = 'cbb-controls-btn';
		btn.onclick = function() { cbb_pageFlip(b, 'F') };
	}
	
	// element to show the data
	b.headingsArea = document.createElement('div');
	document.getElementById(b.parent).appendChild(b.headingsArea);

	b.dataArea = document.createElement('div');
	document.getElementById(b.parent).appendChild(b.dataArea);
	b.dataArea.className = 'cbb-data-area';
	if (b.height > 0)
		b.dataArea.style.height = b.height + 'px';
}

function cbb_getData(b) {
	var sc = (!b.controls[3] || b.searchFields.value == 'all' ? 'all' : b.searchFields.value);

	if (b.isArray) { 
		cbb_sortArrayData(b);
		cbb_setupArrayData(b); 
		if (b.csvMode)
			cbb_createCSV(b); 		
	}
	else {	
		$.ajax({
			type: 'get',
			url: "scripts/browse.php",
			cache: false,
			data: { 
				preQuery: b.preQuery,
				query: b.query,
				filter: b.filter,
				noFilter: !b.controls[0],
				where: b.where,
				groupBy: b.groupBy,
				startRow: b.startRow,
				rowDepth: (b.csvMode ? 0 : b.rowDepth),
				columns: b.columns,
				searchColumn: sc,
				searchExact: b.controls[3] ? b.searchExact.checked : false,
				sortColumn: b.sortColumn,
				sortReverse: b.sortReverse
			},
			success: function(data) { 
				b.recCount = data[0];
				b.data = data[1];			// the data
//			console.log(data[2])		// debug; show the sql
				b.show();
				
				if (b.csvMode)
					cbb_createCSV(b); 

				$(b.loader).hide();
				$(b.searchBox).show();
				
				b.showRecCount.innerHTML = b.recCount;		// update display of record count
				
				b.onComplete();	// execute user-defined function
			},
			error: function (xhr) {		
				cb_alert(xhr.responseText);
			},
			dataType: 'json'
		});
	}
}

function cbb_setupArrayData(b) {
	b.recCount = b.arrayData.length;
	b.data = b.arrayData;			// the data
	b.show();
	$(b.loader).hide();
	$(b.searchBox).show();
	
	b.showRecCount.innerHTML = b.recCount;		// update display of record count
	
	b.onComplete();	// execute user-defined function
}

// sort the array data
function cbb_sortArrayData(b) {
	var column = b.columns.indexOf(b.sortColumn);
	var arr = b.arrayData;

     b.arrayData.sort(function(a,z) {
		if (a[column] === z[column]) {
			return 0;
		}
		else {
			if (b.sortReverse)
				return (a[column] < z[column]) ? 1 : -1;
			else
				return (a[column] < z[column]) ? -1 : 1;
		}
    });		
}

function cbb_displayData(b) {
	var dataArea = b.dataArea;

	// column filters
	var row = document.createElement('div');
	dataArea.appendChild(row);
	b.headingsArea.innerHTML = '';
	b.headingsArea.appendChild(row);
//console.log(b.colFilters, b.columns)	
	b.buildFilters();
	
	if (b.printMode)
		dataArea.innerHTML = b.printHeader;
	else
		dataArea.innerHTML = '';

	var row = document.createElement('div');
	dataArea.appendChild(row);

	// create column headings
	for (var x in b.colHeadings) {
		var field = document.createElement('div');
		row.appendChild(field);
		row.className = 'cbb-headings';
		field.innerHTML = b.colHeadings[x];
		$(field).addClass('cbb-column ' + b.colHeadClass[x]);
		
		if (b.columns[x] == b.sortColumn) {	
			if (b.sortReverse)
				field.innerHTML += '<span class="cbb-sort-column">&#9660;</span>';
			else
				field.innerHTML += '<span class="cbb-sort-column">&#9650;</span>';
		}
		
		// click heading to order on this column
		field.onclick = (function(index) { 	
			return function(e) { 
//console.log(index, b.colHeadings)
				cbb_sortColumn(b, index);
			}
		})(x);		
	}
	
//console.log('l=',$(row).context.scrollWidth)
//var w = $(row).context.scrollWidth;
//$(".cbb-row").css("width", w + 'px');

	if (b.data == '')
		dataArea.innerHTML += '<div class="cbb-no-data">No data.</div>';
	else
		var numCols = b.data[0].length;

	var columnTotal = 0;

	// add each row
	for (var y in b.data) {
		var row = document.createElement('div');
		dataArea.appendChild(row);
		
		row.onclick = (function(index) { 
			return function(e) { 

				var jsonData = {};
				var field;
				for (var x in b.data[index]) {
					field = b.columns[x];
					jsonData[field] = b.data[index][x];
				}
//console.log('data=',b.data, b.columns, jsonData)
				b.fetch(b.data[index], index, jsonData);
			}
		})(y);	
		
		// append each field
		for (var x=0; x<numCols; x++) {
			// convert field to checkbox, if option is set
			if (b.checkBox[0] == b.columns[x]) {		
				var field = document.createElement('input');
				row.appendChild(field);			
				field.type = 'checkbox';
				field.checked = (b.data[y][x] == 1);

				// call user defined checkbox function
				field.onclick = (function(index,col) { return function(e) { 
					e.stopPropagation(); 	// intercept the row onclick event (select the row)
					b.checkBox[1](b.data[index]);
					b.data[index][col] = (b.data[index][col] == 1 ? 0 : 1);
				}
				})(y,x);				
			}
			else if (b.editColumn[0].indexOf(b.columns[x]) != -1) {		// handle input field
				var field = document.createElement('input');
				row.appendChild(field);		
				field.id = 'cbb-input-' + y + '-' + x;
				field.type = 'text';	
				field.value = b.data[y][x];			
				
//$("input[type='text']").on("click", function () {
				// highlight field in focus
				$(field).on("click", function () {
				   $(this).select();
				});	

				// save keypress value in data array
				field.onkeyup = (function(index,col,f) { return function(e) { 
					e.stopPropagation(); 	// intercept the default row event
					b.data[index][col] = f.value;
				}
				})(y,x,field);		

				// execute udf on field exit
				field.onblur = (function(index,col,f,r) { return function(e) { 
/*					var jsonData = {};
					var field;
					for (var x in b.data[index]) {
						field = b.columns[x];
						jsonData[field] = b.data[index][x];
					}*/
//					b.editColumn[1](b.data[index], r, { 'rowData': jsonData, 'rowNum': index, 'colNum': col });		// udf	
					b.editColumn[1](b.data[index], r, { 'rowData': cbb_rowDataToJson(b, index), 'rowNum': index, 'colNum': col });		// udf	
				}
				})(y,x,field,row);		

				// allow up and down arrow to exit the edit box
				field.onkeydown = (function(index,col) { return function(e) { 
					e.stopPropagation(); 	// intercept the default row event
					if (e.which == 38) {
						cbb_setFocusOnInput(b, index, col, this.id, 'up', this.value);
					}
					if (e.which == 40 || e.which == 13) {
						cbb_setFocusOnInput(b, index, col, this.id, 'down', this.value);
					}
				}
				})(y,x);		
				$(field).addClass('cbb-column ' + b.colClass[x]);
			}
			else {
				var field = document.createElement('div');
				row.appendChild(field);
				field.innerHTML = b.data[y][x];
				$(field).addClass('cbb-column ' + b.colClass[x]);
			}			

			// accumulate a total, if defined
			if (b.totalColumn == b.columns[x])
				columnTotal += Number(b.data[y][x]);			
		}
		
		// show a delete icon at the end of every row, if set
		if (b.deleteFn[0]) {
			var field = document.createElement('div');
			row.appendChild(field);
			field.innerHTML = 'x';
			field.title = 'Delete this item';
			$(field).addClass('cbb-column cbb-delete-flag');

			// call user defined delete function
			field.onclick = (
				function(index) { 
					return function(e) { 
						e.stopPropagation(); 	// intercept the row onclick event (select the row)
						b.deleteFn[1](b.data[index], index);
					}
				}
			)(y);				
		}
		
		// execute any user-defined function for the row
//		b.rowCallback(row, b.data[y]);		
		b.rowCallback(row, b.data[y], cbb_addFieldNames(b.columns, b.data[y]));		

		// striping
		if (!(y%2))		
			$(row).addClass('cbb-row');
		else
			$(row).addClass('cbb-row alt');
	}
	
	if (b.printMode) {
		
		// setup area for printing any total column
		var row = document.createElement('div');
		dataArea.appendChild(row);	
		for (var x=0; x<numCols; x++) {
			var field = document.createElement('div');
			row.appendChild(field);
			if (b.totalColumn == b.columns[x])		// this is the column total	
				field.innerHTML = '<div class="cbb-column-total">' + columnTotal.toFixed(2) + '</div>';
			$(field).addClass('cbb-column ' + b.colClass[x]);
		}
		
		var row = document.createElement('div');
		dataArea.appendChild(row);		
		row.innerHTML = '<br>--- End of report ---';

		var els = cbb_getHiddenElements();
		var oldParent = dataArea.parentNode;
		$('body >').hide();
		$(dataArea).appendTo('body');
		
		window.print();

		b.printBtn.innerHTML = 'PRINT';
		b.printBtn.disabled = false;	
		b.printMode = false;
		$('body >').show();
		cbb_setHiddenElements(els);
		
		$(dataArea).appendTo(oldParent);		
		b.rowDepth = b.oldRowDepth;
		if (b.height > 0)
			b.dataArea.style.height = b.height + 'px';
		cbb_getData(b);
	}
}

function cbb_rowDataToJson(b, row) {
	var jsonData = {};
	var field;
	for (var x in b.data[row]) {
		field = b.columns[x];
		jsonData[field] = b.data[row][x];
	}

	return jsonData;
}

// add field names to data, e.g. { name: "Baines" }
function cbb_addFieldNames(cols, data) {
	var returnArray = new Object();
	
	for (var x in data) {
		returnArray[x] = data[x];
		returnArray[cols[x]] = data[x];
	}
	return (returnArray);
}

function cbb_getHiddenElements() {
	var hiddenEls = [];
	$("body >").each(function(x){
		if ($(this).is(":hidden")) {
			hiddenEls.push(this.id);
		}
	});
	return hiddenEls;
}

function cbb_setHiddenElements(els) {
	for (var x in els) {
		var el = '#' + els[x];
		$(el).hide();
	}
}

function cbb_setFocusOnInput(b, index, col, id, direction, value) {
	var str = id.split('-');
	var num = str[2];
	
	if (direction == 'up') {
		if (num > 0) num--;
	}
	else {
		if (num < b.recCount-1) num++;
	}
	
	var target = 'cbb-input-' + num + '-' + col;
//console.log(target)
	document.getElementById(target).focus();
	b.data[index][col] = value;	
//	b.editColumn[1](b.data[index]);		// udf	
	b.editColumn[1](b.data[index], '', { 'rowData': cbb_rowDataToJson(b, index), 'rowNum': index, 'colNum': col });		// udf
}

// change sort column
function cbb_sortColumn(b, col) {
	if (b.sortColumn == b.columns[col]) {		// same heading clicked twice in a row, so reverse direction
		b.sortReverse = !b.sortReverse;
	}

	b.sortColumn = b.columns[col];
	b.startRow = 0;
	cbb_getData(b);
}

// page forwards/backwards
function cbb_pageFlip(b, direction) {
	var currentStart = b.startRow;
	
	if (direction == 'F')
		b.startRow += b.rowDepth;
	else
		b.startRow -= b.rowDepth;
				
	// paged out of bounds, stay where we were before btn press
	if (b.startRow < 0 || b.startRow > b.recCount)
		b.startRow = currentStart;
		
	cbb_getData(b);
}

function cbb_print(b) {
	b.printMode = true;
	
	b.printBtn.innerHTML = '<img src="images/please-wait-2.gif">';
	b.printBtn.disabled = true;

	b.oldRowDepth = b.rowDepth;
	b.rowDepth = 0;

	b.dataArea.style.height = '';

	b.startRow = 0;
	cbb_getData(b);
}

function cbb_csv(b) {
//console.log(b.data)
	b.csvMode = true;
	
	b.csvBtn.innerHTML = '<img src="images/please-wait-2.gif">';
	b.csvBtn.disabled = true;

	b.oldRowDepth = b.rowDepth;
	b.rowDepth = 0;
	b.startRow = 0;

	cbb_getData(b);
}

function cbb_addSlashes(string) {
    return string.replace(/\\/g, '\\\\').
        replace(/\u0008/g, '\\b').
        replace(/\t/g, '\\t').
        replace(/\n/g, '\\n').
        replace(/\f/g, '\\f').
        replace(/\r/g, '\\r').
        replace(/'/g, '\\\'').
        replace(/"/g, '\\"');
}

function cbb_createCSV(b) {
	var data, filename, link;
	var csv = cbb_convertArrayOfObjectsToCSV({
		colClass: b.colClass,
		headings: b.colHeadings,
		data: b.data
	});
	if (csv == null) return;

	if (!csv.match(/^data:text\/csv/i)) {
		csv = 'data:text/csv;charset=utf-8,' + csv;
	}
	data = encodeURI(csv);

	filename = 'export.csv';
	link = document.createElement('a');
	link.setAttribute('href', data);
	link.setAttribute('download', filename);
	link.click();
	
	// reset csv button
	b.csvMode = false;
	b.rowDepth = b.oldRowDepth;	
	b.csvBtn.innerHTML = 'CSV';
	b.csvBtn.disabled = false;	
	b.refreshData();
}
	
function cbb_convertArrayOfObjectsToCSV(args) {
	var result, ctr, keys, columnDelimiter, lineDelimiter, data;

	data = args.data || null;
//console.log('dat=',data)	
	if (data == null || !data.length) {
		return null;
	}

	columnDelimiter = args.columnDelimiter || ',';
	lineDelimiter = args.lineDelimiter || '\n';

	keys = Object.keys(data[0]);

	result = '';
	result = args.headings + '\n';

	data.forEach(function(item) {
		ctr = 0;
		keys.forEach(function(key) {
			if (args.colClass[key] != 'hide') {	// don't output colums that were hidden in display
				if (ctr > 0) result += columnDelimiter;
				result += '"' +  item[key] + '"';		// encase data values in quotes
				ctr++;
			}
		});
		result += lineDelimiter;
	});

	return result;
}	

