<?php
include "db-conx.php";

$churchData = json_decode($_POST['churchData'], true);
$id = $churchData['id'];
$name = $churchData['name'];
$address = $churchData['address'];
$address_2 = $churchData['address_2'];
$city = $churchData['city'];
$county = $churchData['county'];
$province = $churchData['province'];
$postal_code = $churchData['postal_code'];
$region = $churchData['region'];
$phone = $churchData['phone'];
$email = $churchData['email'];
$denomination = $churchData['denomination'];
$status = $churchData['status'];
$notes = $churchData['notes'];
$website = $churchData['website'];
$mailing_address = $churchData['mailing_address'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();

	$sql = 'insert into churches (id, name, address, address_2, city, county, province, postal_code, region, phone, email, denomination, status, notes, website, mailing_address)
				values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
				on duplicate key
				update name=?, address=?, address_2=?, city=?, county=?, province=?, postal_code=?, region=?, phone=?, email=?, denomination=?, status=?, notes=?, website=?, mailing_address=?';
				
	$sth = $db_handle->prepare($sql);
	$success = $sth->execute(array(
		$id,
		$name, 
		$address, 
		$address_2, 
		$city, 
		$county, 
		$province, 
		$postal_code, 
		$region, 
		$phone, 
		$email, 
		$denomination,
		$status, 
		$notes, 
		$website, 
		$mailing_address, 
		$name,
		$address, 
		$address_2, 
		$city, 
		$county,
		$province,
		$postal_code, 
		$region, 
		$phone, 
		$email, 
		$denomination, 
		$status, 
		$notes,
		$website,
		$mailing_address
	));
	
	if ($id == 'new')
		$id = $db_handle->lastInsertId();		

//	$result->sql = $churchData['id'];
	$result->success = $success;
	$result->id = $id;
	$result->errorMessage = $sth->errorInfo();
//	$result->sql = $sql;
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);
?>