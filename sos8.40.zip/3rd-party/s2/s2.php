<?php
require 's2-api.php';
include '../../scripts/db-conx.php';

$s2 = new subsApi($_GET['s2keys']);

$query = $_GET['query'];
$result = '';

switch ($query) {
	case 'test-1': {
		$data = $_GET['data'];
		$result = ($s2->searchCustomersByAccountingId($data));
		
//		if ($result['status'] != 'failed')
//			$result = $result['lastname'];
		
		break;
	}
	case 'test-2': {
		$data = $_GET['data'];
		$result = ($s2->getCustomerSubscriptions($data));
		
//		if ($result['status'] != 'failed')
//			$result = $result['lastname'];
		
		break;
	}
	
	case 'updateS2': {
		$sql = 'select * from s2_log where s2_updated=0 order by type';	// order by type so that 'C' is first. Subs updates depend on 'C' records existing in s2
		$st = $db_handle->prepare($sql);
		$st->execute();

		while ($logRecord = $st->fetch()) {

			$type = $logRecord['type'];
			$id = $logRecord['id'];

			switch($logRecord['type']) {
				case 'C': {
					$result = s2updateCustomer($logRecord['id'], $logRecord['customer_id']);
					break;
				}
				case 'S': {	// create new sub
					$result = s2createSubscription($logRecord['id'], $logRecord['recipient_id'], $logRecord['customer_id'], $logRecord['num_issues'], $logRecord['qty'], $logRecord['pub_id']);
					break;
				}				
				case 'R': {	// renewal
					s2renewSubscription($logRecord['id'], $logRecord['sub_id'], $logRecord['federation_id'], $logRecord['num_issues']);
					break;
				}
				case 'U': {	// update sub
					s2updateSubscription($logRecord['id']);
					break;
				}
			}
		}
		break;
	}

	case 'getSubscriptions': {
		$fedID = getFedID($_GET['sosID']);
//		if ($fedID == 0)			// test for this otherwise S2 hangs
//			$result = array();
//		else
		$result = $s2->getCustomerSubscriptions($fedID);
		break;
	}	

	case 'getSubscription': {
		$result = $s2->getSubscription($_GET['subID']);		
		break;
	}
	
	case 'addToS2Log': {
		/* 	C = customer
			S = create sub
			U = update sub <--- 
			R = renew sub
		*/
		$result = addToS2Log($_GET['data']);
		break;	
	}
}

echo json_encode($result);


function getFedID($sosID) {
	global $db_handle, $s2;
	
	$fedID = '';
	$result = ($s2->searchCustomersByAccountingId($sosID));

//echo json_encode($result);	
//echo $result['conxStatus'];	
//echo '-->' . isset($result['status']);	

	if ($result['conxStatus'] == 'failed') {		// connection error
		// nothing to be done
//echo 'conx failure';
	}
	else if (isset($result['status']) && $result['status'] == 'notice') {		
//echo 'no customer';
		// s2 customer record not found
	}
	else {		// there is an existing s2 record
		$fedID = $result['federationid'];
//echo $fedID;
	}	
	
	return $fedID;
}

/*	Creates OR updates s2 customer record. 
*/
function s2updateCustomer($logID, $sosID) {
	global $db_handle, $s2;
	
	// look up the SOS customer record
	$sql = 'select * from customers where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($sosID));		
	$customer = $st->fetch();

	// set up data needed for s2
	$data = array(
		'webstoreid' => '',
		'title' => $customer['salutation'],
		'firstname' => $customer['first_name'],
		'lastname' => $customer['last_name'],
		'addr1' => $customer['address'],
		'addr2' => $customer['address_2'],
		'city' => $customer['city'],
		'state' => $customer['province'],
		'postcode' => $customer['postal_code'],
		'country' => $customer['country'],
		'email' => $customer['email1']
	);
	
//	$result = ($s2->searchCustomersByAccountingId($sosID));
	$fedID = getFedID($sosID);
	
	if ($fedID == '') {		// s2 record not found, so create one
		$data['accountingid'] = $customer['id'];
		$result = $s2->createCustomer(json_encode($data));
//		$fedID = $result['federationid'];
	}
	else {		// there is a pre-existing s2 record
		$data['federationid'] = $fedID;
		$result = $s2->updateCustomer(json_encode($data));
	}

	if ($result['conxStatus'] == 'failed') {
		$updated = 0;
		$msg = $result['conxMessage'];
	}
	else if (isset($result['status']) && $result['status'] == 'failed') {
		$updated = 0;
		$msg = $result['message'];
	}
	else {
		// mark all the s2_log record(s) that refer to this customer as 's2 updated'
		$updated = 1;	
//		$msg = $result['message'];
		$msg = 'Updated S2 customer record.';
	}

	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($msg, $updated, $logID));

	return $result;
}

// creates a single subscription - using '$id' which is the SOS s2_log ID
function s2createSubscription($id, $recipientID, $donorID, $numIssues, $qty, $pubID) {
	global $db_handle, $s2;
	$updated = 0;
	$result = '';

//echo json_encode($result) . '<br>';

	// establish if this is a gift sub
	$fedID = getFedID($recipientID);
	
	$s2recipientID = $fedID;
	if ($donorID == $recipientID) {		// it's a sub for self
		$s2donorID = '';
	}
	else {		// gift sub
		$result = ($s2->searchCustomersByAccountingId($donorID));
		$s2donorID = $result['federationid'];		
	}
	
	$data = array(
		'federationid' => $s2recipientID,
		'issuecount' => $numIssues,
		'qty' => $qty,
		'analytics' => array( 
			'sourceid' => '',
			'event_id' => '',
		),
		'pubid' => $pubID,
		'giverid' => $s2donorID
	);	
//echo json_encode($data);

	$result = $s2->createSubscription(json_encode($data));
	$response = $result['message'];		
	if ($result['status'] == 'success') {
		$updated = 1;	// s2 successfully updated so flag the s2_log record, i.e. update has been done
	}
	
//echo 'updated=' . $updated;
	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($response, $updated, $id));	

	return $result;
}

// renews a single subscription - using '$id' which is the SOS s2_log ID
function s2renewSubscription($id, $subID, $fedID, $numIssues) {
	global $db_handle, $s2;

	$data = array(
		'federationid' => $fedID,
		'subid' => $subID,
		'issuecount' => $numIssues
	);	
	$result = $s2->renewSubscription(json_encode($data));
	if ($result['status'] == 'success')
		$updated = 1;	// s2 successfully updated so flag the s2_log record, i.e. update has been done
	else
		$updated = 0;
	
	$sql = 'update s2_log set s2_response=?, s2_updated=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($result['message'], $updated, $id));	
	
	return $result;
}

function addToS2Log($data) {
	global $db_handle;

	$type = $data['type'];
	$subID = $data['subID'];
	$notes = $data['notes'];
	$email = $data['email'];
	$qty = $data['qty'];
	$cancel = $data['cancel'];
//	$fedID = $data['fedID'];
	
	$sql = 'insert into s2_log set type=?, sub_id=?, notes=?, email=?, qty=?, cancel=?';
	$st = $db_handle->prepare($sql);
	$result = $st->execute(array($type, $subID, $notes, $email, $qty, $cancel));
	
	return $db_handle->lastInsertId();	
}

function s2updateSubscription($s2logID) {
	global $db_handle, $s2;
//	$s2 = new subsApi();

	$sql = 'select * from s2_log where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($s2logID));
	$logRecord = $st->fetch();
//echo $data;
	$result1 = $s2->commentSubscription($logRecord['sub_id'], $logRecord['notes']);		

	$result2 = $s2->updateSubscription($logRecord['sub_id'], $logRecord['email']);	

	$data = array('subid' => $logRecord['sub_id'], 'newqty' => $logRecord['qty']);
	$result3 = $s2->adjustBulks(json_encode($data));	
	
	$result4 = array(
		'status' => 'success',
		'message' => ''
	);
	   
	if ($logRecord['cancel'] == '1')
		$result4 = $s2->cancelSubscription($logRecord['sub_id'], $logRecord['notes']);

/*
echo json_encode($result1) . '<br>';
echo json_encode($result2) . '<br>';
echo json_encode($result3) . '<br>';
echo json_encode($result4) . '<br>';
*/
	$totalResult = new stdClass();
	if ($result1['conxStatus'] == 'failed' && 
		$result2['conxStatus'] == 'failed' &&
		$result3['conxStatus'] == 'failed' &&
		$result4['conxStatus'] == 'failed') {
	
		$totalResult->status = 'failed';
		$totalResult->message = 'S2 connection problem.';
	}
	else if ($result1['status'] == 'success' && 
		$result2['status'] == 'success' &&
		$result3['status'] == 'success' &&
		$result4['status'] == 'success') {
			
		// s2 successfully updated so flag the s2_log record, i.e. update has been done
		$sql = 'update s2_log set s2_updated=1 where id=?';
		$st = $db_handle->prepare($sql);
		$st->execute(array($s2logID));			
			
		$totalResult->status = 'success';
		$totalResult->message = $result1['message'] . ',' . $result2['message'] . ',' .  $result3['message'] . ',' .  $result4['message'];
	//	return $result1;
	}
	else
		$totalResult->message = $result1['message'] . ',' . $result2['message'] . ',' .  $result3['message'] . ',' .  $result4['message'];
//echo 'total=' . json_encode($totalResult);

	$sql = 'update s2_log set s2_response=? where id=?';
	$st = $db_handle->prepare($sql);
	$st->execute(array($totalResult->message, $s2logID));	

	return $totalResult;
}
?>