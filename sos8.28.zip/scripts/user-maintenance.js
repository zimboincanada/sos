var menuData = {
	id: '0',
	title: "root - not displayed",
	children: [{
		id: '1',
		title: "Customers"
	}, {
		id: '2',
		title: "Reports",
		children: [{
			id: '2-1',
			title: "General"
		}, {
			id: '2-2',
			title: "Mailing lists"
		}, {
			id: '2-3',
			title: "CA reports"
		}, {
			id: '2-4',
			title: "UK reports"
		}]
	}, {
		id: '3',
		title: "Settings",
		children: [{
			id: '3-1',
			title: "General"
		}, {
			id: '3-2',
			title: "Shipping"
		}, {
			id: '3-3',
			title: "Drop down lists"
		}, {
			id: '3-4',
			title: "Sales orders"
		}, {
			id: '3-5',
			title: "Donations"
		}, {
			id: '3-6',
			title: "Subscriptions"
		}, {
			id: '3-7',
			title: "Daily sales summary"
		}, {
			id: '3-8',
			title: "EPIC"
		}, {
			id: '3-9',
			title: "Inventory"
		}]
	}, {
		id: '4',
		title: "Utilities",
		children: [{
			id: '4-1',
			title: "Recurring donations"
		}, {
			id: '4-2',
			title: "System recovery"
		}, {
			id: '4-3',
			title: "Backup database"
		}, {
			id: '4-4',
			title: "Find a customer"
		}, {
			id: '4-5',
			title: "Subscriptions count"
		}, {
			id: '4-6',
			title: "Export Orders (for shipping)"
		}, {
			id: '4-7',
			title: "Lock Sales Orders"
		}, {
			id: '4-8',
			title: "Software update"
		}, {
			id: '4-9',
			title: "Reset 'Courtesy Call' flags"
		}]
	}, {
		id: '5',
		title: "Inventory",
		children: [{
			id: '5-1',
			title: "Purchase Orders"
		}, {
			id: '5-2',
			title: "Adjust"
		}, {
			id: '5-3',
			title: "Stock take"
		}, {
			id: '5-4',
			title: "Upload products"
		}, {
			id: '5-5',
			title: "Suppliers"
		}, {
			id: '5-6',
			title: "Product maintenance"
		}, {
			id: '5-7',
			title: "S2 product map"
		}]
	}, {
		id: '6',
		title: "User maintenance"
	}, {
		id: '7',
		title: "Picklists",
		children: [{
			id: '7-1',
			title: "Create picklist"
		}, {
			id: '7-2',
			title: "Event returns"
		}, {
			id: '7-3',
			title: "Picklist maintenance"
		}]
	}, {
		id: '8',
		title: "EPIC",
		children: [{
			id: '8-1',
			title: "Churches"
		}, {
			id: '8-2',
			title: "Events"
		}, {
			id: '8-3',
			title: "Tours"
		}, {
			id: '8-4',
			title: "Web export"
		}, {
			id: '8-5',
			title: "Talks"
		}, {
			id: '8-6',
			title: "Document templates"
		}, {
			id: '8-7',
			title: "Speakers"
		}]
	}]
};

//	menuData = oLogin.navItems;

function init() {
	if (!oLogin.hasMenuRights('6'))
		window.location.href = 'index.html';
//console.log(menuData)	
//console.log(oLogin.menuData)	
	showUsers();
	initMenu();
}

function setPanel(tab, panel) {
	$('#user-menu-rights').hide();
	$('#user-function-rights').hide();
	$('#user-details').hide();
	$('#user-alerts').hide();
	$('.tab').removeClass('active');
	
	$('#' + panel).show();
	$(tab).addClass('active');
}

function initMenu() {
	$('#user-menu-rights').html('');
	addItem($('#user-menu-rights'), menuData);	
	$('.expand-collapse').on('click', function () {
		$(this).closest('li').children('ul').slideToggle();
		if (this.expandCollapse)
			this.src = 'images/expand.png';
		else
			this.src = 'images/collapse.png';
		this.expandCollapse = !this.expandCollapse;
	});
}

function addItem(parentUL, branch) {
	for (var key in branch.children) {
		var item = branch.children[key];
		$item = $('<li>', {
			id: "item" + item.id
		});

		$item.append($('<input>', {
			type: "checkbox",
			id: "item-detail-" + item.id,
			name: "item" + item.id,
			checked: item.checked
		}));
					
		$item.append($('<label>', {
			for: "item-detail-" + item.id,
			text: item.title
		}));
		parentUL.append($item);
		if (item.children) {
		
			$item.append('<img class="expand-collapse" src="images/expand.png" style="width:18px; margin-left:5px; cursor:pointer; vertical-align:middle">')

			var $ul = $('<ul>', {
				style: 'display: none'
			}).appendTo($item);
			$item.append();
			addItem($ul, item);
		}
	}
}

var userObj;
function showUsers() {
	var b = new cb_browse('users');
	b.query = 'select * from users';
	b.sortColumn = 'login_uid';
	b.rowDepth = 0;
	b.height = 500;
	b.columns = ['login_uid', 'sys_admin'];
	b.colClass = ['login-1','login-2'];
	b.colHeadings = ['Login ID', 'System Admin'];
	b.colHeadClass = b.colClass;
	b.deleteFn = [true, function(data) { deleteUserCheck(data[0]) }];
	b.fetch = function(data) { 
	
		$('#right-panel-img').hide();
		$('#right-panel-data').show();
	
		var uid = data[0];
		$('#user-id').html('&#9658;' + ' ' + uid); 
		
		var sql = 'select * from users where login_uid="' + uid + '"';
		execSQL(sql, function(data) {
			var str = data[0];

			for (var x in str)
				userObj[x] = str[x];
			userObj.menuRights = str.menu_rights.split(',');
			getUserDetails();
		});			
	};
	
	b.rowCallback = function(row, data) {
		row.children[1].innerHTML = '';		
		if (data[1] == 1)
			row.children[1].innerHTML = 'Yes';		
	}
	
	b.init();
	userObj = b; 
}

function deleteUserCheck(id) {
	confirmBox(
		"CONFIRM", 
		"About to delete this user: <b>" + id + "</b>.<br>Are you sure?", 
		["Yes", "No"],
		[ function() { 
			var sql = 'delete from users where login_uid="' + id + '"';
			execSQL(sql, function() {
				userObj.refreshData();
			});	
		}, function() {} ]
	);
}

function getUserDetails() {
	initMenu();
	
	if (userObj.menuRights[0] != '') {
		for (var x in userObj.menuRights) {
			var id = ('item-detail-' + userObj.menuRights[x]);
//console.log(id, $('#' + id).length)
			if ($('#' + id).length > 0)	// needs to exist
				document.getElementById(id).checked = true;
		}
	}

	document.getElementById('sys-admin').checked = (userObj.sys_admin == 1);
	toggleRightsTree(userObj.sys_admin == 1);
	
	document.getElementById('ufr-delete-customer').checked = (userObj.delete_customer == 1);
	document.getElementById('ufr-delete-sales-order').checked = (userObj.delete_sales_order == 1);
	document.getElementById('ufr-edit-sales-order').checked = (userObj.edit_sales_order == 1);
	document.getElementById('ufr-delete-subscription').checked = (userObj.delete_subscription == 1);
	document.getElementById('ufr-edit-subscription').checked = (userObj.edit_subscription == 1);
	document.getElementById('ufr-delete-po').checked = (userObj.delete_po == 1);
	document.getElementById('ufr-custom-product').checked = (userObj.custom_product == 1);
	document.getElementById('user-alert-harvest').checked = (userObj.alert_harvest == 1);
	document.getElementById('user-alert-s2').checked = (userObj.alert_s2 == 1);
	document.getElementById('user-alert-todo').checked = (userObj.alert_todo == 1);
	document.getElementById('user-alert-bom').checked = (userObj.alert_bom == 1);
	document.getElementById('user-alert-stock').checked = (userObj.alert_stock == 1);
	document.getElementById('ufr-stocktake-closeout').checked = (userObj.stocktake_closeout == 1);

	$('#ud-uid').html(userObj.login_uid);
	$('#ud-name').val(userObj.login_full_name);
}

function saveUserDetails() {
	userObj.menuRights = '';
	walkMenuTree(menuData.children);
	
	var sql = 'update users set menu_rights="' + userObj.menuRights + 
					'", sys_admin=' + (document.getElementById('sys-admin').checked ? 1 : 0) + 
					', delete_customer=' + (document.getElementById('ufr-delete-customer').checked ? 1 : 0) + 
					', delete_sales_order=' + (document.getElementById('ufr-delete-sales-order').checked ? 1 : 0) + 
					', edit_sales_order=' + (document.getElementById('ufr-edit-sales-order').checked ? 1 : 0) + 
					', delete_subscription=' + (document.getElementById('ufr-delete-subscription').checked ? 1 : 0) + 
					', edit_subscription=' + (document.getElementById('ufr-edit-subscription').checked ? 1 : 0) + 
					', delete_po=' + (document.getElementById('ufr-delete-po').checked ? 1 : 0) + 
					', custom_product=' + (document.getElementById('ufr-custom-product').checked ? 1 : 0) + 
					', login_full_name="' + $('#ud-name').val() + '"' + 
					', alert_harvest="' + (document.getElementById('user-alert-harvest').checked ? 1 : 0) + '"' + 
					', alert_s2="' + (document.getElementById('user-alert-s2').checked ? 1 : 0) + '"' + 
					', alert_todo="' + (document.getElementById('user-alert-todo').checked ? 1 : 0) + '"' + 
					', alert_bom="' + (document.getElementById('user-alert-bom').checked ? 1 : 0) + '"' + 
					', alert_stock="' + (document.getElementById('user-alert-stock').checked ? 1 : 0) + '"' + 
					', stocktake_closeout="' + (document.getElementById('ufr-stocktake-closeout').checked ? 1 : 0) + '"' + 
					' where login_uid="' + userObj.login_uid + '"';
//console.log(sql)
	execSQL(sql, function() {
		userObj.refreshData();
		statusMsg('Access rights updated for ' + userObj.login_uid + '.');
	})
}

function walkMenuTree(o) {
	for (var i in o) {
		if (!!o[i] && typeof(o[i]) == "object") {
			if (i != 'children') {
				var id = ('item-detail-' + o[i].id);
				var checked = document.getElementById(id).checked;
				if (checked) {
					if (userObj.menuRights != '')
						userObj.menuRights += ',';
					userObj.menuRights += o[i].id;
				}
			}
			walkMenuTree(o[i]);		
		}		
	}
	
	return userObj.menuRights;
}  	

function toggleRightsTree(isSysAdmin) {
	if (isSysAdmin) {
		$("#user-menu-rights, #user-function-rights").addClass('disabled');
		$("#user-menu-rights, #user-function-rights").click(function(e) {
			e.preventDefault();
		});
	}
	else {
		$("#user-menu-rights, #user-function-rights").removeClass('disabled');
		$("#user-menu-rights, #user-function-rights").unbind();
	}
}

function addUserID() {	
	var uid = $('#new-uid').val();
	if (uid == '')
		return;
		
	var sql = 'insert into users set login_uid="' + uid + '", login_full_name="' + uid + '"';
	execSQL(sql, function(d) {
		statusMsg(uid + ' has been added');
		userObj.refreshData();
	});
}

function resetPassword() {
	var sql = 'update users set login_pwd="" where login_uid="' + userObj.login_uid + '"';
//console.log(sql)
	execSQL(sql, function() {
		statusMsg('Password has been reset for ' + userObj.login_uid + '.');
	})
}
