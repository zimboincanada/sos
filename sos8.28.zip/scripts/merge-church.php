<?php
include "db-conx.php";

$primaryID = $_POST['primaryID'];
$duplicateID = $_POST['duplicateID'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();

	$sql = 'update events set church_id=? where church_id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$primaryID,
		$duplicateID
	));
		
	$sql = 'update contacts set church_id=? where church_id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$primaryID,
		$duplicateID
	));


	$sql = 'update contact_history set church_id=? where church_id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$primaryID,
		$duplicateID
	));
	
	$sql = 'delete from churches where id=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$duplicateID
	));	

	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);
?>