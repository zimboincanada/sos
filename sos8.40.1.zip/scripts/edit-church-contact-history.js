// CHURCH CONTACT HISTORY...

function contactHistory() {
	this.edit = function(id, note, followUp, eventPlanner) {
		document.getElementById('contact-history-form').overlay = doOverlay(true, 'contact-history-form');
		document.getElementById('contact-history-form').style.display = 'block';
		document.getElementById('contact-history-form').reset();
		this.currentNoteID = id;
		
		var options = oLogin.users;
		fillPicklistWithData('contact-history-note-owner', options, options);	
		
		if (id == 'new') {
			$('#contact-history-note').val('');
			$('#contact-history-note-follow-up').val('');
			$('#contact-history-note-owner').val(oLogin.uid);
		}
		else {
			$('#contact-history-note').val(note);
			$('#contact-history-note-follow-up').val(followUp);
			$('#contact-history-note-owner').val(eventPlanner);
		}
	}

	// close contact dialog
	this.close = function() {
		document.getElementById('contact-history-form').style.display = 'none';
		doOverlay(false, document.getElementById('contact-history-form').overlay);
	}

	this.deleteCheck = function(id) {
	
		confirmBox(
			"CONFIRM", 
			"Are you sure you want to delete this Note?", 
			["Yes", "No"],
			[ function() { oContactHistory.remove(id) }, function() {} ]
		);
	}

	this.remove = function(id) {
		var sql = 'delete from contact_history where id=' + id;
		execSQL(sql, function() {
			oContactHistory.browse.refreshData();
		});
	}	
		
	this.save = function() {
		var obj = this;

		if (!formValidated('contact-history-form'))
			return;

		var sql = 'insert into contact_history set' +
						' id="' + this.currentNoteID + '"' +
						',church_id="' + oChurch.details.id + '"' +
						',note="' + $('#contact-history-note').val() + '"' +
						',follow_up="' + $('#contact-history-note-follow-up').val() + '"' +
						',login_id="' + $('#contact-history-note-owner').val() + '"' +
						' on duplicate key' +
						' update note="' + $('#contact-history-note').val() + '", login_id="' + $('#contact-history-note-owner').val() +'", follow_up="' + $('#contact-history-note-follow-up').val() + '"';

		execSQL(sql, function() {
			obj.close();
			oContactHistory.browse.refreshData();
			statusMsg('Note saved.');
			log('EPIC CONTACT NOTE ADDED', oChurch.details.name);
		});	
	}
	
}