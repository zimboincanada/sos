<?php
	include "db-conx.php";
//	include "../3rd-party/s2/s2-api.php";

	$array = array();
	$query = $_GET['query'];
	$key = $_GET['key'];

	switch($query) {				
		case 'getBOM': {	// return list of products (BOM) associated with pack item ($key)
			$sql = "select pb.sku, p.title, p.price, p.digital, pb.qty from product_boms pb, products p where p.sku=pb.sku and pb.parent_sku='" . $key . "'";
			$sth = $db_handle->prepare($sql);
			$sth->execute();
			$counter = 0;

			while ($row = $sth->fetch()) {
				$array[$counter][0] = $row['sku'];
				$array[$counter][1] = $row['title'];
				$array[$counter][2] = $row['price'];
				$array[$counter][3] = $row['digital'];
				$array[$counter][4] = $row['qty'];
				$counter++;
			}
			break;
		}
	
		// return last issue number plus its sub_type of most recent subscription record and only if it is status 'active'
		case 'getCurrentSub': {		
			$subType = $_GET['sub_type'];
			$values[0] = $key;
				
			$sql = 'select ms.last_issue, soi.sub_type from mag_subs ms, sales_order_items soi
						where ms.recipient_id=?
						and soi.mag_sub_id=ms.id
						and ms.status=1';
						
			if ($subType == 'J') {
				$sql .= ' and soi.sub_type=?';
				$values[1] = $subType;
			}
			
			$sql .= ' order by ms.last_issue desc limit 1';
					
			$sth = $db_handle->prepare($sql);
			if ($sth->execute($values)) {
				$row = $sth->fetch();
				$array[0] = $row['last_issue'];
				$array[1] = $row['sub_type'];
			}
			else {
				$array[0] = '';
				$array[1] = '';
			}
			break;
		}
		
		case 'getSettings': {
			$sth = $db_handle->prepare("select * from settings where id=1");
			if ($sth->execute()) {
				$row = $sth->fetch();
				$array[0] = $row['shipping_rate_pct'];
				$array[1] = $row['shipping_rate_max'];
				$array[2] = $row['customer_source'];
				$array[3] = $row['payment_method'];
				$array[4] = $row['sales_order_source'];
				$array[5] = $row['salutation'];
				$array[6] = $row['cmi_address_1'];
				$array[7] = $row['cmi_address_2'];
				$array[8] = $row['cmi_address_3'];
				$array[9] = $row['cmi_address_4'];
				$array[10] = $row['cmi_address_5'];
				$array[11] = $row['cmi_address_6'];
				$array[12] = $row['sales_order_footer'];
				$array[13] = $row['country'];
				$array[14] = $row['backup_folder'];
				$array[15] = $row['shipping_folder'];
				$array[16] = $row['donation_letter'];
				$array[17] = $row['recurring_donations'];
				$array[18] = $row['current_print'];
				$array[19] = $row['current_digital'];
				$array[20] = $row['current_journal'];
				$array[21] = $row['welcome_letter'];
				$array[22] = $row['gift_letter'];
				$array[23] = $row['gift_renewal_letter'];
				$array[24] = $row['welcome_letter_j'];
				$array[25] = $row['gift_letter_j'];
				$array[26] = $row['gift_renewal_letter_j'];
				$array[27] = $row['tax_band_1'];
				$array[28] = $row['tax_band_2'];
				$array[29] = $row['tax_band_3'];
				$array[30] = $row['tax_band_4'];
				$array[31] = $row['tax_band_label_1'];
				$array[32] = $row['tax_band_label_2'];
				$array[33] = $row['tax_band_label_3'];
				$array[34] = $row['tax_band_label_4'];
				$array[35] = $row['donation_default_source'];
				$array[36] = $row['cut_off_period'];
				$array[37] = $row['subs_country_code'];
				$array[38] = $row['subs_letters_margin'];
				$array[39] = $row['subs_gift_renewal_margin'];
//				$array[40] = $row['current_issue_sku'];
//				$array[41] = $row['current_j_issue_sku'];
				$array[42] = $row['countries'];
				$array[43] = $row['eu_countries'];
				$array[44] = $row['uk_shipping_band_1'];
				$array[45] = $row['uk_shipping_band_2'];
				$array[46] = $row['uk_shipping_band_3'];
				$array[47] = $row['uk_shipping_band_4'];
				$array[48] = $row['background_image'];
				$array[49] = $row['reports_exclude_payment_type'];
				$array[50] = $row['subs_missed_issues'];
				$array[51] = $row['cut_off_period_j'];
				$array[52] = $row['cut_off_period_d'];
				$array[53] = $row['source_to_exclude_sub'];
			}
			break;
		}
				
		case 'getCustomer': {
			$sth = $db_handle->prepare("select * from customers where id=?");
			if ($sth->execute(array($key))) {
				$row = $sth->fetch();
				$array = $row;

				// get donations total for current year (the stored proc will accept a year as parameter for other years)
				$year = date("Y");
				$sql = "call get_donation_value(?,?)";
				$sth = $db_handle->prepare($sql);
				if ($sth->execute(array($key, $year))) {
					$donValue = $sth->fetch();
					$array = array_merge($array,  $donValue);
				}
			}
			break;
		}

		// get donations total for current year (the stored proc will accept a year as parameter for other years)
		case 'getDonations': {
				$year = date("Y");
				$sql = "call get_donation_value(?,?)";
				$sth = $db_handle->prepare($sql);
				if ($sth->execute(array($key, $year))) {
					$row = $sth->fetch();
					$array[0] = $row[0];
				}
				else
					$array[0] = 0;
				break;
		}
		
		// single sales order - header data
		case 'sales_order': {
			$sql = "select * from sales_orders where id=?";
			$sth = $db_handle->prepare($sql);
			if ($sth->execute(array($key))) {
				$row = $sth->fetch();
				$array[0] = $row['notes'];
				$array[1] = $row['source'];
				$array[2] = $row['payment_type'];
				$array[3] = $row['add_info'];
				$array[4] = $row['ship_address_1'];
				$array[5] = $row['ship_address_2'];
				$array[6] = $row['ship_address_3'];
				$array[7] = $row['ship_address_4'];
				$array[8] = $row['ship_address_5'];
				$array[9] = $row['ship_address_6'];
				$array[10] = $row['ship_address_7'];
				$array[11] = $row['payment_date'];
				$array[12] = $row['payment_type_1'];
				$array[13] = $row['payment_amount_1'];
				$array[14] = $row['payment_info_1'];
				$array[15] = $row['payment_type_2'];
				$array[16] = $row['payment_amount_2'];
				$array[17] = $row['payment_info_2'];
				$array[18] = $row['payment_type_3'];
				$array[19] = $row['payment_amount_3'];
				$array[20] = $row['payment_info_3'];
				$array[21] = $row['payment_type_4'];
				$array[22] = $row['payment_amount_4'];
				$array[23] = $row['payment_info_4'];
				$array[24] = $row['payment_type_5'];
				$array[25] = $row['payment_amount_5'];
				$array[26] = $row['payment_info_5'];
				$array[27] = $row['payment_type_6'];
				$array[28] = $row['payment_amount_6'];
				$array[29] = $row['payment_info_6'];
				$array[30] = $row['lockdown'];
			}
			break;
		}

		// sales order product items, for a specific sales order
		case 'sales_order_items': {		// SOI
			$sql = "select soi.sku, soi.title, soi.price, soi.type, soi.sub_type, soi.shipping_calc, soi.qty, soi.mag_sub_id, ms.recipient_id, soi.gift_aid, soi.digital, soi.id, soi.back_order, ms.first_issue, ms.last_issue, ms.num_issues, soi.s2_create_sub
						from sales_order_items soi
						left outer join mag_subs ms
						on soi.mag_sub_id=ms.id
						where soi.sales_order=?";

			$sth = $db_handle->prepare($sql);
			if ($sth->execute(array($key))) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[$counter] = $row;
					$counter++;
				}					
			}
			break;
		}
				
		case 'salesOrderLinesPrint': {		// SOP
			$sql="select *, soi.qty as soi_qty, soi.id as soi_id, 
						if(concat(c.first_name, ' ', c.last_name)=' ',
							c.organization,
							concat(c.first_name, ' ', c.last_name)) as name ,
						soi.gift_aid as soi_gift_aid
						from sales_order_items soi
						left outer join mag_subs ms
						on soi.mag_sub_id=ms.id
						left outer join customers c
						on c.id=ms.recipient_id
						where soi.sales_order=?
						order by soi.sku";			
			$sth = $db_handle->prepare($sql);
			if ($sth->execute(array($key))) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[$counter][0] = $row['sku'];
					$array[$counter][1] = $row['title'];
					$array[$counter][2] = $row['price'];
					$array[$counter][3] = $row['soi_qty'];
					$array[$counter][4] = $row['type'];
					$array[$counter][5] = $row['mag_sub_id'];
					$array[$counter][6] = $row['name'];
					$array[$counter][7] = $row['sub_type'];
					$array[$counter][8] = $row['recipient_id'];
					$array[$counter][9] = $row['digital'];
					$array[$counter][10] = $row['soi_gift_aid'];
					$array[$counter][11] = $row['back_order'];

					$packValue = $row['pack_value'];
					$packPrice = $row['price'];
					$soiID = $row['soi_id'];

					// collect bom item descriptions/prices into arrays
					$bomItems = array();
					$bomPrices = array();
					$bomSubTypes = array();
					$bomQtys = array();
					$x = 0;
					$sql = 'select sku, title, price, sub_type, qty from sales_order_bom_items where soi_id=?';
					$sth2 = $db_handle->prepare($sql);
					$sth2->execute(array($soiID));
					while ($row = $sth2->fetch()) {
						$bomItems[$x] = $row['title'] . ' (' . $row['sku'] . ')';
						if ($packValue == 0)
							$bomPrices[$x] = 0;	// avoid div by zero
						else
							$bomPrices[$x] = $row['price'] / $packValue * $packPrice;
						$bomSubTypes[$x] = $row['sub_type'];
						$bomQtys[$x] = $row['qty'];
						$x++;
					}
					$array[$counter][12] = $bomItems;
					$array[$counter][13] = $bomPrices;
					$array[$counter][14] = $bomSubTypes;
					$array[$counter][15] = $bomQtys;
					
					$counter++;
				}					
			}
			break;
		}	
				
		case 'salesOrderSummary2016': {			
			$txnDate = $_GET['txn_date'];
			$filter = $_GET['filter'];
			
			// products (non books), shipping, digi only mags
			$sql = 'select case c.province
						when find_in_set(c.province,s.tax_band_1) = 0 then s.tax_band_label_1
						when find_in_set(c.province,s.tax_band_2) = 0 then s.tax_band_label_2
						when find_in_set(c.province,s.tax_band_3) = 0 then s.tax_band_label_3
						when find_in_set(c.province,s.tax_band_4) = 0 then s.tax_band_label_4
						else "Other"
						end as band, 
						sku, title,
						sum(soi.qty) as t_qty,
						sum(soi.qty*soi.price) as t_price
						from sales_order_items soi, sales_orders so, customers c, settings s
						where ' . $filter . ' and
						soi.sales_order=so.id and
						so.customer_id=c.id and
						((soi.type="P" and soi.sub_type="N") or soi.type="S" or (soi.type="M" and soi.sub_type="D")) and
						c.price_band!=4 and
						left(so.order_date,10)="' . $txnDate . '"
						group by band, soi.type, soi.sub_type, soi.sku
						order by band, soi.sku';
			$sth = $db_handle->prepare($sql);
			if ($sth->execute()) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[0][$counter][0] = $row['band'];
					$array[0][$counter][1] = $row['sku'];
					$array[0][$counter][2] = $row['title'];
					$array[0][$counter][3] = $row['t_qty'];
					$array[0][$counter][4] = $row['t_price'];
					$counter++;
				}
			}
			
			// products (books & non digi only magazines)
			$sql = 'select sku, title,
						sum(soi.qty) as t_qty,
						sum(soi.qty*soi.price) as t_price
						from sales_order_items soi, sales_orders so, customers c
						where ' . $filter . ' and						
						soi.sales_order=so.id and
						so.customer_id=c.id and
						((soi.type="P" and soi.sub_type="B") or (soi.type="M" and soi.sub_type!="D")) and
						c.price_band!=4 and						
						left(so.order_date,10)="' . $txnDate . '"
						group by soi.type, soi.sub_type, soi.sku, soi.title
						order by soi.sku';
			$sth = $db_handle->prepare($sql);
			if ($sth->execute()) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[1][$counter][0] = $row['sku'];
					$array[1][$counter][1] = $row['title'];
					$array[1][$counter][2] = $row['t_qty'];
					$array[1][$counter][3] = $row['t_price'];
					$counter++;
				}
			}

			// donations
			$sql = 'select soi.title, sum(soi.qty*soi.price) as total
						from sales_order_items soi, sales_orders so
						where ' . $filter . ' and						
						soi.sales_order=so.id and
						soi.type="D" and
						left(so.order_date,10)="' . $txnDate . '"
						group by soi.title';
			$sth = $db_handle->prepare($sql);
			if ($sth->execute()) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[2][$counter][0] = $row['title'];
					$array[2][$counter][1] = $row['total'];
					$counter++;
				}
			}			
			
			// custom items
			$sql = 'select c.province, 
						if(concat(c.first_name, " ", c.last_name)=" ",
							c.organization,
							concat(c.first_name, " ", c.last_name)) as name,		
						soi.title, soi.qty, (soi.qty*soi.price) as total, so.id
						from sales_order_items soi, sales_orders so, customers c
						where ' . $filter . ' and						
						soi.sales_order=so.id and
						so.customer_id=c.id and
						c.price_band!=4 and								
						soi.type="C" and
						left(so.order_date,10)="' . $txnDate .'"';						
			$sth = $db_handle->prepare($sql);
			if ($sth->execute()) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[3][$counter][0] = $row['province'];
					$array[3][$counter][1] = $row['name'];
					$array[3][$counter][2] = $row['title'];
					$array[3][$counter][3] = $row['qty'];
					$array[3][$counter][4] = $row['total'];
					$array[3][$counter][5] = $row['id'];
					$counter++;
				}
			}				
			
			// every payment receipt
			$sql = 'select *, so.id as soID from sales_orders so, customers c
						where ' . $filter . ' and			
						so.customer_id=c.id and
						c.price_band!=4 and								
						left(so.payment_date,10)="' . $txnDate .'"
						order by so.payment_type, so.order_date, soID';							
			$sth = $db_handle->prepare($sql);
			if ($sth->execute()) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[4][$counter][0] = $row['soID'];
					$array[4][$counter][1] = $row['first_name'] . ' ' . $row['last_name'];
					$array[4][$counter][2] = $row['id'];
					$array[4][$counter][3] = $row['value'];
					$array[4][$counter][4] = substr($row['order_date'], 0, 10);
					$array[4][$counter][5] = $row['payment_type'];
					$array[4][$counter][6] = $row['add_info'];
					$counter++;
				}
			}					
			
			// every donation (recurring)
			$sql = 'select *, sum(soi.qty*soi.price) as total, sum(soi.qty) as qty_total
						from sales_order_items soi, sales_orders so, settings s
						where ' . $filter . ' and						
						soi.sales_order=so.id 
						and soi.type="D"
						and so.source=s.donation_default_source
						and left(so.order_date,10)="' . $txnDate . '"
						group by sku';	
			$sth = $db_handle->prepare($sql);
			if ($sth->execute()) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[5][$counter][0] = $row['sku'];
					$array[5][$counter][1] = $row['title'];
					$array[5][$counter][2] = $row['qty_total'];
					$array[5][$counter][3] = $row['total'];
					$counter++;
				}
			}			

			// every donation (non recurring)
			$sql = 'select *, sum(soi.qty*soi.price) as total, sum(soi.qty) as qty_total
						from sales_order_items soi, sales_orders so, settings s
						where ' . $filter . ' and						
						soi.sales_order=so.id 
						and soi.type="D"
						and so.source!=s.donation_default_source
						and left(so.order_date,10)="' . $txnDate . '"
						group by sku';						
			$sth = $db_handle->prepare($sql);
			if ($sth->execute()) {
				$counter = 0;
				while ($row = $sth->fetch()) {
					$array[6][$counter][0] = $row['sku'];
					$array[6][$counter][1] = $row['title'];
					$array[6][$counter][2] = $row['qty_total'];
					$array[6][$counter][3] = $row['total'];
					$counter++;
				}
			}			

			break;
		}		

	}
	echo json_encode($array);
?>