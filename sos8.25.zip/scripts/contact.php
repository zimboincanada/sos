<?php
include "db-conx.php";

$id = $_POST['id'];
$name = $_POST['name'];
$role = $_POST['role'];
$phone1 = $_POST['phone1'];
$phone2 = $_POST['phone2'];
$email = $_POST['email'];
$email2 = $_POST['email2'];
$fax = $_POST['fax'];
$address = $_POST['address'];
$notes = $_POST['notes'];
$churchID = $_POST['churchID'];

$result = new stdClass();
$result->status = 0;		// ok

try {
	$db_handle->beginTransaction();

	$sql = 'insert into contacts (id, name, role, phone_1, phone_2, email, email_2, fax, address, notes, church_id)
				values (?,?,?,?,?,?,?,?,?,?,?)
				on duplicate key
				update name=?, role=?, phone_1=?, phone_2=?, email=?, email_2=?, fax=?, address=?, notes=?';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(array(
		$id,
		$name, 
		$role, 
		$phone1, 
		$phone2, 
		$email, 
		$email2, 
		$fax, 
		$address, 
		$notes,
		$churchID,
		$name, 
		$role, 
		$phone1, 
		$phone2, 
		$email, 
		$email2, 
		$fax, 
		$address,
		$notes
	));
	
	if ($id == 'new')
		$id = $db_handle->lastInsertId();		

//	$result->status = $status;
	$result->id = $id;
	
	$db_handle->commit();
}
catch (Exception $e) {
	$db_handle->rollback();
	$result->status = -1;
	$result->message = $e;
}
	
echo json_encode($result);
?>