<?php
	include "db-conx.php";

	$result = "database update fail";
	$query = $_POST['query'];
	$key = $_POST['key'];
		
	switch($query) {		
		case 's2productMap': {
			try {
				$db_handle->beginTransaction();

				$s2productData = $_POST['s2productData'];
				
				for ($x=0; $x<sizeof($s2productData); $x++) {	
					$sql = "update products set s2_id=?, s2_hide_from_list=? where sku=?";
					$sth = $db_handle->prepare($sql);
					$sth->execute(array($s2productData[$x][2], $s2productData[$x][3], $s2productData[$x][0]));					
				}
				$db_handle->commit();
				$result = 'success';
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}				
			break;
		}
		
		case 'help': {			
			$sql = "insert into help 
						(topic, content)
						values (?,?)
						on duplicate key update
						topic = values(topic),
						content = values(content)";									
			$sth = $db_handle->prepare($sql);
			$sth->execute(array($_POST['key'], $_POST['content']));
			break;
		}
		
		case 'stockTake': {
			try {
				$db_handle->beginTransaction();

				$stockData = $_POST['stock_data'];
				
				for ($x=0; $x<sizeof($stockData); $x++) {	

					$qty = $stockData[$x][3];
					$note = 'Stock take level set';					

					$sql = "update products set qty=?, count_qty=0 where sku=?";
					$sth = $db_handle->prepare($sql);
					$sth->execute(array($qty, $stockData[$x][0]));
					
					// add the history record
					$sql = "insert into stock_adjustments
								(sku, qty, notes)
								values (?,?,?)";
					$sth = $db_handle->prepare($sql);
					$sth->execute(array($stockData[$x][0], $qty, $note));
				}
				$db_handle->commit();
				$result = 'success';
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}				
			break;
		}

		case 'savePO': {
			try {
				$db_handle->beginTransaction();

				// get supplier address
				$sql = 'select name, address from suppliers where id=?';
				$sth = $db_handle->prepare($sql);			
				$sth->execute(array($_POST['supplier_id']));
				$row = $sth->fetch();
				$supplierAddress = $row['name'] . "\n" . $row['address'];

				// insert header info
				$sql = "insert into purchase_orders
						(id, supplier_id, supplier_address, shipping_address, status)
						values (?,?,?,?,?)
						on duplicate key update
						id = values(id),
						supplier_id = values(supplier_id),
						supplier_address = values(supplier_address),
						shipping_address = values(shipping_address),				
						status = values(status)";				
				$sth = $db_handle->prepare($sql);
				$sth->execute(array($key, $_POST['supplier_id'], $supplierAddress, $_POST['shipping_address'], $_POST['status']));
				if ($key == '')
					$key = $db_handle->lastInsertId();
				
				// clear out existing data, then re-add below
				$sql = "delete from purchase_order_items where po_id=?";
				$sth = $db_handle->prepare($sql);
				$sth->execute(array($key));
				
				// add the po items
				$poBasketData = $_POST['po_basket_data'];
				for ($x=0; $x<sizeof($poBasketData); $x++) {	
					$sql = "insert into purchase_order_items
								(po_id, sku, qty_ordered, qty_received, cost)
								values (?,?,?,?,?)";
					$sth = $db_handle->prepare($sql);
					$sth->execute(array($key, $poBasketData[$x][0], $poBasketData[$x][2], $poBasketData[$x][3], $poBasketData[$x][4]));
				}
				$db_handle->commit();
				$result = $key;		// for new POs, 	return the ID for further processing and screen update
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}				
			break;
		}
		
		case 'saveSettings': {
			$result = new stdClass();
			
			$sql = "update settings set
							shipping_rate_pct=?,
							shipping_rate_max=?,
							shipping_folder=?,
							salutation=?,
							customer_source=?,
							payment_method=?,
							sales_order_source=?,
							country=?,
							countries=?,
							eu_countries=?,
							reports_exclude_payment_type=?,							
							backup_folder=?,
							cmi_address_1=?,
							cmi_address_2=?,
							cmi_address_3=?,
							cmi_address_4=?,
							cmi_address_5=?,
							cmi_address_6=?,
							use_multiple_payment_types=?,
							sales_order_gridlines=?,
							events_use_special_prices=?,
							sales_order_footer=?,
							back_order_slip_text=?,
							donation_default_source=?,
							donation_min_amount=?,
							donation_letter=?,
							donation_receipt_footer=?,
							recurring_donations=?,
							current_print=?,
							current_digital=?,
							current_journal=?,
							cut_off_period=?,
							cut_off_period_j=?,
							cut_off_period_d=?,
							subs_country_code=?,
							subs_letters_margin=?,
							subs_gift_renewal_margin=?,
							source_to_exclude_sub=?,
							s2active=?,
							sos_server_name=?,
							welcome_letter=?,
							gift_letter=?,
							gift_renewal_letter=?,
							welcome_letter_j=?,
							gift_letter_j=?,
							gift_renewal_letter_j=?,
							tax_band_1=?,
							tax_band_2=?,
							tax_band_3=?,
							tax_band_4=?,
							tax_band_label_1=?,
							tax_band_label_2=?,
							tax_band_label_3=?,
							tax_band_label_4=?,
							uk_shipping_band_1=?,
							uk_shipping_band_2=?,
							uk_shipping_band_3=?,
							uk_shipping_band_4=?,
							login_timeout=?,
							church_status=?,
							church_denominations=?,
							presentation_type=?,
							event_status=?,
							event_source=?,
							document_status=?,
							regions=?
							where id=1";
				
			$sth = $db_handle->prepare($sql);
			$result->status = $sth->execute(array($_POST['shipping_rate_pct'],
															$_POST['shipping_rate_max'],
															$_POST['shipping_folder'],
															$_POST['salutation'],
															$_POST['customer_source'],
															$_POST['payment_method'],
															$_POST['sales_order_source'],
															$_POST['country'],
															$_POST['countries'],
															$_POST['eu_countries'],
															$_POST['reports_exclude_payment_type'],
															$_POST['backup_folder'],
															$_POST['cmi_address_1'],
															$_POST['cmi_address_2'],
															$_POST['cmi_address_3'],
															$_POST['cmi_address_4'],
															$_POST['cmi_address_5'],
															$_POST['cmi_address_6'],
															$_POST['use_multiple_payment_types'],
															$_POST['sales_order_gridlines'],
															$_POST['events_use_special_prices'],
															$_POST['sales_order_footer'],
															$_POST['back_order_slip_text'],
															$_POST['donation_default_source'],
															$_POST['donation_min_amount'],
															$_POST['donation_letter'],
															$_POST['donation_receipt_footer'],
															$_POST['recurring_donations'],
															$_POST['current_print'],
															$_POST['current_digital'],
															$_POST['current_journal'],
															$_POST['cut_off_period_p'],
															$_POST['cut_off_period_j'],
															$_POST['cut_off_period_d'],
															$_POST['subs_country_code'],
															$_POST['subs_letters_margin'],
															$_POST['subs_gift_renewal_margin'],
															$_POST['subs_source_to_exclude_sub'],
															$_POST['s2active'],
															$_POST['sos_server_name'],
															$_POST['welcome_letter'],
															$_POST['gift_letter'],
															$_POST['gift_renewal_letter'],
															$_POST['welcome_letter_j'],
															$_POST['gift_letter_j'],
															$_POST['gift_renewal_letter_j'],
															$_POST['tax_band_1'],
															$_POST['tax_band_2'],
															$_POST['tax_band_3'],
															$_POST['tax_band_4'],
															$_POST['tax_band_label_1'],
															$_POST['tax_band_label_2'],
															$_POST['tax_band_label_3'],
															$_POST['tax_band_label_4'],
															$_POST['uk_shipping_band_1'],
															$_POST['uk_shipping_band_2'],
															$_POST['uk_shipping_band_3'],
															$_POST['uk_shipping_band_4'],
															$_POST['login_timeout'],
															$_POST['church_status'],
															$_POST['church_denominations'],
															$_POST['presentation_type'],
															$_POST['event_status'],
															$_POST['event_source'],
															$_POST['document_status'],
															$_POST['regions']
															));
			
			if ($result->status == false) {
				$result->errorMessage = $sth->errorInfo();
				break;
			}
			
			$sql = 'delete from event_todo_item_defaults';				
			$sth = $db_handle->prepare($sql);
			$result->status = $sth->execute();
			if ($result->status == false) {
				$result->errorMessage = $sth->errorInfo();
				break;
			}

			$todos = $_POST['eventTodos'];
			for ($x=0; $x<sizeof($todos); $x++) {
				$sql = 'insert into event_todo_item_defaults set item=?, offset_date_type=?, offset_from_date=?';
				$sth = $db_handle->prepare($sql);
				$result->status = $sth->execute(array($todos[$x][0], $todos[$x][1], $todos[$x][2]));
				if ($result->status == false) {
					$result->errorMessage = $sth->errorInfo();
					break;
				}
			}	
			
//			$result = 'success';
			break;
		}		
		
		case 'updateCustomer': {
			try {
				$db_handle->beginTransaction();						
				$sql = "
					insert into customers 
					(id, salutation, first_name, last_name, organization, address, address_2, city, province,
					postal_code, country, phone1, phone2, email1, email2, source, gift_aid, courtesy_call_complete, follow_up_required, friend_of_cmi,
					prayer_news, update_news, no_cem, no_mail, price_band, notes, access_number, account_balance)
					values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
					on duplicate key update
					salutation=values(salutation), 
					first_name=values(first_name), 
					last_name=values(last_name),
					organization=values(organization),
					address=values(address),
					address_2=values(address_2),
					city=values(city),
					province=values(province),
					postal_code=values(postal_code),
					country=values(country),
					phone1=values(phone1),
					phone2=values(phone2),
					email1=values(email1),
					email2=values(email2),
					source=values(source),
					gift_aid=values(gift_aid),
					courtesy_call_complete=values(courtesy_call_complete),
					follow_up_required=values(follow_up_required),
					friend_of_cmi=values(friend_of_cmi),
					prayer_news=values(prayer_news),
					update_news=values(update_news),
					no_cem=values(no_cem),
					no_mail=values(no_mail),
					price_band=values(price_band),
					notes=values(notes),
					access_number=values(access_number),
					account_balance=values(account_balance)";
						
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array(
					$key,
					$_POST['salutation'],
					$_POST['first_name'],
					$_POST['last_name'],
					$_POST['organization'],
					$_POST['address'],
					$_POST['address_2'],
					$_POST['city'],
					$_POST['province'],
					$_POST['postal_code'],
					$_POST['country'],
					$_POST['phone1'],
					$_POST['phone2'],
					$_POST['email1'],
					$_POST['email2'],
					$_POST['source'],
					$_POST['gift_aid'],
					$_POST['courtesy_call_complete'],
					$_POST['follow_up_required'],
					$_POST['friend_of_cmi'],
					$_POST['prayer_news'],
					$_POST['update_news'],
					$_POST['no_cem'],
					$_POST['no_mail'],
					$_POST['price_band'],
					$_POST['notes'],		
					$_POST['access_number'],
					$_POST['account_balance']
				));		
				
				// need the id back to display on-screen and for saves on edit
				if ($key == 0)
					$customerID = $db_handle->lastInsertId();
				else
					$customerID = $key;

				// set up an s2 update transaction, but only if the customer has subs
				if (customerHasSubs($customerID)) {
					$sql = 'insert into s2_log set type=?, customer_id=?';
					$sth = $db_handle->prepare($sql);
					$sth->execute(array('C', $customerID));
				}
								
				$result = array('status' => 'success', 'id' => $customerID);			
				$db_handle->commit();
			}
			catch (Exception $e) {
				$result = array('status' => 'fail');
				$db_handle->rollback();
			}					
			break;
		}

		case 'unlockCustomer': {
			$sql = "update customers set rec_lock=0 where id=?";
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($key));
			
			if ($status) $result = 'success';	
			break;
		}		

		case 'lockCustomer': {
			$result = 0;	// assume cannot get exclusive lock
			
			$sql = "select rec_lock from customers where id=?";
			$sth = $db_handle->prepare($sql);			
			if ($sth->execute(array($key))) {
				$row = $sth->fetch();

				if ($row['rec_lock'] == 0) {		// record is available for lock
					$sql = "update customers set rec_lock=1 where id=?";			
					$sth = $db_handle->prepare($sql);
					$status = $sth->execute(array($key));
					
					if ($status) $result = 1;		// we have a lock
				}
			}			
			break;
		}		

		case 'clearLocks': {
			$sql = "update customers set rec_lock=''";
					
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute();		
			if ($status) $result = 'success';
			break;
		}		
		
		case 'updateSalesOrder': {
			$sql = "update sales_orders set
						order_date=?,
						notes=?,
						source=?,
						payment_type=?,
						payment_date=?,
						add_info=?,
						ship_address_1=?,
						ship_address_2=?,
						ship_address_3=?,
						ship_address_4=?,
						ship_address_5=?,
						ship_address_6=?,
						ship_address_7=?,
						payment_type_1=?,
						payment_amount_1=?,
						payment_info_1=?,
						payment_type_2=?,
						payment_amount_2=?,
						payment_info_2=?,
						payment_type_3=?,
						payment_amount_3=?,
						payment_info_3=?,
						payment_type_4=?,
						payment_amount_4=?,
						payment_info_4=?,
						payment_type_5=?,
						payment_amount_5=?,
						payment_info_5=?,
						payment_type_6=?,
						payment_amount_6=?,
						payment_info_6=?,
						updated_by=?
						where id=?";
					
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($_POST['order_date'],
																$_POST['notes'],
																$_POST['source'],
																$_POST['payment_type'],												
																$_POST['payment_date'],												
																$_POST['add_info'],										
																$_POST['ship_address_1'],
																$_POST['ship_address_2'],													
																$_POST['ship_address_3'],													
																$_POST['ship_address_4'],													
																$_POST['ship_address_5'],													
																$_POST['ship_address_6'],
																$_POST['ship_address_7'],
																$_POST['payment_type_1'],
																$_POST['payment_amount_1'],
																$_POST['payment_info_1'],
																$_POST['payment_type_2'],
																$_POST['payment_amount_2'],
																$_POST['payment_info_2'],
																$_POST['payment_type_3'],
																$_POST['payment_amount_3'],
																$_POST['payment_info_3'],
																$_POST['payment_type_4'],
																$_POST['payment_amount_4'],
																$_POST['payment_info_4'],
																$_POST['payment_type_5'],
																$_POST['payment_amount_5'],
																$_POST['payment_info_5'],
																$_POST['payment_type_6'],
																$_POST['payment_amount_6'],
																$_POST['payment_info_6'],
																$_POST['updated_by'],
																$key										
																));
			
			if ($status) $result = 'success';
			break;
		}
		
		case 'mergeCustomers': {
			// $key = primary customer
			$duplicate = $_POST['duplicate'];

			try {
				$db_handle->beginTransaction();

				// step 1 - move mags subs from duplicate account ($duplicate) to primary account ($key)
				$sql = "update mag_subs set recipient_id=? where recipient_id=?";
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($key, $duplicate));					

				// step 2 - move sales orders from duplicate account ($duplicate) to primary account ($key)
				$sql = "update sales_orders set customer_id=? where customer_id=?";
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($key, $duplicate));	

				// step 3 - remove duplicate account from main customers table
				$sql = 'delete from customers where id=?';
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($duplicate));	
				
				$db_handle->commit();
				$result = 'success';
			}
			catch (Exception $e) {
				$db_handle->rollback();
			}
			
			break;
		}
	}
	echo json_encode($result);

	function customerHasSubs($customerID) {
		global $db_handle;

		$sql = "select count(*) as numSubs from mag_subs where recipient_id=?";
		$st = $db_handle->prepare($sql);
		$st->execute(array($customerID));
		$result = $st->fetch();

		return $result['numSubs'] > 0;
	}
?>