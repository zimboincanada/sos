<?php

/* 	User imports a csv file (generated from master price list excel sheet)
	This script uploads the file into uploads folder and then replaces the products data by lookup on sku
	
	BULK PRICES column:
	Format is qty-price, qty-price, etc.
	Example: 10-1.80,20-1.50,50-1.25
	
	PACK column: (0 or 1)
	After importing products from MPL ensure packs have component items assigned
*/
$label = $_POST["label"];
$filename = $label.$_FILES["file"]["name"];
if (move_uploaded_file($_FILES["file"]["tmp_name"], "../uploads/" . $filename)) {
	$data = readMPL($filename);
	echo importData($data);
}
else
	echo 'Failed to upload file.';
//echo importData($data);

function readMPL($filename) {
	$data = array();
	$x = 0;
	$mpl = fopen("../uploads/" . $filename, "r");
//	$mpl = fopen("c:/../uploads/products.csv", "r");

	while(! feof($mpl)) {
		$line = fgetcsv($mpl);
//echo $line[1] . '<br>';
		$data[$x] = $line;
		$x++;
	}
	
	return $data;
}

function importData($data) {
	include "db-conx.php";

	$success = 0;
	
	try {
		$db_handle->beginTransaction();
		
		$sql = 'update products set status=0';		// set everything to inactive
		$sth = $db_handle->prepare($sql);
		$sth->execute();
		
		for ($x=0; $x<count($data); $x++) {
//echo $data[$x][0];
			$sql = "insert into products
						(category, sku, title, price, special_price, staff_price, wholesale_price, type, sub_type, term, shipping_calc, digital, pack, sp_from, sp_to, status, bulk_prices)
						values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
						on duplicate key update
						category = values(category),
						sku = values(sku),
						title = values(title),
						price = values(price),
						staff_price = values(staff_price),
						special_price = values(special_price),
						wholesale_price = values(wholesale_price),
						type = values(type),
						sub_type = values(sub_type),
						term = values(term),
						shipping_calc = values(shipping_calc),
						digital = values(digital),
						pack = values(pack),
						sp_from = values(sp_from),
						sp_to = values(sp_to),
						status = values(status),
						bulk_prices = values(bulk_prices)";

			$sth = $db_handle->prepare($sql);
			$sth->execute(array(
				$data[$x][0],
				$data[$x][1], 
				$data[$x][2], 
				$data[$x][3], 
				$data[$x][4], 
				$data[$x][5], 
				$data[$x][6], 
				$data[$x][7], 
				$data[$x][8], 
				$data[$x][9], 
				$data[$x][10], 
				$data[$x][11], 
				$data[$x][12], 
				$data[$x][13], 
				$data[$x][14], 
				1,					// active
				$data[$x][15]
			));
		}
			
		$db_handle->commit();
		$success = 1;
	}
	catch (PDOException $e) {
		$db_handle->rollback();
		$success = $e->getMessage();
	}	
	
	return $success;
}
?>