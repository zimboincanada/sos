<?php
/* 	User imports a csv file
	This script uploads the file into uploads folder and then reads and returns the read data
	
	CSV file needs 3 columns - 	CUST ID, 
											DONATION AMOUNT, 
											SKU TO BE USED FOR SALES ORDER
*/
$label = $_POST["label"];
$filename = $label.$_FILES["file"]["name"];
if (move_uploaded_file($_FILES["file"]["tmp_name"], "../uploads/" . $filename)) {
	$data = readXL($filename);	
	$data = getCustomerData($data);
	
	echo json_encode($data);
}
else
	echo 'Failed to upload file.';

function readXL($filename) {
	$data = array();
	$x = 0;
	$mpl = fopen("../uploads/" . $filename, "r");

	while(! feof($mpl)) {
		$line = fgetcsv($mpl);
		$data[$x] = $line;
		$x++;
	}
	
	return $data;
}

function getCustomerData($data) {
	include "db-conx.php";

	// 0=id, 1=amount, 2=sku
	$fullData = [];
	$next = 0;
	for ($x=0; $x<count($data); $x++) {

		$sql = "select id, first_name, last_name, (select sku from products where sku='" . $data[$x][2] ."') as sku, gift_aid from customers where id=" . $data[$x][0];

		$sth = $db_handle->prepare($sql);
		$sth->execute();
		$customer = $sth->fetch();

		if ($customer['sku'] == '') 
			$sku = '** error';
		else
			$sku = $customer['sku'];
		
		$amount = $data[$x][1];
		if ($customer['id'] != '' && $amount != 0) {
			$fullData[$next] = [$customer['id'], $customer['first_name'], $customer['last_name'], $amount, $sku, $customer['gift_aid']];
			$next++;
		}
	}
	
	return $fullData;
}
?>