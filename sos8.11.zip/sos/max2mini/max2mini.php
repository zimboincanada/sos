<?php

/*
1. look at events with no date
*/

set_time_limit(500);

$server = "localhost";
$database = "sos";
$username = "root";
$password = "";
$db_handle = new PDO("mysql:host=$server;dbname=$database", $username, $password);

//doBob('T');
$log = fopen("log.txt", "w") or die("Unable to open file!");
$sql = 'SET FOREIGN_KEY_CHECKS=0';
$sth = $db_handle->prepare($sql);
$status = $sth->execute();
addChurches();
addContacts();
addTours();
addEvents();
addEventTalks();
fclose($log);

function addChurches() {
	
	global $log, $db_handle;

	$sql = 'delete from churches';
	$sth = $db_handle->prepare($sql);
	$sth->execute();
		
	$id = 1;
	$name = 2;
	$address = 5;
	$city = 6;
	$county = 7;
	$region = 8;
	$phone = 14;
	$postal_code = 21;
	
	$source = fopen("churches.csv", "r") or die("Unable to open file!");
	while(! feof($source)) {
		
		$line = fgetcsv($source);
echo $line[$id] . '<br>';
		
		$sql = "insert into churches
					(id, name, address, city, county, postal_code, region, phone, status)
					values (?,?,?,?,?,?,?,?,?)";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($line[$id], 
														$line[$name], 
														$line[$address], 
														$line[$city],
														$line[$county], 
														$line[$postal_code], 
														$line[$region], 
														$line[$phone], 
														'Warm'));	
	
	}
}

function addContacts() {
	
	global $log, $db_handle;

	$sql = 'delete from contacts';
	$sth = $db_handle->prepare($sql);
	$sth->execute();
		
//	$id = 0;
	$church_id = 1;
	$fname = 3;
	$lname = 4;
	$email = 11;
	$phone_1 = 14;
	$role = 16;
//	$phone_2 = 5;
//	$address = 8-12;
	
	$source = fopen("contacts.csv", "r") or die("Unable to open file!");
	while(! feof($source)) {
		
		$line = fgetcsv($source);
		
		$address = ($line[6] != '' ? $line[6] . "\n" : '');
		$address .= ($line[7] != '' ? $line[7] . "\n" : '');
		$address .= ($line[8] != '' ? $line[8] . "\n" : '');
		$address .= ($line[21] != '' ? $line[21] . "\n" : '');
		$address .= ($line[17] != '' ? $line[17] . "\n" : '');
		
		$name = $line[$fname] . ' ' . $line[$lname];
		
		$sql = "insert into contacts
					(church_id, name, role, phone_1, email, address)
					values (?,?,?,?,?,?)";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($line[$church_id], 
														$name, 
														$line[$role],
														$line[$phone_1], 
														$line[$email], 
														$address));	
	
	}
}

function addTours() {
	
	global $log, $db_handle;

	$sql = 'delete from tours';
	$sth = $db_handle->prepare($sql);
	$sth->execute();
		
	$id = 1;
	$name = 2;
	$start_date = 3;
	$end_date = 3;
	$region = 9;
	
	$source = fopen("tours.csv", "r") or die("Unable to open file!");
	while(! feof($source)) {
		
		$line = fgetcsv($source);
		
		$sql = "insert into tours
					(id, name, start_date, end_date, region)
					values (?,?,?,?,?)";
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(array($line[$id], 
														$line[$name], 
														$line[$start_date], 
														$line[$end_date],
														$line[$region]));	
	
	}
}

function xxxxxxxxxxxxxxxxxxbob() {
	
	global $log, $db_handle;

	$id = 3;
	$church_id = 2;
	$speaker = 4;
	$event_date = 5;
	$attendance = 7;
	$tour_id = 9;
	$address = '';
//	$event_status = 'Open';
	$meeting_type = 12;

	$today = date('Y-m-d');
	
$cnt = 0;

	$source = fopen("events.csv", "r") or die("Unable to open file!");
	while(! feof($source)) {
		
$cnt++;
		$line = fgetcsv($source);
echo $cnt, ' event id=', $line[$id], ' church id=', $line[$church_id], ' mtg type=', $line[$meeting_type], ' x=', $line[13] . '<br>';

	}
}

function addEvents() {
	
	global $log, $db_handle;

	$sql = 'delete from events';
	$sth = $db_handle->prepare($sql);
	$sth->execute();

	$sql = 'delete from event_todo_items';
	$sth = $db_handle->prepare($sql);
	$sth->execute();
	
	$id = 2;
	$church_id = 3;
	$speaker = 6;
	$event_date = 7;
	$attendance = 9;
	$tour_id = 11;
	$address = '';
//	$event_status = 'Open';
	$meeting_type = 14;

	$today = date('Y-m-d');
	
	$sql = 'select * from event_todo_item_defaults';
	$sth = $db_handle->prepare($sql);
	$status = $sth->execute(); 	
	$todos = array();
	while ($settings = $sth->fetch()) {
		array_push($todos, array($settings['item'], $settings['offset_date_type'], $settings['offset_from_date']));
//echo $todos[0];
	}
	
//	for ($x=0; $x<sizeof($todos); $x++)
//		echo $todos[$x][2] . '<br>';
//echo $settings[0], $today;
//	$todos = explode(',', $settings[0]);
//echo sizeof($todos);
//return;
$cnt = 0;

	$source = fopen("events.csv", "r") or die("Unable to open file!");
	while(! feof($source)) {
		
$cnt++;
		$line = fgetcsv($source);
echo $cnt, ' church id=', $line[$church_id], ' mtg type=', $line[$meeting_type] . '<br>';

		$sql = 'select * from churches where id=' . $line[$church_id];
		$sth = $db_handle->prepare($sql);
		$status = $sth->execute(); 
		
		if ($status == '1') {
			$church = $sth->fetch();

			$sql = "insert into events
						(id, church_id, event_date, speaker, attendance_expected, address, city, county, postal_code, region, status, tour_id, presentation_type)
						values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
			$sth = $db_handle->prepare($sql);
			$sth->execute(array( $line[$id],
												$line[$church_id], 
												$line[$event_date], 
												$line[$speaker], 
												$line[$attendance],	
												$church['address'],	
												$church['city'],	
												$church['county'],	
												$church['postal_code'],	
												$church['region'],	
												($line[$event_date]>=$today ? 'Open' : 'Complete'),	
												$line[$tour_id],
												$line[$meeting_type]));	
												
			$eventID = $db_handle->lastInsertId();
															
//echo '>' . $status . '< ' . $line[$id] . ' ' . $church['id'] . ' ' . $church['address'] . '<br>';
//echo '>', $line[$event_date], '<  >', $today, '<<br>';
															
			if ($line[$event_date] < $today) {		
				$sql = "insert into event_todo_items
							(event_id, item, complete, due)
							values (?,?,?,?)";
				$sth = $db_handle->prepare($sql);
				$status = $sth->execute(array($eventID, 
																'Transfer from WebMax',
																1,
																$today));	
			}
			else {
				for ($x=0; $x<sizeof($todos); $x++) {

					$basedOnDate =	$todos[$x][1] == 'B' ? $today : $line[$event_date];		// default based either on 'booking' or 'event'
					$offset = $todos[$x][2];
					$todoDate = date('Y-m-d', strtotime($basedOnDate . '+' . $offset. ' days'));			
					
					$sql = "insert into event_todo_items
								(event_id, item, complete, due)
								values (?,?,?,?)";
					$sth = $db_handle->prepare($sql);
					$sth->execute(array(
						$eventID, 
						$todos[$x][0],
						0,
						$todoDate
					));					
				}
			}
			
		}
	}
}

function addEventTalks() {
	
	global $log, $db_handle;
	
//$time2 = '8:00 AM';
//echo date('Hi', strtotime($time2)) . '<br>';//time2 
//$time2 = '8:00AM';
//echo date('Hi', strtotime($time2)) . '<br>';//time2 
//$time2 = '8:00am';
//echo date('Hi', strtotime($time2)) . '<br>';//time2 
//$time2 = '8am';
//echo date('Hi', strtotime($time2)) . '<br>';//time2 
//outputs 0800 in correct military time	
//return;

	$sql = 'delete from event_talks';
	$sth = $db_handle->prepare($sql);
	$sth->execute();
		
	$event_id = 2;
	$talk = 11;
	$time = 12;
	
	$source = fopen("event_talks.csv", "r") or die("Unable to open file!");
	while(! feof($source)) {
		
		$line = fgetcsv($source);
		
		$talks = explode('xxx', $line[$talk]);
		$talksLen = sizeof($talks);
		$baseTalk = $talks[0];

		$times = explode('&', $line[$time]);
		$timesLen = sizeof($times);
		$baseTime = $times[0];
		if ($baseTime == 'TBA')
			$baseTime = '';
//$baseTime = 'TBA';

		$len = ($talksLen > $timesLen) ? $talksLen : $timesLen;
		
		for ($x=0; $x<$len; $x++) {
			if ($timesLen == $talksLen) {
				$theTime = $times[$x];
				$theTalk = $talks[$x];
			}
			else if ($timesLen > $talksLen) {
				$theTime = $times[$x];
				$theTalk = $baseTalk;
			}
			else {
				$theTime = $baseTime;
				$theTalk = $talks[$x];
			}

			$theTalk = str_replace('+', '', $theTalk);
			
			if ($theTime == '' || $theTime == 'TBA')
				$theConvertedTime = '';
			else
				$theConvertedTime = date('Hi', strtotime($theTime));
			
			if (strpos($theTime, 'aily') !== false)
				$daily = 1;
			else
				$daily = 0;
//echo $len . ' ' . $line[2] . ' ' . $theTalk . ' ' . $theTime . ' ' . $theConvertedTime . ' ' . $daily . '<br>';

			$sql = "insert into event_talks
						(event_id, talk, time, daily)
						values (?,?,?,?)";
			$sth = $db_handle->prepare($sql);
			$status = $sth->execute(array($line[$event_id], 
															$theTalk, 
															$theConvertedTime . '00',
															$daily
													));	
		}
	
	}
}
?>