<?php
$folder = $_GET['folder'];

if (makeDir($folder))
	echo json_encode(copyFile($folder));
else	
	echo json_encode(0);

function makeDir($folder) {
	return is_dir($folder) || mkdir($folder);
}

function copyFile($folder) {
	$backupFile = $folder . '\sos.sql';		
	
	$str = 'c:\wamp\bin\mysql\mysql5.6.17\bin\mysqldump --routines=true --events -u root sos > ' .$backupFile;
	exec($str, $output, $retval);
	
	if (!$retval)
		return 1;
	else
		return [0, $retval];
}
?>