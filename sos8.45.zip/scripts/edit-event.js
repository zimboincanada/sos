// EVENTS........

function event() {	
	this.editEvent = function(id) {		
		var obj = this;
		
		$('#event-presentation-type-label').html('Presentation type:');
		$('#event-gift-label').html('Gift:');
		$('#event-gift-pledged-label').hide();
		if (global.isCA) {
			$('#event-presentation-type-label').html('Event type:');
			$('#event-gift-label').html('Honorarium received:');
			$('#event-gift-pledged-label').show();
		}

		this.getChurchContacts();
		
		this.unsavedEvent = false;
		this.eventTodoItemsCreated = false;
		$('#event-panel').on('change', function(el) {
//console.log(el)			
			if (el.target.id == 'event-document-status' || el.target.id == 'event-document-status-date')	// these are subject to a separate 'save' button
				return;
			obj.unsavedEvent = true;
		});

		// show running total of sales
		$('#event-sales-cash, #event-sales-cheque, #event-sales-card, #event-sales-invoice').on('input', function() {
			obj.showEventSalesTotal();
		});
		
		document.getElementById('event-panel').overlay = doOverlay(true, 'event-panel');
		document.getElementById('event-panel').style.display = 'block';
		this.currentEvent = id;
		$('#event-talks').html('');

		if (id == 'new') {
			$('#event-name').val('');
			$('#event-contact').val('');
			$('#event-address').val('');
			$('#event-address-2').val('');
			$('#event-city').val('');
			$('#event-county').val('');
			$('#event-postal-code').val('');
			$('#event-region').val('');
			$('#event-latitude').val('');
			$('#event-longitude').val('');
			$('#event-use-church-address').prop('checked', false);
			$('#event-phone').val($('#church-phone').val());
			$('#event-no-web').prop('checked', false);
			$('#event-single-speaker').prop('checked', true);
			$('#event-speaking-time').val('');
			$('#event-kjv').prop('checked', false);
			$('#event-clipboards').prop('checked', true);
			$('#event-book-table').prop('checked', true);
			$('#event-ep').val(oLogin.login_uid);
			$('#event-attendance-expected').val('');
			$('#event-attendance-actual').val('');
			$('#event-attendance-actual-u18').val('');
			$('#event-accommodation-details').val('');
			$('#event-direction-details').val('');
			$('#event-gift-pledged').val('');
			$('#event-gift').val('');
			$('#event-gift-other').val('');
			$('#event-is-tour').prop('checked', false);
			$('#event-notes').val('');
			var option = $("#event-status option:first").text();
			$('#event-status').val(option);
			$('#event-source').val(option);
			$('#event-host-details').val('');
			$('#event-volunteer-details').val('');
			$('#event-cmi-equipment').val('');
			$('#event-access-time-details').val('');
			$('#event-itinerary-notes').val('');
			$('#event-leave-by-details').val('');
			$('#event-travel-details').val('');
			$('#event-presentation-type').attr('cmi-multiselect-value', '');		
			$('#event-webpage-id').val('');
			$('#event-magsubs').val('');
			$('#event-infobytes').val('');
			$('#event-comments').val('');
			$('#event-created-date').html(today());
			$('#event-sales-max').val(0);
			$('#event-sales-cash').val(0);
			$('#event-sales-cheque').val(0);
			$('#event-sales-card').val(0);
			$('#event-sales-invoice').val(0);
			
			obj.addEventTalk('', '', '', '', false);		// need at least 1 talk
			
			obj.dateFrom = '';
			obj.dateTo = '';
			
		}
		else {
			var sql = 'select * from events where id=' + id;
			execSQL(sql, function(data) {
				var event = data[0];
				$('#event-name').val(event.name);
				$('#event-contact').val(event.contact_name);
				$('#event-address').val(event.address);
				$('#event-address-2').val(event.address_2);
				$('#event-city').val(event.city);
				$('#event-county').val(event.county);
				$('#event-postal-code').val(event.postal_code);
				$('#event-region').val(event.region);
				$('#event-latitude').val(event.latitude);
				$('#event-longitude').val(event.longitude);
				$('#event-use-church-address').prop('checked', event.use_church_address == 1);
				$('#event-phone').val(event.phone);
				$('#event-no-web').prop('checked', event.no_web == 1);
				$('#event-single-speaker').prop('checked', event.single_speaker == 1)
				$('#event-speaking-time').val(event.speaking_time);
				$('#event-kjv').prop('checked', event.kjv == 1);
				$('#event-clipboards').prop('checked', event.clipboards == 1);
				$('#event-book-table').prop('checked', event.book_table == 1)
				$('#event-ep').val(event.event_planner);
				$('#event-attendance-expected').val(event.attendance_expected);
				$('#event-attendance-actual').val(event.attendance_actual);
				$('#event-attendance-actual-u18').val(event.attendance_actual_u18);
				$('#event-accommodation-details').val(event.accommodation_details);
				$('#event-direction-details').val(event.direction_details);
				$('#event-gift-pledged').val(event.gift_pledged);
				$('#event-gift').val(event.gift);
				$('#event-gift-other').val(event.gift_other);
				$('#event-tours').val(event.tour_id == 0 ? 1 : event.tour_id);
				$('#event-is-tour').prop('checked', event.tour_id > 0);
				$('#event-notes').val(event.notes);
				$('#event-status').val(event.status);
				$('#event-source').val(event.source);
				$('#event-host-details').val(event.host_contact_details);
				$('#event-volunteer-details').val(event.volunteer_details);
				$('#event-cmi-equipment').val(event.cmi_equipment);
				$('#event-access-time-details').val(event.access_time_details);
				$('#event-meal-details').val(event.meal_details);
				$('#event-itinerary-notes').val(event.itinerary_notes);
				$('#event-leave-by-details').val(event.leave_by_details);
				$('#event-travel-details').val(event.travel_details);
				$('#event-presentation-type').attr('cmi-multiselect-value', event.presentation_type);
				$('#event-webpage-id').val(event.webpage_id);
				$('#event-magsubs').val(event.magsubs);
				$('#event-infobytes').val(event.infobytes);
				$('#event-comments').val(event.comments);
				$('#event-created-date').html(event.created_date.substr(0, 10));
				$('#event-sales-max').val(event.sales_max);
				$('#event-sales-cash').val(event.sales_cash);
				$('#event-sales-cheque').val(event.sales_cheque);
				$('#event-sales-card').val(event.sales_card);
				$('#event-sales-invoice').val(event.sales_invoice);

				obj.dateFrom = event.event_date;
				obj.dateTo = event.event_date_to;
			
			}, false);

			// add event talks
			this.getEventTalks(id);		
			this.singleSpeakerCheck();

			// build todo list for this event
			this.getEventTodoItems(id);		
		}

		// multiselect for presentation type
		var ms = new multiSelect('event-presentation-type');
		ms.values = oSettings.presentation_type.split(',');
		ms.texts = oSettings.presentation_type.split(',');
		ms.height = '150px';
		ms.init();
					
		this.showEventSalesTotal();
		
		if ($('#event-is-tour').prop('checked'))
			$('#event-tours').show();
		else
			$('#event-tours').hide();
		
		$('#event-is-tour').on('change', function() {
			if ($('#event-is-tour').prop('checked'))
				$('#event-tours').show();
			else
				$('#event-tours').hide();
		});
		
		this.formatLogistics();

		global.setTabActive('event-tab-1', 'event-panel-1');
		$("#event-save-btn").show();

		this.refreshDialogTitle();
	}
	
	this.getChurchContacts = function() {
		var sql = 'select concat(c.first_name, " ", c.last_name) as name from church_contacts cc, customers c where c.id=cc.contact_id and cc.church_id=' + oChurch.details.id;		
		execSQL(sql, function(data) {
			var options = [];
		
			for (var x in data)
				options.push(data[x].name);
			fillPicklistWithData('event-contact-list', options, options);
		});
	}	

	this.formatLogistics = function() {
		$('#event-panel-4 div div').on('click', function() { 
			$('#event-panel-4 div div').removeClass('clicked');	// highlight menu option selected
			$(this).addClass('clicked');

			var field = $(this).attr('fld');		// show field for selected menu option
			$('.event-logistics-textbox').hide();
			$('#' + field).show().focus();

		});
		$('#event-panel-4 div:first-child').click();
	}

	// update display of sales breakdown
	this.showEventSalesTotal = function() {
		var total = Number($('#event-sales-cash').val()) + 
			Number($('#event-sales-cheque').val()) + 
			Number($('#event-sales-card').val()) + 
			Number($('#event-sales-invoice').val()) +
			Number($('#event-sales-max').val());

		$('#event-sales-total').html(formatCurrency(total));
	}

	this.listEventSpeakerTalks = function(speaker) {
		var sql = 'select title from talks t, customers c where t.speaker_id=c.id and concat(c.first_name," ",c.last_name)="' + speaker + '" and c.speaker=1';
		execSQL(sql, function(data) {
			var options = [];
			for (var x in data)
				options.push(data[x].title);
			fillPicklistWithData('event-talk-list', options, options);
		});
	}
	
	this.getEventTalks = function(eventID) {
		var obj = this;
		var sql = 'select * from event_talks where event_id=' + eventID;
		execSQL(sql, function(data) {
			for (var x in data) {
				obj.addEventTalk(data[x].speaker, data[x].talk, data[x].talk_date, data[x].time, (data[x].daily == 1));
			}
		}, false);
	}

	this.closeEvent = function() {
		if (this.unsavedEvent) {		
			confirmBox(
				"ATTENTION", 
				"You made changes but haven't saved them.", 
				["Back to Edit", "OK, lose the changes"],
				[ function() {}, function() {				
					document.getElementById('event-panel').style.display = 'none';
					doOverlay(false, document.getElementById('event-panel').overlay);
				} ]
			);		
		}
		else {
			document.getElementById('event-panel').style.display = 'none';
			doOverlay(false, document.getElementById('event-panel').overlay);
		}
	}

	this.saveEvent = function() {
		var obj = this;
		
		if (!formValidated('event-panel'))
			return;
		
		var eventTalks = [];
		var talks = $('#event-talks').children();
		for (var x=0; x<talks.length; x++) {
			var speaker = talks[x].getElementsByClassName('event-speaker')[0].value;
			var talk = talks[x].getElementsByClassName('event-talk')[0].value;
			var date = talks[x].getElementsByClassName('event-date')[0].value;
			var time = talks[x].getElementsByClassName('event-time')[0].value;
			var daily = talks[x].getElementsByClassName('event-daily')[0].checked;
			eventTalks[x] = [speaker, talk, date, time, (daily ? 1 : 0)];
		}
		this.recalcEventDates(eventTalks);

//console.log('df=',this.dateFrom)
		if (this.dateFrom == '') {
			alertBox("Can't save the Event without an event date");
			return;
		}
				
//console.log(this.dateFrom, this.dateTo)
		if (this.currentEvent == 'new')
			this.createEventTodoItems();		

		var eventTodos = [];
		var todos = $("#event-todo-items").children();
		for (var x=0; x<todos.length; x++) {
			var item = todos[x].getElementsByClassName("event-todo-item")[0].value;
			var complete = todos[x].getElementsByClassName("event-todo-complete")[0].checked;
			var due = todos[x].getElementsByClassName("event-todo-date")[0].value;
			var eventPlanner = todos[x].getElementsByClassName("event-todo-ep")[0].value;
			eventTodos[x] = [item, (complete ? 1 : 0), due, eventPlanner];	
		}
		
		var isNew = (this.currentEvent == 'new');
//console.log(obj.dateFrom, obj.dateTo)		
		$.ajax({
			type: 'post',
			url: "scripts/event.php",
			cache: false,
			data: { 
				id: this.currentEvent,
				name: $('#event-name').val(),
				contactName: $('#event-contact').val(),
				phone: $('#event-phone').val(),
				eventDate: obj.dateFrom,
				eventDateTo: obj.dateTo,
				noWeb: $('#event-no-web').prop('checked') == true ? 1 : 0,
				eventTalks: eventTalks,
				singleSpeaker: $('#event-single-speaker').prop('checked') == true ? 1 : 0,
				speakingTime: $('#event-speaking-time').val(),
				kjv: $('#event-kjv').prop('checked') == true ? 1 : 0,
				clipboards: $('#event-clipboards').prop('checked') == true ? 1 : 0,
				bookTable: $('#event-book-table').prop('checked') == true ? 1 : 0,
				eventPlanner: $('#event-ep').val(),
				attendanceExpected: $('#event-attendance-expected').val(),
				address: $('#event-address').val(),
				address2: $('#event-address-2').val(),
				city: $('#event-city').val(),
				county: $('#event-county').val(),
				postalCode: $('#event-postal-code').val(),
				region: $('#event-region').val(),
				latitude: $('#event-latitude').val(),
				longitude: $('#event-longitude').val(),
				useChurchAddress: $('#event-use-church-address').prop('checked') == true ? 1 : 0,
				accommodationDetails: $('#event-accommodation-details').val(),
				attendanceActual: $('#event-attendance-actual').val(),
				attendanceActualU18: $('#event-attendance-actual-u18').val(),
				directionDetails: $('#event-direction-details').val(),
				giftPledged: $('#event-gift-pledged').val(),
				gift: $('#event-gift').val(),
				giftOther: $('#event-gift-other').val(),
				tourID: $('#event-is-tour').prop('checked') ? $('#event-tours').val() : 0,
				notes: $('#event-notes').val(),
				status: $('#event-status').val(),
				source: $('#event-source').val(),
				churchID: oChurch.details.id,
				hostDetails: $('#event-host-details').val(),
				volunteerDetails: $('#event-volunteer-details').val(),
				cmiEquipment: $('#event-cmi-equipment').val(),
				accessTimeDetails: $('#event-access-time-details').val(),
				itineraryNotes: $('#event-itinerary-notes').val(),
				leaveByDetails: $('#event-leave-by-details').val(),
				travelDetails: $('#event-travel-details').val(),
				mealDetails: $('#event-meal-details').val(),
				presentationType: $('#event-presentation-type').attr('cmi-multiselect-value'),
				webpageID: $('#event-webpage-id').val(),
				magSubs: $('#event-magsubs').val(),
				infobytes: $('#event-infobytes').val(),
				comments: $('#event-comments').val(),
				salesCash: $('#event-sales-cash').val(),
				salesCheque: $('#event-sales-cheque').val(),
				salesCard: $('#event-sales-card').val(),
				salesInvoice: $('#event-sales-invoice').val(),
				eventTodos: eventTodos
			},
			success: function(result) { 	
//console.log(result.id)			
				if (result.success) {
					if (isNew)	{	// celebrate
						obj.celebrateNewEvent();
					}
						
					obj.unsavedEvent = false;				
	//				oChurch.closeEvent();
					obj.currentEvent = result.id;
					statusMsg('Event details saved.');
				
					if (oChurch.eventMode == 'church')
						oChurch.listEvents();
					else	
						oEvents.listEvents();
					
					log('EPIC EVENT UPDATED', oChurch.details.name + ', event date=' + $('#event-date').val());
				}
				else
					alertBox(result.errorMessage);
			},
			error: function(xhr) {
				alertBox(xhr.responseText);
			},
			dataType: 'json'
		});		
	}

	this.celebrateNewEvent = function() {	
		$('#system-icon').attr("src", 'images/book-event.gif');
		setTimeout(function() {
			$('#system-icon').attr("src", 'images/sos-icon.gif');
		}, 2000);					
	}
	
	this.setEventAddress = function(set) {
		if (set) {
			$('#event-address').val(oChurch.details.address).prop('disabled', true);
			$('#event-address-2').val(oChurch.details.address_2).prop('disabled', true);
			$('#event-city').val(oChurch.details.city).prop('disabled', true);
			$('#event-county').val(oChurch.details.county).prop('disabled', true);
			$('#event-postal-code').val(oChurch.details.postal_code).prop('disabled', true);
			$('#event-region').val(oChurch.details.region).prop('disabled', true);
		}
		else {
			$('#event-address').val('').prop('disabled', false);
			$('#event-address-2').val('').prop('disabled', false);
			$('#event-city').val('').prop('disabled', false);
			$('#event-county').val('').prop('disabled', false);
			$('#event-postal-code').val('').prop('disabled', false);
			$('#event-region').val('').prop('disabled', false);
		}
	}
	
	this.addEventTalk = function(theSpeaker, theTalk, theDate, theTime, daily) {
		var obj = this;
		
		var line = document.createElement('li');
		document.getElementById('event-talks').appendChild(line);
		line.className = "ui-state-default";

		var handle = document.createElement('span');
		line.appendChild(handle);
		handle.className = "event-talk-handle";
		handle.innerHTML = '&udarr;';
		
		var speaker = document.createElement('input');
		line.appendChild(speaker);
		speaker.className = "event-speaker";
		$(speaker).attr('list', "event-speakers-list");
		speaker.value = theSpeaker;
		$(speaker).on('change', function() { 
			obj.singleSpeakerCheck();
			obj.listEventSpeakerTalks(this.value);
		});
		
		var talk = document.createElement('input');
		line.appendChild(talk);
		talk.className = "event-talk";
		$(talk).attr('list', "event-talk-list");
		talk.value = theTalk;
		
		var date = document.createElement('input');
		line.appendChild(date);
		date.className = "event-date";
		date.type = "date";
		date.value = theDate;
//time.disabled = (daily == 1);

		var time = document.createElement('input');
		line.appendChild(time);
		time.className = "event-time";
		time.type = "time";
//console.log(theTime)
		if (theTime == '00:00:00')
			time.value = ''
		else
			time.value = theTime;
		time.disabled = (daily == 1);
		
		var cbx = document.createElement('input');
		line.appendChild(cbx);
		cbx.className = "event-daily";
		cbx.type = "checkbox";
		cbx.checked = daily;
		$(cbx).on('click', function() { 
			if (this.checked) {
				time.disabled = true;
				time.value = '';
			}
			else
				time.disabled = false;
		})

/*		var cbxLabel = document.createElement("label");
		cbxLabel.innerHTML = "DAILY";
		cbxLabel.className = 'event-talk-daily';
		line.appendChild(cbxLabel);
*/		
		var canx = document.createElement('span');
		line.appendChild(canx);
		canx.innerHTML = "x";
		canx.className = "event-talk-canx";
		canx.onclick = function() {
			obj.deleteEventTalk(line);
		}
	}
	
	this.deleteEventTalk = function(line) {
		if ($('#event-talks').children().length == 1)
			alertBox('You must have at least one talk, even if it\'s TBA');
		else
			document.getElementById('event-talks').removeChild(line);
	}

	this.singleSpeakerCheck = function() {
		var single = $('#event-single-speaker').prop('checked');
		var talks = $('#event-talks').children();
		var firstSpeaker = '';
		for (var x=0; x<talks.length; x++) {
			var speaker = talks[x].getElementsByClassName('event-speaker')[0];
			$(speaker).prop('disabled', false);
			$(speaker).css('visibility', 'visible');
			
			if (x == 0) {
				firstSpeaker = 	$(speaker).val();
			}
			else {
				if (single) {
					$(speaker).val(firstSpeaker);
					$(speaker).prop('disabled', true);
				}
			}
		}
	}
			
	// EVENT TODO ITEMS
	this.eventTodoCheck = function() {
		if (this.currentEvent == 'new')
			this.createEventTodoItems();
		else
			this.getEventTodoItems();
		global.setTabActive('event-tab-5', "event-panel-5");
		$("#event-save-btn").show();
	}
	
	this.createEventTodoItems = function() {
		
		if (this.eventTodoItemsCreated) {
			return;
		}

		var obj = this;		
		$('#event-todo-items').html('');
			
		var sql = 'select * from event_todo_item_defaults';
		execSQL(sql, function(defaults) {
			var data = [];
			for (var x in defaults) {
				var basedOnDate = defaults[x].offset_date_type == 'B' ? $('#event-created-date').html() : obj.dateFrom;		// default based either on 'booking' or 'event'	
//console.log(global.bob(basedOnDate));				
//				var date = new Date(basedOnDate);
				var date = global.dateAsObject(basedOnDate);
				var newDate = new Date(date);
				newDate.setDate(newDate.getDate() + Number(defaults[x].offset_from_date));
				
				var dd = newDate.getDate();
				var mm = newDate.getMonth() + 1;
				var yyyy = newDate.getFullYear();
				var todoDate = yyyy + '-' + strZero(mm, 2) + '-' + strZero(dd, 2);
//console.log('todoDate=', basedOnDate, date, newDate, $('#event-created-date').html(), dd, todoDate)
				data[x] = { complete: false, item: defaults[x].item, due: todoDate };
				obj.addEventTodoItem(data[x]);							
			}
		}, false);

		this.eventTodoItemsCreated = true;
	}

	this.getEventTodoItems = function() {	
		var obj = this;		
		var sql = 'select * from event_todo_items where event_id=' + this.currentEvent;
		$('#event-todo-items').html('');
				
		execSQL(sql, function(data) {	
			for (var x in data) {
				obj.addEventTodoItem(data[x]);
			}
		});
	}
	
	this.addEventTodoItem = function(data) {
		var obj = this;
		
		var line = document.createElement('li');
		document.getElementById('event-todo-items').appendChild(line);
		line.className = "ui-state-default";

		var handle = document.createElement('span');
		line.appendChild(handle);
		handle.className = "event-todo-handle";
		handle.innerHTML = '&udarr;';		
		
		var cbx = document.createElement('input');
		line.appendChild(cbx);
		cbx.type = "checkbox";
		cbx.className = 'event-todo-complete';
		cbx.checked = (data.complete == 1);

		var cbxLabel = document.createElement("input");
		cbxLabel.innerHTML = data.item;
		cbxLabel.value = data.item;
		cbxLabel.className = 'event-todo-item';
		line.appendChild(cbxLabel);
		
		//show DOW
		var cbxDOW = document.createElement("div");
//console.log(data.due)		
		cbxDOW.innerHTML = typeof(data.due) == 'undefined' ? '--' : formatDate(data.due, 6);
		cbxDOW.className = 'event-todo-dow';
		line.appendChild(cbxDOW);
		
		var cbxDate = document.createElement("input");
		cbxDate.type = "date";
		cbxDate.value = data.due;
		cbxDate.className = 'event-todo-date';
		line.appendChild(cbxDate);
		$(cbxDate).on('change', function() { cbxDOW.innerHTML = formatDate(cbxDate.value, 6); });

		// list of all users so can assign event planner to todo item
		var cbxEP = document.createElement("select");
		cbxEP.id = 'id-' + Math.random().toString(36).substr(2, 16);		// need unique ID for fillPicklistWithData()
		cbxEP.className = 'event-todo-ep';
		line.appendChild(cbxEP);
		var options = oLogin.users;
		fillPicklistWithData(cbxEP.id, options, options);
		
		if (data.event_planner == undefined) {
			cbxEP.value = oLogin.login_uid;
		}
		else {
			cbxEP.value = data.event_planner;
		}
				
		var canx = document.createElement('span');
		line.appendChild(canx);
		canx.innerHTML = "x";
		canx.className = "event-todo-canx";
		canx.onclick = function() {
			obj.deleteEventTodoItem(line);
		}				
	}
	
	this.deleteEventTodoItem = function(line) {
		if ($('#event-todo-items').children().length == 1)
			alertBox('You must have at least one ToDo item.');
		else
			document.getElementById('event-todo-items').removeChild(line)
	}
	
	this.resetTodoDefaults = function() {
		confirmBox(
			"CONFIRM",
			"Are you sure you want to reset Todos to defaults?", 
			["Yes", "No"],
			[ function() { oEvent.eventTodoItemsCreated = false; oEvent.createEventTodoItems(); }, function() {} ]
		);		
	}
	
	this.refreshDialogTitle = function() {
		var date = '';
		if (this.dateFrom > '0000-00-00')
			date = ' // ' + formatDate(this.dateFrom, 6) + ' ' + this.dateFrom;	
		if (this.dateTo > '0000-00-00' && this.dateTo != this.dateFrom)
			date += '&mdash;' + formatDate(this.dateTo, 6) + ' ' + this.dateTo;

		$('#event-church-name').html(oChurch.details.name + date);
	}
	
	// calculate first event date and last event date
	this.recalcEventDates = function(talks) {
//console.log(talks)		

		this.dateFrom = talks[0][2];
		this.dateTo = this.dateFrom;
		
		var isBlanks = false;
		for (var x in talks) {
			
			if (talks[x][2] < this.dateFrom)
				this.dateFrom = talks[x][2];
			if (talks[x][2] > this.dateTo)
				this.dateTo = talks[x][2];
			if (this.dateFrom == '')
				this.dateFrom = this.dateTo;
		}

		this.refreshDialogTitle();
	}
	
	
	// DOCUMENTS
	
	this.listEventDocs = function() {		
		var obj = this;
		$('#event-all-documents-panel').hide();
		$('#event-document-container').hide();
		$('#event-documents-panel').slideDown();

		var b = new cb_browse('event-documents');
		var sql = "select status, status_date, name, '' as print, content, id from event_documents ed where event_id=" + this.currentEvent;
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.controls[0] = false;		// no search
		b.displayRecount = false;
		b.columns = ['id','status','status_date','name','print','content'];
		b.colClass = ['ed-id','ed-status','ed-status-date', 'ed-name','ed-print','hide'];
		b.colHeadings = ['ID','Status','Status date', 'Document name','',''];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'id';
		b.rowCallback = function(row, data, data2) { 
			row.children[4].innerHTML = '<img src="images/print.png" style="width: 15px">';
			row.children[4].title = 'Click to print';
			row.children[4].onclick = function(e) { 
				e.stopPropagation(); 
				$('#sos-print-container').html(data2.content);
				window.print();
				$('#sos-print-container').html('');
			}			
		}
		
		b.deleteFn = [true, function(data) { obj.deleteEventDocument(data[0]) } ];		
		b.fetch = function(data, xxx, json) {
			var x = screen.width/2 - 1000/2;
			var y = screen.height/2 - 700/2;
			obj.eventDocumentID = json.id;
			obj.eventDocumentOpen();
			$('#event-documents-panel').hide();
			$('#event-document-container').slideDown();
		}
		b.init();
		this.documentList = b;
	}
	
	this.deleteEventDocument = function(id) {
		var obj = this;
		var sql = 'delete from event_documents where id=' + id;
		execSQL(sql, function() {
			obj.listEventDocs();
		});
	}
	
	this.xxxxxxxxxxxxxxxxxgetEventSpeakersForWord = function() {
		var eventSpeakers = '';
		var talks = $('#event-talks').children();
		for (var x=0; x<talks.length; x++) {
			var speaker = talks[x].getElementsByClassName('event-speaker')[0].value;
			eventSpeakers += speaker + ' - ';
		}
		return eventSpeakers;
	}
	
	this.getEventSpeakersForWord = function(firstNameOnly) {
		var eventSpeakers = [];
		var talks = $('#event-talks').children();
		var handle;
		for (var x=0; x<talks.length; x++) {
			if (firstNameOnly) {
				handle = (talks[x].getElementsByClassName('event-speaker')[0].value).split(' ')[0];
				eventSpeakers.push(handle);
			}
			else
				eventSpeakers.push(talks[x].getElementsByClassName('event-speaker')[0].value);
		}
		
		return dedupeArray(eventSpeakers).join(' / ');
	}
	
	this.getEventTalksForWord = function() {
		var eventTalks = '';
		var talks = $('#event-talks').children();
		for (var x=0; x<talks.length; x++) {
			var talk = talks[x].getElementsByClassName('event-talk')[0].value;
			var time = talks[x].getElementsByClassName('event-time')[0].value;
//console.log('>' + time + '<')
			if (time == '')
				var timeForDisplay = '';
			else
				var timeForDisplay = ' (' + global.formatTime(1, time) + ')';
			eventTalks += talk + timeForDisplay + "<br>";
		}
		return eventTalks;
	}
	
	this.getMinistryHistoryForWord = function() {
		var ministryHistory = '';
		var sql = "select *, (select group_concat(talk) from event_talks where event_id=e.id) as talks, (select group_concat(speaker) from event_talks where event_id=e.id) as speaker from events e where e.id<>" + this.currentEvent + " and church_id=" + oChurch.details.id;
		execSQL(sql, function(data) {
			for (var x in data) {
//console.log(sql, data[x].event_date, data[x].talks, data[x].speaker, data[x].attendance_actual);
				ministryHistory += data[x].event_date + ' - ' + data[x].talks + " (" + data[x].speaker + ") - " + data[x].attendance_actual + "<br>";
			}			
		}, false);
		return ministryHistory;
	}	
	
	this.listDocuments = function() {
		var obj = this;
		$('#event-documents-panel').slideUp();
		$('#event-all-documents-panel').slideDown();
		
		var b = new cb_browse('event-all-documents');
		var sql = "select id, name, content from document_templates";
		b.preQuery = 'create temporary table report (index(name)) ENGINE=MyISAM (' + sql + ')';
		b.query = 'select * from report';
		b.rowDepth = 0;
		b.controls[0] = false;		// no search
		b.displayRecount = false;
		b.columns = ['id','name','content'];
		b.colClass = ['hide','','hide'];
		b.colHeadings = ['','',''];
		b.colHeadClass = b.colClass;
		b.sortColumn = 'name';
		b.fetch = function(data, xxx, json) {
			obj.mailMerge(json);
		}
		b.init();
	}	
	
	this.mailMerge = function(templateDoc) {
		var obj = this;
		var eventTalks = this.getEventTalksForWord();
		var ministryHistory = this.getMinistryHistoryForWord();	
	
		var mmData = [];
		for (var x in global.miniMaxDocFields) {
			mmData[x] = new Array();
			mmData[x][0] = global.miniMaxDocFields[x][1];
			mmData[x][1] = global.miniMaxDocFields[x][2]();
		}
		
		var mergedDoc = templateDoc.content;

		for (var x in mmData) {
			mergedDoc = mergedDoc.replace(new RegExp(mmData[x][0], 'g'), mmData[x][1]);
		}
	
		$.ajax({
			type: 'post',
			url: "scripts/add-event-document.php",
			cache: false,
			data: { 
				name: templateDoc.name,
				content: mergedDoc,
				eventID: obj.currentEvent
			},
			success: function(result) { 
				statusMsg('Document added.');	
				obj.listEventDocs();
			},
			error: function(xhr) {
				alertBox(xhr.responseText);
			},
			dataType: 'json'
		});		
	}
	
	this.eventDocumentOpen = function() {
		var sql = 'select name, status, status_date, content from event_documents where id=' + this.eventDocumentID;	
		execSQL(sql, function(results) {
			if (results.length == 0) {
				var status  = '';
				var statusDate  = '';
				var name  = 'No document found.';
				var content = 'No document found.';
			}
			else {
				var status = results[0].status;
				var statusDate = results[0].status_date;
				var name = results[0].name;
				var content = results[0].content;
			}
				
			$('#event-document-title').html(name);	
			$('#event-document-status').val(status);	
			$('#event-document-status-date').val(statusDate);	
			tinymce.get('event-document-text-edit').setContent(content);		
		});
	}

	this.eventDocumentSave = function() {
		var obj = this;

		$.ajax({
			type: 'post',
			url: "scripts/event-document.php",
			cache: false,
			data: { 
				id: obj.eventDocumentID,
				status: $('#event-document-status').val(),
				statusDate: $('#event-document-status-date').val(),
				content: tinymce.get('event-document-text-edit').getContent()
			},
			success: function(result) { 
//console.log(oEvents)
				log('EPIC DOCUMENT UPDATED', oChurch.details.name + ' > ' + $('#event-date').val() + ' - ' + $('#event-document-title').html());				
				statusMsg('Document saved.');
				obj.documentList.refreshData();
			},
			error: function(xhr) {
				alertBox(xhr.responseText);
			},
			dataType: 'json'
		});			
	}

	this.eventDocumentClose = function(id) {
		$('#event-document-container').hide();
		$('#event-documents-panel').show();
	}
	
	this.eventDocumentWordExport = function() {
		var obj = this;		
		var textArea = document.createElement('div');

		document.body.appendChild(textArea);
		textArea.innerHTML = tinymce.get('event-document-text-edit').getContent();
		textArea.style.backgroundColor = 'white';
		global.copyToClipboard(textArea);
		document.body.removeChild(textArea);
	}

	this.documentSendByEmail = function(target) {			
//console.log(this.eventDocumentWordExport());
		$(target).attr("href", "mailto:" + $("#church-email").val());
	}	

	this.viewOnWebCalendar = function() {
//console.log(oEvent)		

		var id = strZero(500000 + Number(oEvent.currentEvent), 21) + 'O';
		var country = global.isCA ? 'ca' : 'gb';
//console.log(id)		
		window.open('https://creation.com/events/' + country + '/' + id);
		return;
		
	}
}